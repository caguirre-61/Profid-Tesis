<?php
// conexión a la base
try {
    $config = "mysql:host=localhost;dbname=u214138677_profid;charset=utf8";
    $cnx = new PDO($config, 'root', '');
    $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $error) {
    die("Hubo un error en la conexión: " . $error->getMessage());
}
?>
```[cite: 1]
  