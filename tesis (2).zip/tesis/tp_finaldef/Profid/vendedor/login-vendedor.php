<?php
/*
session_start();

// Parámetros de la Base de Datos
$host     = "localhost";
$user_bd  = "root";
$pass_bd  = "";
$nombre_bd= "profid_obras";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$nombre_bd;charset=utf8", $user_bd, $pass_bd);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $pdo->prepare("SELECT * FROM vendedores WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $vendedor = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($vendedor && password_verify($password, $vendedor['password'])) {
        $_SESSION['vendedor_id']     = $vendedor['id'];
        $_SESSION['vendedor_nombre'] = $vendedor['nombre'];
        $_SESSION['empresa']         = $vendedor['empresa'];
        
        header("Location: index.html");
        exit;
    } else {
        $error = "El correo o la contraseña son incorrectos.";
    }
        
}
*/
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ProFid - Ingreso Vendedores</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --pf-brand-500: #0ea5e9;
      --pf-brand-600: #0284c7;
      --pf-brand-700: #0369a1;
      --pf-industrial: #0f172a;
    }
    .bg-industrial { background-color: var(--pf-industrial); }
    .bg-brand { background-color: var(--pf-brand-600); }
    .hover-bg-brand:hover { background-color: var(--pf-brand-700); }
    .text-brand { color: var(--pf-brand-500); }
    .fade-in {
      animation: fadeIn 0.3s ease-in-out forwards;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 font-sans min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-md bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden fade-in">
    
    <!-- HEADER PRO FID -->
    <div class="bg-industrial px-8 py-6 text-center border-b border-white/10">
      <div class="inline-flex items-center gap-3 justify-center mb-2">
        <div class="w-10 h-10 rounded-xl bg-brand flex items-center justify-center text-white font-extrabold text-xl shadow-lg">P</div>
        <span class="text-2xl font-black text-white tracking-wide">Pro<span class="text-brand">Fid</span></span>
      </div>
      <p class="text-xs text-gray-400 font-medium uppercase tracking-wider">Acceso para Vendedores / Proveedores</p>
    </div>

    <div class="p-6 md:p-8">
      <h2 class="text-xl font-bold text-slate-800 mb-1 text-center">Iniciar Sesión</h2>
      <p class="text-xs text-gray-500 text-center mb-6">Ingresá a tu cuenta comercial para gestionar tus insumos</p>

      <!-- FORMULARIO DE LOGIN -->
      <form action="index.html" method="POST" class="space-y-4">
        <div>
          <label for="email" class="block text-xs font-semibold text-gray-600 mb-1">Correo Electrónico Comercial</label>
          <input type="email" id="email" name="email" required placeholder="ventas@corralon.com" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
        </div>

        <div>
          <label for="password" class="block text-xs font-semibold text-gray-600 mb-1">Contraseña</label>
          <input type="password" id="password" name="password" required placeholder="••••••••" class="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
        </div>

        <div class="flex items-center justify-between text-xs pt-1">
          <label class="flex items-center gap-2 text-gray-500 cursor-pointer">
            <input type="checkbox" class="rounded border-gray-300 text-sky-600 focus:ring-sky-500"> Recordarme
          </label>
          <a href="#" class="text-sky-600 hover:underline font-medium">¿Olvidaste tu contraseña?</a>
        </div>

        <button type="submit" class="w-full bg-brand hover-bg-brand text-white font-bold py-3 rounded-lg transition-colors text-sm shadow-md mt-2">
          Ingresar al Sistema
        </button>
      </form>

      <!-- ENLACE A REGISTRO -->
      <div class="mt-6 text-center text-xs text-gray-500">
        ¿Aún no tenés una cuenta? 
        <a href="registro-vendedor.php" class="text-sky-600 font-bold hover:underline">Registrate aquí</a>
      </div>
    </div>

    <!-- PIE DE PÁGINA -->
    <div class="bg-slate-50 px-6 py-4 border-t border-gray-200 text-center text-xs text-gray-400">
      Plataforma de Gestión ProFid &copy; 2026
    </div>

  </div>

</body>
</html>