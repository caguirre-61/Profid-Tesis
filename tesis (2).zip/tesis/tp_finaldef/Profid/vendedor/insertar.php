<?php
// conexión a la base
try {
    $config = "mysql:host=localhost;dbname=mcking;charset=utf8";
    $cnx = new PDO($config, 'root', '');
    $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $error) {
    die("Hubo un error en la conexión: " . $error->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado - Registro Empleado</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
    }

    .container-box {
      background-color: #111;
      border-radius: 18px;
      border: 2px solid #ffc107;
      max-width: 500px;
      width: 100%;
      padding: 30px 40px;
      box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
      text-align: center;
    }

    h2 {
      color: #ffc107;
      font-weight: bold;
      margin-bottom: 25px;
    }

    .alert-success, .alert-danger {
      border-radius: 12px;
      padding: 15px 20px;
      font-weight: 600;
      margin-bottom: 25px;
      box-shadow: 0 3px 10px rgba(255, 193, 7, 0.2);
    }

    .alert-success {
      background-color: #2d4d1a;
      color: #c3e88d;
      border: 1px solid #9ccc65;
    }

    .alert-danger {
      background-color: #5a1e1e;
      color: #f9b3b3;
      border: 1px solid #f28b8b;
    }

    a.btn {
      display: inline-block;
      font-weight: bold;
      padding: 12px 30px;
      border-radius: 50px;
      text-decoration: none;
      transition: background-color 0.3s ease;
      margin: 5px;
      border: none;
    }

    a.btn-primary {
      background-color: #ffc107;
      color: #000;
    }

    a.btn-primary:hover {
      background-color: #e6b006;
    }

    a.btn-secondary {
      background-color: #333;
      color: #fff;
      border: 2px solid #777;
    }

    a.btn-secondary:hover {
      background-color: #444;
    }
  </style>
</head>
<body>
  <div class="container-box">
    <h2>Resultado del registro</h2>

    <?php
    $nombre    = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $usuario   = isset($_POST['usuario']) ? trim($_POST['usuario']) : '';
    $password  = isset($_POST['password']) ? trim($_POST['password']) : '';
    $rol       = isset($_POST['rol']) ? trim($_POST['rol']) : ''; 

    if ($nombre === "" || $usuario === "" || $password === "" || $rol === "") {
        echo '<div class="alert alert-danger">Completa todos los campos</div>';
        echo '<a href="registrar.php" class="btn btn-secondary">Volver al formulario</a>';
    } else {
        try {
            // Verificar si el usuario ya existe (opcional)
            $check = $cnx->prepare("SELECT COUNT(*) FROM empleados WHERE usuario = :usuario");
            $check->bindValue(':usuario', $usuario);
            $check->execute();
            $existe = $check->fetchColumn();

            if ($existe > 0) {
                echo '<div class="alert alert-danger">El usuario ya existe</div>';
                echo '<a href="registrar.php" class="btn btn-secondary">Volver al formulario</a>';
            } else {
                $query = $cnx->prepare(
                  "INSERT INTO empleados (nombre, usuario, password, rol)
                   VALUES (:nombre, :usuario, :password, :rol)"
                );
                $query->bindValue(':nombre', $nombre);
                $query->bindValue(':usuario', $usuario);
                $query->bindValue(':password', $password); // Considera usar password_hash()
                $query->bindValue(':rol', $rol);

                $usuario_agregado = $query->execute();

                if ($usuario_agregado) {
                    echo '<div class="alert alert-success">Empleado registrado exitosamente</div>';
                    echo '<a href="listado.php" class="btn btn-primary">Ver empleados</a>';
                } else {
                    echo '<div class="alert alert-danger">Error al guardar empleado</div>';
                    echo '<a href="registrar.php" class="btn btn-secondary">Volver al formulario</a>';
                }
            }
        } catch (PDOException $e) {
            echo '<div class="alert alert-danger">Error en la base de datos: ' . htmlspecialchars($e->getMessage()) . '</div>';
            echo '<a href="registrar.php" class="btn btn-secondary">Volver al formulario</a>';
        }
    }
    ?>
  </div>
</body>
</html>
