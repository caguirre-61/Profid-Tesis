<?php
require 'conexion.php';

$criterio = $_GET['criterio'] ?? '';

if ($criterio != '') {
    $query = $cnx->prepare("SELECT * FROM empleados WHERE nombre LIKE :criterio");
    $query->bindValue(":criterio", "%$criterio%");
} else {
    $query = $cnx->prepare("SELECT * FROM empleados");
}

$query->execute();
$datos = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Listado de Empleados</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
      min-height: 100vh;
    }
    .container-box {
      background-color: #111;
      border-radius: 18px;
      border: 2px solid #ffc107;
      max-width: 1000px;
      width: 100%;
      padding: 30px 40px;
      box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
    }
    h1, h2 {
      color: #ffc107;
      text-align: center;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn-primary {
      background-color: #ffc107;
      border: none;
      color: #000;
      font-weight: bold;
      padding: 10px 25px;
      border-radius: 50px;
      cursor: pointer;
      transition: background-color 0.3s;
      text-decoration: none;
      display: inline-block;
    }
    .btn-primary:hover {
      background-color: #e6b006;
    }
    form {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 30px;
    }
    input.form-control {
      padding: 10px;
      border-radius: 10px;
      border: 2px solid #ffc107;
      background-color: #222;
      color: #fff;
      width: 300px;
      font-size: 16px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: center;
      border-radius: 10px;
      overflow: hidden;
    }
    thead {
      background-color: #ffc107;
      color: #000;
    }
    th, td {
      padding: 15px;
      border-bottom: 1px solid #444;
      vertical-align: middle;
    }
    tbody tr:hover {
      background-color: #222;
    }
    .btn-danger, .btn-warning {
      border: none;
      border-radius: 8px;
      padding: 6px 12px;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s;
      text-decoration: none;
      display: inline-block;
      margin: 0 2px;
    }
    .btn-danger {
      background-color: #e63946;
      color: #fff;
    }
    .btn-danger:hover {
      background-color: #c71c2f;
    }
    .btn-warning {
      background-color: #ffc107;
      color: #000;
    }
    .btn-warning:hover {
      background-color: #e6b006;
    }
    img {
      border-radius: 6px;
      max-width: 70px;
      height: auto;
    }
    .descripcion {
      text-align: left;
      color: #ccc;
      font-size: 14px;
    }
</style>

</head>
<body>
  <div class="container-box">
    <div class="logo-side">
      <h1>McKing</h1>
    </div>

    <h2>Listado de Empleados</h2>

    <form method="get" class="row g-2 justify-content-center">
      <input type="text" name="criterio" class="form-control" placeholder="Buscar por nombre" value="<?= htmlspecialchars($criterio) ?>">
      <button type="submit" class="btn-primary">Buscar</button>
    </form>

    <a href="registrar.php" class="btn-primary mb-3" style="display: inline-block; margin-bottom: 20px;">Agregar nuevo</a>
     <a href="index.php" class="btn-primary mb-3" style="display: inline-block; margin-bottom: 20px;">Volver Inicio</a>

    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Usuario</th>
          <th>Password</th>
          <th>Rol</th>
          <th>Eliminar</th>
          <th>Modificar</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($datos) > 0): ?>
            <?php foreach ($datos as $fila): ?>
            <tr>
              <td><?= htmlspecialchars($fila['nombre']); ?></td>
              <td><?= htmlspecialchars($fila['usuario']); ?></td>
              <td><?= htmlspecialchars($fila['password']); ?></td>
              <td><?= htmlspecialchars($fila['rol']); ?></td>
              <td>
                <a href="eliminar-empleado.php?id=<?= $fila['id_empleado']; ?>" class="btn-danger" onclick="return confirm('¿Estás seguro que querés eliminar?')">Eliminar</a>
              </td>
              <td>
                <a href="form-modificar.php?id=<?= $fila['id_empleado']; ?>" class="btn-warning">Modificar</a>
              </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
              <td colspan="6" class="text-center text-muted" style="color:#999;">No se encontraron empleados</td>
            </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
