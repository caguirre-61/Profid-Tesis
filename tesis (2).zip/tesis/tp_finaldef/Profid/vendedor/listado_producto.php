<?php
require 'conexion.php';

$criterio = trim($_GET['criterio'] ?? '');

if ($criterio !== '') {
    $query = $cnx->prepare("SELECT * FROM productos WHERE nombre LIKE :criterio");
    $query->bindValue(":criterio", "%$criterio%");
} else {
    $query = $cnx->prepare("SELECT * FROM productos");
}

$query->execute();
$datos = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Listado de Productos</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
      min-height: 100vh;
    }
    .container-box {
      background-color: #111;
      border-radius: 18px;
      border: 2px solid #ffc107;
      max-width: 1000px;
      width: 100%;
      padding: 30px 40px;
      box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
    }
    h1, h2 {
      color: #ffc107;
      text-align: center;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .btn-primary {
      background-color: #ffc107;
      border: none;
      color: #000;
      font-weight: bold;
      padding: 10px 25px;
      border-radius: 50px;
      cursor: pointer;
      transition: background-color 0.3s;
      text-decoration: none;
      display: inline-block;
    }
    .btn-primary:hover {
      background-color: #e6b006;
    }
    form {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 30px;
    }
    input.form-control {
      padding: 10px;
      border-radius: 10px;
      border: 2px solid #ffc107;
      background-color: #222;
      color: #fff;
      width: 300px;
      font-size: 16px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: center;
      border-radius: 10px;
      overflow: hidden;
    }
    thead {
      background-color: #ffc107;
      color: #000;
    }
    th, td {
      padding: 15px;
      border-bottom: 1px solid #444;
      vertical-align: middle;
    }
    tbody tr:hover {
      background-color: #222;
    }
    .btn-danger, .btn-warning {
      border: none;
      border-radius: 8px;
      padding: 6px 12px;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s;
      text-decoration: none;
      display: inline-block;
      margin: 0 2px;
    }
    .btn-danger {
      background-color: #e63946;
      color: #fff;
    }
    .btn-danger:hover {
      background-color: #c71c2f;
    }
    .btn-warning {
      background-color: #ffc107;
      color: #000;
    }
    .btn-warning:hover {
      background-color: #e6b006;
    }
    img {
      border-radius: 6px;
      max-width: 70px;
      height: auto;
    }
    .descripcion {
      text-align: left;
      color: #ccc;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="container-box">
    <h1>McKing</h1>
    <h2>Listado de Productos</h2>

    <form method="get" action="">
      <input
        type="text"
        name="criterio"
        placeholder="Buscar por nombre"
        value="<?= htmlspecialchars($criterio) ?>"
        class="form-control"
        autocomplete="off"
      />
      <button type="submit" class="btn-primary">Buscar</button>
    </form>

    <a href="producto.php" class="btn-primary" style="margin-bottom: 20px;">Agregar nuevo</a>
    <a href="index.php" class="btn-primary" style="margin-bottom: 20px;">Volver Inicio</a>
    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Precio</th>
          <th>Descripción</th>
          <th>Imagen</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($datos) > 0): ?>
          <?php foreach ($datos as $fila): ?>
            <tr>
              <td><?= htmlspecialchars($fila['nombre']) ?></td>
              <td>$<?= number_format($fila['precio'], 0, ',', '.') ?></td>
              <td class="descripcion"><?= htmlspecialchars($fila['descripcion'] ?? '—') ?></td>
              <td><img src="<?= htmlspecialchars($fila['img_path']) ?>" alt="Imagen de <?= htmlspecialchars($fila['nombre']) ?>" /></td>
              <td>
                <a href="modificar-producto.php?id=<?= (int)$fila['id_producto'] ?>" class="btn-warning">Modificar</a>
                <a href="eliminar-producto.php?id=<?= (int)$fila['id_producto'] ?>" class="btn-danger" onclick="return confirm('¿Estás seguro que querés eliminar este producto?')">Eliminar</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" style="color:#999;">No se encontraron productos.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
