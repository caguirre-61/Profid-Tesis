<?php
require 'conexion.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    die("Error: no se especificó el empleado.");
}

$query = $cnx->prepare("SELECT * FROM empleados WHERE id_empleado = :id");
$query->bindValue(":id", $id, PDO::PARAM_INT);
$query->execute();
$datos = $query->fetch(PDO::FETCH_ASSOC);

if (!$datos) {
    die("Error: empleado no encontrado.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Modificar Empleado - McKing</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Montserrat', sans-serif; background-color: #000; color: #fff; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
    .container-box { background-color: #111; border-radius: 18px; border: 2px solid #ffc107; max-width: 450px; width: 100%; padding: 40px 40px 30px; box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4); text-align: center; }
    .logo-circle { width: 90px; height: 90px; border: 4px solid #ffc107; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-weight: bold; font-size: 26px; margin: 0 auto 20px; color: #ffc107; }
    h2 { color: #ffc107; font-weight: 700; margin-bottom: 30px; }
    form { text-align: left; }
    label { display: block; margin-bottom: 6px; font-weight: 600; color: #ffc107; }
    .form-control, .form-select { border-radius: 10px; border: 2px solid #ffc107; background-color: #222; color: #fff; padding: 10px 15px; width: 100%; font-size: 16px; margin-bottom: 20px; transition: border-color 0.3s, background-color 0.3s; }
    .form-control:focus, .form-select:focus { outline: none; border-color: #fff; background-color: #333; }
    .btn-primary { background-color: #ffc107; border: none; color: #000; font-weight: 700; padding: 12px 25px; border-radius: 50px; cursor: pointer; width: 100%; transition: background-color 0.3s; margin-top: 10px; display: inline-block; text-align: center; text-decoration: none; border: 2px solid #ffc107; }
    .btn-primary:hover { background-color: #e6b006; border-color: #e6b006; color: #000; }
    .btn-secondary { background-color: transparent; border: 2px solid #ffc107; color: #ffc107; padding: 12px 25px; border-radius: 50px; cursor: pointer; width: 100%; margin-top: 15px; text-align: center; text-decoration: none; display: inline-block; font-weight: 700; transition: background-color 0.3s, color 0.3s; }
    .btn-secondary:hover { background-color: #ffc107; color: #000; }
  </style>
</head>
<body>
  <div class="container-box">
    <div class="logo-circle">McK</div>
    <h2>Modificar Empleado</h2>
    <form action="modificar.php" method="post">
      <input type="hidden" name="id_empleado" value="<?= $datos['id_empleado']; ?>">

      <label for="nombre">Nombre completo</label>
      <input type="text" class="form-control" id="nombre" name="nombre" value="<?= htmlspecialchars($datos['nombre']); ?>" required />

      <label for="usuario">Nombre de usuario</label>
      <input type="text" class="form-control" id="usuario" name="usuario" value="<?= htmlspecialchars($datos['usuario']); ?>" required />

      <label for="password">Contraseña</label>
      <input type="password" class="form-control" id="password" name="password" value="<?= htmlspecialchars($datos['password']); ?>" required />

      <label for="rol">Rol</label>
      <select name="rol" id="rol" class="form-select" required>
        <option value="cocinero" <?= $datos['rol'] == 'cocinero' ? 'selected' : '' ?>>Cocinero</option>
        <option value="encargado" <?= $datos['rol'] == 'encargado' ? 'selected' : '' ?>>Encargado</option>
      </select>

      <button type="submit" class="btn-primary">Modificar</button>
    </form>
    <a href="listado.php" class="btn-secondary">Cancelar</a>
  </div>
</body>
</html>
