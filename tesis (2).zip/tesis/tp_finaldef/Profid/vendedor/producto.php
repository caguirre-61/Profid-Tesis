<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Insertar Producto - McKing</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Roboto', sans-serif;
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #000000 50%, #ffcc00 50%);
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }

    .container-main {
      background-color: #ffffff;
      border-radius: 18px;
      padding: 40px;
      width: 420px;
      box-shadow: 0 6px 25px rgba(0,0,0,0.3);
      text-align: center;
    }

    .logo-circle {
      width: 90px;
      height: 90px;
      border: 4px solid #ffcc00;
      border-radius: 50%;
      color: #ffcc00;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      font-size: 26px;
      margin: 0 auto 10px;
    }

    h2 {
      color: #ffcc00;
      font-weight: bold;
      margin-bottom: 25px;
    }

    .form-label {
      color: #333;
      font-weight: 500;
      text-align: left;
      display: block;
    }

    .form-control {
      border-radius: 10px;
      border: 1px solid #ccc;
      background-color: #fff;
      color: #000;
    }

    .form-control:focus {
      border-color: #ffcc00;
      box-shadow: 0 0 8px rgba(255,204,0,0.4);
    }

    .btn-primary {
      background-color: #ffcc00;
      border: none;
      width: 100%;
      border-radius: 50px;
      padding: 10px;
      font-weight: bold;
      color: #000;
      margin-top: 10px;
    }

    .btn-primary:hover {
      background-color: #e6b800;
    }

    a {
      text-decoration: none;
      color: #ffcc00;
      display: block;
      margin-top: 15px;
      font-weight: bold;
    }

    a:hover {
      color: #000;
    }

  </style>
</head>

<body>
  <div class="container-main">
    <div class="logo-circle">McK</div>
    <h2>Insertar Producto</h2>

    <form action="resultado-insercion.php" method="POST">
      
      <div class="mb-3 text-start">
        <label class="form-label">Nombre del producto</label>
        <input type="text" name="nombre" class="form-control" required>
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Precio</label>
        <input type="number" name="precio" step="0.01" class="form-control" required>
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Imagen (URL o nombre de archivo)</label>
        <input type="text" name="img_path" class="form-control" required>
      </div>

      <div class="mb-3 text-start">
        <label class="form-label">Descripción</label>
        <textarea name="descripcion" class="form-control" rows="4" required></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Insertar Producto</button>
    </form>

    <a href="index.php">Volver al inicio</a>
  </div>
</body>
</html>
