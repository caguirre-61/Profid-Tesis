<?php
require 'conexion.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    die("Error: no se especificó el producto a eliminar.");
}

$query = $cnx->prepare("DELETE FROM productos WHERE id_producto = :id");
$query->bindValue(":id", $id, PDO::PARAM_INT);
$query->execute();

$filas = $query->rowCount();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Eliminar producto - McKing</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
      * { margin: 0; padding: 0; box-sizing: border-box; }
      body {
        font-family: 'Montserrat', sans-serif;
        background-color: #000;
        color: #fff;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px;
      }
      .container-box {
        background-color: #111;
        border-radius: 18px;
        border: 2px solid #ffc107;
        max-width: 450px;
        width: 100%;
        padding: 30px 40px;
        text-align: center;
        box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
      }
      h2 {
        color: #ffc107;
        font-weight: 700;
        margin-bottom: 30px;
      }
      .alert-success, .alert-danger {
        border-radius: 12px;
        padding: 15px 20px;
        font-weight: 600;
        margin-bottom: 25px;
        box-shadow: 0 3px 10px rgba(255, 193, 7, 0.2);
      }
      .alert-success {
        background-color: #2d4d1a;
        color: #c3e88d;
        border: 1px solid #9ccc65;
      }
      .alert-danger {
        background-color: #5a1e1e;
        color: #f9b3b3;
        border: 1px solid #f28b8b;
      }
      a.btn-success {
        display: inline-block;
        background-color: #ffc107;
        color: #000;
        font-weight: 700;
        padding: 12px 30px;
        border-radius: 50px;
        text-decoration: none;
        transition: background-color 0.3s ease;
        border: 2px solid #ffc107;
      }
      a.btn-success:hover {
        background-color: #e6b006;
        border-color: #e6b006;
        color: #000;
        text-decoration: none;
      }
    </style>
</head>
<body>
  <div class="container-box">
    <h2>Eliminar producto</h2>

    <?php if ($filas > 0): ?>
        <div class="alert alert-success">
            Se borró <strong><?= $filas ?></strong> producto.
        </div>
    <?php else: ?>
        <div class="alert alert-danger">
            No se borró ningún producto
        </div>
    <?php endif; ?>

    <a href="listado_producto.php" class="btn-success">Volver al listado</a>
  </div>
</body>
</html>
