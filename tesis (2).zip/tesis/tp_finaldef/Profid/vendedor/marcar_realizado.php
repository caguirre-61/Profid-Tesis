<?php
require 'conexion.php';

if (!isset($_POST['id'])) {
    die("ID invalido");
}

$id = $_POST['id'];

$update = $cnx->prepare("UPDATE pedidos SET estado = 'realizado' WHERE id_pedido = ?");
$update->execute([$id]);

header("Location: cocinero.php");
exit;
?>

