<?php
require 'conexion.php';

//trae los peiddos
$sql = "
    SELECT p.id_pedido, p.fecha_hora, p.total, p.estado, c.usuario
    FROM pedidos p
    JOIN clientes c ON p.id_cliente = c.id_cliente
    ORDER BY p.fecha_hora DESC
";

$query = $cnx->prepare($sql);
$query->execute();

$pedidos = $query->fetchAll(PDO::FETCH_ASSOC);

//separa el estado del pedido
$pendientes = array_filter($pedidos, fn($p) => $p['estado'] === 'pendiente');
$realizados = array_filter($pedidos, fn($p) => $p['estado'] === 'realizado');

$usuario = "Cocinero"; // <-- BORRAR ESTO cuando uses sesiones reales
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Pedidos - Cocina</title>

<style>
    body {
        font-family: 'Montserrat', sans-serif;
        background: #000;
        padding: 0;
        margin: 0;
        color: #fff;
    }

    .topbar {
        width: 100%;
        background: #111;
        padding: 15px 25px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 2px solid #ffca2c;
        box-shadow: 0 0 15px rgba(255, 202, 44, 0.3);
    }

    .topbar .saludo {
        font-size: 20px;
        color: #ffca2c;
        font-weight: bold;
    }

    .topbar button {
        padding: 10px 18px;
        background: #ffca2c;
        border: none;
        border-radius: 8px;
        color: #000;
        font-weight: bold;
        cursor: pointer;
    }

    .topbar button:hover {
        background: #e6b800;
    }

    .content {
        padding: 30px;
    }

    h2 {
        margin-top: 20px;
        color: #ffca2c;
        border-left: 6px solid #ffca2c;
        padding-left: 10px;
    }

    .seccion {
        padding: 20px;
        background: #111;
        border-radius: 12px;
        margin-bottom: 40px;
        border: 2px solid #ffca2c;
        box-shadow: 0 0 15px rgba(255, 202, 44, 0.3);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
        background: #222;
        border-radius: 12px;
        overflow: hidden;
    }

    th {
        background: #ffca2c;
        color: #000;
        padding: 12px;
        text-align: left;
        font-weight: bold;
    }

    td {
        padding: 12px;
        border-bottom: 1px solid #444;
        color: #eee;
    }

    tr:hover {
        background: #333;
    }

    button {
        padding: 8px 14px;
        border: none;
        background: #ffca2c;
        color: #000;
        cursor: pointer;
        border-radius: 8px;
        font-weight: bold;
    }

    button:hover {
        background: #e6b800;
    }
</style>

</head>
<body>

<div class="topbar">
    <div class="saludo">Hola, <?= htmlspecialchars($usuario); ?> </div>

    <form action="../index-principal.php" method="GET">
        <button>Volver al inicio</button>
    </form>
</div>

<div class="content">

<div class="seccion">
<h2>Pedidos Pendientes</h2>

<table>
<tr>
    <th>ID</th>
    <th>Cliente</th>
    <th>Fecha</th>
    <th>Total</th>
    <th>Estado</th>
    <th>Acción</th>
</tr>

<?php foreach ($pendientes as $p): ?>
<tr>
    <td><?= $p['id_pedido']; ?></td>
    <td><?= $p['usuario']; ?></td>
    <td><?= $p['fecha_hora']; ?></td>
    <td>$<?= $p['total']; ?></td>
    <td><?= $p['estado']; ?></td>

    <td>
        <form action="marcar_realizado.php" method="POST">
            <input type="hidden" name="id" value="<?= $p['id_pedido']; ?>">
            <button type="submit">Marcar realizado</button>
        </form>
    </td>
</tr>
<?php endforeach; ?>
</table>
</div>

<div class="seccion">
<h2>Pedidos Realizados</h2>

<table>
<tr>
    <th>ID</th>
    <th>Cliente</th>
    <th>Fecha</th>
    <th>Total</th>
    <th>Estado</th>
</tr>

<?php foreach ($realizados as $p): ?>
<tr>
    <td><?= $p['id_pedido']; ?></td>
    <td><?= $p['usuario']; ?></td>
    <td><?= $p['fecha_hora']; ?></td>
    <td>$<?= $p['total']; ?></td>
    <td><?= $p['estado']; ?></td>
</tr>
<?php endforeach; ?>
</table>
</div>

</div>

</body>
</html>
