<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado de inserción</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
    }

    .container-box {
      background-color: #111;
      border-radius: 18px;
      border: 2px solid #ffc107;
      max-width: 500px;
      width: 100%;
      padding: 30px 40px;
      box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
      text-align: center;
    }

    h2 {
      color: #ffc107;
      font-weight: bold;
      margin-bottom: 25px;
    }

    .alert-success, .alert-danger, .alert-warning {
      border-radius: 12px;
      padding: 15px 20px;
      font-weight: 600;
      margin-bottom: 25px;
    }

    .alert-success {
      background-color: #2d4d1a;
      color: #c3e88d;
      border: 1px solid #9ccc65;
    }

    .alert-danger {
      background-color: #5a1e1e;
      color: #f9b3b3;
      border: 1px solid #f28b8b;
    }

    .alert-warning {
      background-color: #554400;
      color: #fff3b0;
      border: 1px solid #ffc107;
    }

    a.btn {
      display: inline-block;
      font-weight: bold;
      padding: 12px 30px;
      border-radius: 50px;
      text-decoration: none;
      transition: background-color 0.3s ease;
      margin-top: 10px;
    }

    a.btn-primary {
      background-color: #ffc107;
      color: #000;
    }

    a.btn-primary:hover {
      background-color: #e6b006;
    }

    a.btn-secondary {
      background-color: #444;
      color: #fff;
    }

    a.btn-secondary:hover {
      background-color: #666;
    }
  </style>
</head>
<body>
  <div class="container-box">
    <h2>Resultado del registro de producto</h2>

    <?php
    require 'conexion.php';

    $nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $precio = isset($_POST['precio']) ? trim($_POST['precio']) : '';
    $imagen = isset($_POST['img_path']) ? trim($_POST['img_path']) : '';
    $descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';

    if ($nombre === "" || $precio === "" || $imagen === "" || $descripcion === "") {
        echo '<div class="alert alert-danger">Por favor, completá todos los campos.</div>';
        echo '<a href="producto.php" class="btn btn-secondary">Volver al formulario</a>';
    } else {
        try {
            $check = $cnx->prepare("SELECT COUNT(*) FROM productos WHERE nombre = :nombre");
            $check->bindValue(':nombre', $nombre);
            $check->execute();
            $existe = $check->fetchColumn();

            if ($existe > 0) {
                echo '<div class="alert alert-warning">El producto ya existe en la base de datos.</div>';
                echo '<a href="producto.php" class="btn btn-secondary">Volver al formulario</a>';
            } else {
                $query = $cnx->prepare(
                    "INSERT INTO productos (nombre, precio, img_path, descripcion)
                     VALUES (:nombre, :precio, :img_path, :descripcion)"
                );
                $query->bindValue(':nombre', $nombre);
                $query->bindValue(':precio', $precio);
                $query->bindValue(':img_path', $imagen);
                $query->bindValue(':descripcion', $descripcion);

                $insertado = $query->execute();

                if ($insertado) {
                    echo '<div class="alert alert-success">Producto registrado exitosamente.</div>';
                    echo '<a href="listado_producto.php" class="btn btn-primary">Ver productos</a>';
                } else {
                    echo '<div class="alert alert-danger">Error al registrar el producto.</div>';
                    echo '<a href="producto.php" class="btn btn-secondary">Volver al formulario</a>';
                }
            }
        } catch (PDOException $e) {
            echo '<div class="alert alert-danger">Error en la base de datos: ' . htmlspecialchars($e->getMessage()) . '</div>';
            echo '<a href="producto.php" class="btn btn-secondary">Volver al formulario</a>';
        }
    }
    ?>
  </div>
</body>
</html>
