<?php
session_start();
require 'conexion.php';

$usuario = $_POST["usuario"] ?? '';
$password = $_POST["password"] ?? '';

$login_exitoso = false;
$mensaje = "";

if ($usuario === '' || $password === '') {
    $mensaje = "Por favor completa todos los campos.";
} else {
    try {
        $query = $cnx->prepare("SELECT * FROM empleados WHERE usuario = :usuario");
        $query->bindValue(':usuario', $usuario);
        $query->execute();
        $empleado = $query->fetch(PDO::FETCH_ASSOC);

        if ($empleado && $empleado['password'] === $password) {
            $_SESSION['id'] = $empleado['id_empleado'];
            $_SESSION['usuario'] = $empleado['usuario'];
            $_SESSION['rol'] = $empleado['rol'];
            $login_exitoso = true;

            //reidirige segun el rol
            if ($empleado['rol'] === 'encargado') {
                header("Location: index.php"); //encargado
            } else {
                header("Location: cocinero.php"); //empleados normales
            }
            exit();
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }
    } catch (PDOException $e) {
        $mensaje = "Error en la base de datos: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado de Login Empleados</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Roboto', sans-serif;
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #000000 50%, #ffcc00 50%);
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      overflow: hidden;
    }

    .container-box {
      position: relative;
      z-index: 2;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #ffffff;
      border-radius: 18px;
      box-shadow: 0 6px 25px rgba(0,0,0,0.3);
      overflow: hidden;
      max-width: 700px;
      width: 90%;
    }

    .logo-side {
      flex: 1;
      text-align: center;
      padding: 40px;
    }

    .form-side {
      flex: 1;
      padding: 40px;
      text-align: center;
    }

    .logo-circle {
      width: 90px;
      height: 90px;
      border: 4px solid #ffcc00;
      border-radius: 50%;
      color: #ffcc00;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      font-size: 26px;
      margin: 0 auto 10px;
    }

    h1, h2 {
      color: #ffcc00;
      font-weight: bold;
      margin-bottom: 25px;
    }

    .alert-box {
      text-align: center;
      padding: 20px 0;
    }

    .btn-return {
      margin-top: 20px;
      width: 100%;
      font-weight: bold;
      border-radius: 50px;
      padding: 12px 30px;
      text-decoration: none;
      display: inline-block;
      transition: 0.3s;
    }

    .btn-return-primary {
      background-color: #ffcc00;
      color: #000;
      border: none;
    }

    .btn-return-primary:hover {
      background-color: #e6b800;
    }

    .btn-return-secondary {
      background-color: #fff;
      border: 1px solid #ccc;
      color: #333;
    }

    .btn-return-secondary:hover {
      background-color: #f5f5f5;
    }

    @media (max-width: 768px) {
      body {
        background: linear-gradient(180deg, #000 40%, #ffcc00 60%);
      }
      .container-box {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>
  <div class="container-box">
    <div class="logo-side">
      <div class="logo-circle">McK</div>
      <h1>McKing Empleados</h1>
    </div>

    <div class="form-side">
      <h2>Resultado de Login</h2>
      <div class="alert-box">
        <?php if ($login_exitoso): ?>
          <div class="alert alert-success" role="alert">
            ¡Inicio exitoso! Bienvenido, <?= htmlspecialchars($usuario) ?>.
          </div>
        <?php else: ?>
          <div class="alert alert-danger" role="alert">
            <?= htmlspecialchars($mensaje) ?>
          </div>
          <a href="login-empleado.html" class="btn-return btn-return-secondary">Volver al Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>
