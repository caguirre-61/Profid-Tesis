<?php
session_start();

// Configuración de la base de datos (descomentar cuando la conectes)
/*
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "profid_obras";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
*/

$mensaje = "";
$tipo_mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo_cuenta = $_POST['tipo_cuenta'] ?? 'vendedor';

    if ($tipo_cuenta === 'vendedor') {
        $nombre   = trim($_POST['reg_nombre'] ?? '');
        $email    = trim($_POST['reg_email'] ?? '');
        $cuit     = trim($_POST['reg_cuit'] ?? '');
        $password = $_POST['reg_password'] ?? '';

        if (empty($nombre) || empty($email) || empty($cuit) || empty($password)) {
            $mensaje = "Por favor, completa todos los campos obligatorios.";
            $tipo_mensaje = "error";
        } else {
            // Lógica de inserción vendedor simple...
            /*
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO vendedores (nombre, email, cuit, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nombre, $email, $cuit, $password_hash);
            $stmt->execute();
            */

            // Redirección al panel del vendedor
            header("Location: panel-vendedor-trabajos.html");
            exit;
        }
    } else {
        // Datos de Empresa / Comercio
        $razon_social   = trim($_POST['emp_razon_social'] ?? '');
        $tipo_juridico  = trim($_POST['emp_tipo_juridico'] ?? '');
        $objeto_social  = trim($_POST['emp_objeto_social'] ?? '');
        $cuit_empresa   = trim($_POST['emp_cuit'] ?? '');
        $domicilio      = trim($_POST['emp_domicilio'] ?? '');
        $email_contacto = trim($_POST['emp_email'] ?? '');
        $telefono       = trim($_POST['emp_telefono'] ?? '');
        $capital_social = trim($_POST['emp_capital'] ?? '');

        // Datos del Titular / Socio
        $socio_nombre     = trim($_POST['socio_nombre'] ?? '');
        $socio_cuit       = trim($_POST['socio_cuit'] ?? '');
        $socio_dni        = trim($_POST['socio_dni'] ?? '');
        $socio_porcentaje = trim($_POST['socio_porcentaje'] ?? '');
        $password         = $_POST['emp_password'] ?? '';

        if (empty($razon_social) || empty($cuit_empresa) || empty($email_contacto) || empty($password)) {
            $mensaje = "Por favor, completa los datos principales de la empresa.";
            $tipo_mensaje = "error";
        } else {
            /* 
            // REGISTRO EN BD (Ejemplo):
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO empresas (razon_social, tipo_juridico, objeto_social, cuit, domicilio, email, telefono, capital_social, socio_nombre, socio_cuit, socio_dni, socio_porcentaje, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssssssss", $razon_social, $tipo_juridico, $objeto_social, $cuit_empresa, $domicilio, $email_contacto, $telefono, $capital_social, $socio_nombre, $socio_cuit, $socio_dni, $socio_porcentaje, $password_hash);
            $stmt->execute();
            */

            header("Location: index.html");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ProFid - Alta de Proveedores y Empresas</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {
      --pf-brand-500: #0ea5e9;
      --pf-brand-600: #0284c7;
      --pf-brand-700: #0369a1;
      --pf-industrial: #0f172a;
    }
    .bg-industrial { background-color: var(--pf-industrial); }
    .bg-brand { background-color: var(--pf-brand-600); }
    .hover-bg-brand:hover { background-color: var(--pf-brand-700); }
    .text-brand { color: var(--pf-brand-500); }
    .fade-in { animation: fadeIn 0.3s ease-in-out forwards; }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(6px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 font-sans min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-2xl bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden fade-in my-8">
    
    <!-- HEADER PRO FID -->
    <div class="bg-industrial px-8 py-6 text-center border-b border-white/10">
      <div class="inline-flex items-center gap-3 justify-center mb-2">
        <div class="w-10 h-10 rounded-xl bg-brand flex items-center justify-center text-white font-extrabold text-xl shadow-lg">P</div>
        <span class="text-2xl font-black text-white tracking-wide">Pro<span class="text-brand">Fid</span></span>
      </div>
      <p class="text-xs text-gray-400 font-medium uppercase tracking-wider">Portal Oficial de Proveedores y Comercio</p>
    </div>

    <div class="p-6 md:p-8">
      
      <!-- MENSAJES DE ALERTA -->
      <?php if (!empty($mensaje)): ?>
        <div class="mb-6 p-4 rounded-xl text-xs font-semibold <?php echo $tipo_mensaje === 'error' ? 'bg-red-50 text-red-700 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'; ?>">
          <?php echo $mensaje; ?>
        </div>
      <?php endif; ?>

      <!-- SELECTOR DE TIPO DE REGISTRO -->
      <div class="mb-8">
        <label class="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 text-center">Selecciona el perfil de registro</label>
        <div class="grid grid-cols-2 gap-3">
          <button type="button" id="tab-vendedor" onclick="setTipoCuenta('vendedor')" class="p-3 border-2 border-sky-500 bg-sky-50/50 rounded-xl text-center transition-all">
            <span class="block text-sm font-bold text-sky-900">Vendedor Independiente</span>
            <span class="text-[11px] text-sky-700">Comercial / Agente</span>
          </button>
          <button type="button" id="tab-empresa" onclick="setTipoCuenta('empresa')" class="p-3 border-2 border-gray-200 bg-white rounded-xl text-center transition-all hover:border-gray-300">
            <span class="block text-sm font-bold text-gray-800">Empresa / Comercio</span>
            <span class="text-[11px] text-gray-500">Alta Comercial Completa</span>
          </button>
        </div>
      </div>

      <!-- FORMULARIO VENDEDOR INDIVIDUAL -->
      <form id="form-vendedor" action="" method="POST" class="space-y-4">
        <input type="hidden" name="tipo_cuenta" value="vendedor">
        
        <div>
          <label for="reg_nombre" class="block text-xs font-semibold text-gray-600 mb-1">Nombre y Apellido *</label>
          <input type="text" id="reg_nombre" name="reg_nombre" required placeholder="Juan Pérez" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label for="reg_cuit" class="block text-xs font-semibold text-gray-600 mb-1">CUIT / CUIL *</label>
            <input type="text" id="reg_cuit" name="reg_cuit" required placeholder="20-12345678-9" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
          </div>
          <div>
            <label for="reg_email" class="block text-xs font-semibold text-gray-600 mb-1">Correo Electrónico *</label>
            <input type="email" id="reg_email" name="reg_email" required placeholder="vendedor@email.com" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
          </div>
        </div>

        <div>
          <label for="reg_password" class="block text-xs font-semibold text-gray-600 mb-1">Contraseña *</label>
          <input type="password" id="reg_password" name="reg_password" required placeholder="Crea una contraseña" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500">
        </div>

        <button type="submit" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-lg transition-colors text-sm shadow-md mt-4">
          Completar Registro Vendedor
        </button>
      </form>

      <!-- FORMULARIO EMPRESA / COMERCIO -->
      <form id="form-empresa" action="" method="POST" class="space-y-6 hidden">
        <input type="hidden" name="tipo_cuenta" value="empresa">

        <!-- SECCIÓN 1: DATOS BÁSICOS -->
        <div>
          <h3 class="text-xs font-bold text-sky-600 uppercase tracking-wider mb-3 border-b border-gray-200 pb-1">1. Datos Básicos de la Empresa</h3>
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Razón Social *</label>
                <input type="text" name="emp_razon_social" required placeholder="Corralón San Martín S.A." class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Tipo Jurídico *</label>
                <select name="emp_tipo_juridico" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500 bg-white">
                  <option value="Monotributo / Autónomo">Persona Humana (Monotributo / Autónomo)</option>
                  <option value="SRL">Sociedad de Resp. Ltda. (S.R.L.)</option>
                  <option value="SA">Sociedad Anónima (S.A.)</option>
                  <option value="SAS">Soc. por Acciones Simplificada (S.A.S.)</option>
                  <option value="Otro">Otro Tipo Societario</option>
                </select>
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">CUIT Comercial *</label>
                <input type="text" name="emp_cuit" required placeholder="30-12345678-9" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Capital Social Inicial ($) *</label>
                <input type="number" step="0.01" name="emp_capital" placeholder="Ej: 500000" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
            </div>

            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1">Objeto Social / Actividad Principal *</label>
              <textarea name="emp_objeto_social" rows="2" placeholder="Descripción detallada de la actividad económica..." class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500"></textarea>
            </div>

            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1">Domicilio Fiscal y Legal *</label>
              <input type="text" name="emp_domicilio" placeholder="Av. Corrientes 1234, CABA" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
            </div>
          </div>
        </div>

        <!-- SECCIÓN 2: CONTACTO -->
        <div>
          <h3 class="text-xs font-bold text-sky-600 uppercase tracking-wider mb-3 border-b border-gray-200 pb-1">2. Contacto Oficial</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1">Correo Electrónico Institucional *</label>
              <input type="email" name="emp_email" required placeholder="contacto@empresa.com" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
            </div>
            <div>
              <label class="block text-xs font-semibold text-gray-600 mb-1">Teléfono / Celular Oficial *</label>
              <input type="text" name="emp_telefono" placeholder="+54 11 1234-5678" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
            </div>
          </div>
        </div>

        <!-- SECCIÓN 3: DATOS DEL SOCIO O TITULAR -->
        <div>
          <h3 class="text-xs font-bold text-sky-600 uppercase tracking-wider mb-3 border-b border-gray-200 pb-1">3. Socio / Titular Principal</h3>
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Nombre Completo del Titular *</label>
                <input type="text" name="socio_nombre" placeholder="Nombre y Apellido" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">DNI del Titular *</label>
                <input type="text" name="socio_dni" placeholder="12.345.678" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">CUIT / CUIL Personal *</label>
                <input type="text" name="socio_cuit" placeholder="20-12345678-9" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">% Participación Societaria *</label>
                <input type="number" min="1" max="100" name="socio_porcentaje" placeholder="Ej: 50%" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
              </div>
            </div>
          </div>
        </div>

        <!-- ACCESO -->
        <div>
          <h3 class="text-xs font-bold text-sky-600 uppercase tracking-wider mb-3 border-b border-gray-200 pb-1">4. Credenciales de Acceso</h3>
          <div>
            <label class="block text-xs font-semibold text-gray-600 mb-1">Contraseña de Administrador de Empresa *</label>
            <input type="password" name="emp_password" required placeholder="Creá una contraseña segura" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-sky-500">
          </div>
        </div>

        <button type="submit" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-lg transition-colors text-sm shadow-md">
          Registrar Empresa y Solicitar Alta
        </button>
      </form>

      <!-- ENLACE A LOGIN -->
      <div class="mt-6 text-center text-xs text-gray-500">
        ¿Ya tenés una cuenta registrada? 
        <a href="login-vendedor.php" class="text-sky-600 font-bold hover:underline">Iniciar Sesión</a>
      </div>
    </div>

    <!-- PIE DE PÁGINA -->
    <div class="bg-slate-50 px-6 py-4 border-t border-gray-200 text-center text-xs text-gray-400">
      Plataforma de Gestión ProFid &copy; 2026
    </div>

  </div>

  <script>
    function setTipoCuenta(tipo) {
      const formVendedor = document.getElementById('form-vendedor');
      const formEmpresa = document.getElementById('form-empresa');
      const tabVendedor = document.getElementById('tab-vendedor');
      const tabEmpresa = document.getElementById('tab-empresa');

      if (tipo === 'vendedor') {
        formVendedor.classList.remove('hidden');
        formEmpresa.classList.add('hidden');

        tabVendedor.className = 'p-3 border-2 border-sky-500 bg-sky-50/50 rounded-xl text-center transition-all';
        tabEmpresa.className = 'p-3 border-2 border-gray-200 bg-white rounded-xl text-center transition-all hover:border-gray-300';
      } else {
        formVendedor.classList.add('hidden');
        formEmpresa.classList.remove('hidden');

        tabEmpresa.className = 'p-3 border-2 border-sky-500 bg-sky-50/50 rounded-xl text-center transition-all';
        tabVendedor.className = 'p-3 border-2 border-gray-200 bg-white rounded-xl text-center transition-all hover:border-gray-300';
      }
    }
  </script>

</body>
</html>