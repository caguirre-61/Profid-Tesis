<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php"); // Redirigir si no hay sesión
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>McKing - Inicio</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      overflow-x: hidden;
    }

    header {
      background-color: #ffc107;
      padding: 20px 60px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
      z-index: 10;
    }

    .logo {
      display: flex;
      align-items: center;
      font-size: 28px;
      font-weight: bold;
      color: #000;
    }

    nav span {
      color: #000;
      font-weight: bold;
    }

    main {
      position: relative;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 100px 80px;
      min-height: 90vh;
      background-color: #111;
      overflow: hidden;
    }

    .content {
      flex: 1;
      z-index: 2;
      max-width: 500px;
    }

    .content h1 {
      font-size: 70px;
      font-weight: bold;
      color: #ffc107;
      margin-bottom: 20px;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .content p {
      font-size: 20px;
      color: #fff;
      margin-bottom: 40px;
      line-height: 1.6;
    }

    .btns {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .btn-mck {
      display: inline-block;
      background-color: #000;
      color: #ffc107;
      padding: 15px 35px;
      font-size: 18px;
      font-weight: bold;
      border-radius: 50px;
      border: 2px solid #ffc107;
      cursor: pointer;
      text-decoration: none;
      text-align: center;
      transition: 0.3s;
    }

    .btn-mck:hover {
      background-color: #ffc107;
      color: #000;
      transform: scale(1.05);
    }

    .image {
      flex: 1.3;
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      z-index: 2;
    }

    .image img {
      width: 100%;
      max-width: 600px;
      border-radius: 20px;
      transition: transform 0.3s ease;
    }

    .image img:hover {
      transform: scale(1.05);
    }

    .wave-bg {
      position: absolute;
      bottom: -40px;
      left: 0;
      width: 100%;
      z-index: 1;
    }

    @media screen and (max-width: 992px) {
      main {
        flex-direction: column;
        text-align: center;
        padding: 60px 20px;
      }

      .content {
        margin-bottom: 40px;
      }

      .content h1 {
        font-size: 50px;
      }

      .image img {
        width: 90%;
      }
    }
  </style>
</head>
<body>

  <header>
    <div class="logo">McKing</div>
    <nav>
      <span>Hola, <?= htmlspecialchars($_SESSION['usuario']) ?></span>
    </nav>
  </header>

  <main>
    <div class="content">
      <h1>Hola Admin</h1>
      
      <div class="btns">
        <a href="producto.php" class="btn-mck">Insertar Producto</a>
        <a href="listado.php" class="btn-mck">Empleados</a>
        <a href="listado_producto.php" class="btn-mck">Listado Productos</a>
        <a href="../login-principal.html" class="btn-mck" style="background-color:#e63946; border-color:#e63946;">Cerrar Sesión</a>
      </div>
    </div>

    <div class="image">
      <img src="./img/ham15.png" alt="Hamburguesa McKing">
    </div>

    <svg class="wave-bg" viewBox="0 0 1440 320">
      <path fill="#ffc107" fill-opacity="1" d="M0,288L80,256C160,224,320,160,480,170.7C640,181,800,267,960,282.7C1120,299,1280,245,1360,218.7L1440,192L1440,320L0,320Z"></path>
    </svg>
  </main>

</body>
</html>
