<?php
require 'conexion.php';

$id_empleado = $_POST['id_empleado'] ?? null;
$nombre = $_POST['nombre'] ?? '';
$usuario = $_POST['usuario'] ?? '';
$password = $_POST['password'] ?? '';
$rol = $_POST['rol'] ?? '';

if (!$id_empleado) {
    die("Error: no se especificó el empleado a modificar.");
}

// Actualizar datos
$consulta = $cnx->prepare("
    UPDATE empleados 
    SET nombre = :nombre, usuario = :usuario, password = :password, rol = :rol 
    WHERE id_empleado = :id_empleado
");

$consulta->bindValue(':id_empleado', $id_empleado, PDO::PARAM_INT);
$consulta->bindValue(':nombre', $nombre);
$consulta->bindValue(':usuario', $usuario);
$consulta->bindValue(':password', $password); // ideal: usar password_hash()
$consulta->bindValue(':rol', $rol);

$validacion = $consulta->execute();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado - Modificación Empleado</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Montserrat', sans-serif; background-color: #000; color: #fff; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 40px 20px; }
    .container-box { background-color: #111; border-radius: 18px; border: 2px solid #ffc107; max-width: 500px; width: 100%; padding: 30px 40px; box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4); text-align: center; }
    h2 { color: #ffc107; font-weight: bold; margin-bottom: 25px; }
    .alert-success, .alert-danger { border-radius: 12px; padding: 15px 20px; font-weight: 600; margin-bottom: 25px; }
    .alert-success { background-color: #2d4d1a; color: #c3e88d; border: 1px solid #9ccc65; }
    .alert-danger { background-color: #5a1e1e; color: #f9b3b3; border: 1px solid #f28b8b; }
    a.btn { display: inline-block; font-weight: bold; padding: 12px 30px; border-radius: 50px; text-decoration: none; transition: background-color 0.3s ease; margin-top: 10px; }
    a.btn-primary { background-color: #ffc107; color: #000; }
    a.btn-primary:hover { background-color: #e6b006; }
  </style>
</head>
<body>
  <div class="container-box">
    <h2>Resultado de la modificación</h2>

    <?php if ($validacion): ?>
      <div class="alert alert-success">Empleado modificado correctamente.</div>
    <?php else: ?>
      <div class="alert alert-danger">Hubo un error al modificar el empleado.</div>
    <?php endif; ?>

    <a href="listado.php" class="btn btn-primary">Volver al listado</a>
  </div>
</body>
</html>
