<?php
require 'conexion.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    die("Error: no se especificó el producto a modificar.");
}

// Obtener datos actuales del producto
$stmt = $cnx->prepare("SELECT * FROM productos WHERE id_producto = :id");
$stmt->bindValue(':id', $id, PDO::PARAM_INT);
$stmt->execute();
$producto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$producto) {
    die("Error: producto no encontrado.");
}

// Procesar actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $precio = $_POST['precio'] ?? '';
    $img_path = $_POST['img_path'] ?? '';

    $update = $cnx->prepare("
        UPDATE productos 
        SET nombre = :nombre, precio = :precio, img_path = :img_path 
        WHERE id_producto = :id
    ");
    $update->bindValue(':nombre', $nombre);
    $update->bindValue(':precio', $precio);
    $update->bindValue(':img_path', $img_path);
    $update->bindValue(':id', $id, PDO::PARAM_INT);

    $success = $update->execute();
    $mensaje = $success ? "Producto modificado correctamente." : "Error al modificar el producto.";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Modificar Producto</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
  background-color: #000;
  color: #fff;
  font-family: 'Montserrat', sans-serif;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.container-box {
  background-color: #111;
  border: 2px solid #ffc107;
  border-radius: 20px;
  padding: 40px;
  box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
  width: 400px;
}

h2 {
  color: #ffc107;
  text-align: center;
  font-weight: bold;
  margin-bottom: 30px;
}

.form-control {
  border-radius: 10px;
  border: 2px solid #ffc107;
  background-color: #222;
  color: #fff;
  display: block;
  width: 100%;
  margin-bottom: 15px;
  padding: 10px;
}

.btn-primary {
  background-color: #ffc107;
  border: none;
  color: #000;
  font-weight: bold;
  width: 100%;
  border-radius: 50px;
  padding: 10px;
  cursor: pointer;
}

.btn-primary:hover {
  background-color: #e6b006;
}

.alert {
  padding: 12px;
  border-radius: 12px;
  text-align: center;
  margin-bottom: 20px;
}

.success {
  background-color: #2d4d1a;
  color: #c3e88d;
  border: 1px solid #9ccc65;
}

.error {
  background-color: #5a1e1e;
  color: #f9b3b3;
  border: 1px solid #f28b8b;
}

a {
  text-decoration: none;
  color: #ffc107;
  display: block;
  text-align: center;
  margin-top: 15px;
}

a:hover {
  color: #fff;
}
</style>
</head>
<body>
<div class="container-box">
<h2>Modificar Producto</h2>

<?php if (isset($mensaje)): ?>
    <div class="alert <?= $success ? 'success' : 'error' ?>"><?= $mensaje ?></div>
<?php endif; ?>

<form method="post" action="verificacion-modificar.php">
  <input type="hidden" name="id_producto" value="<?= htmlspecialchars($producto['id_producto'])?>">
    <label>Nombre</label>
    <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($producto['nombre']) ?>" required>
    
    <label>Precio</label>
    <input type="number" step="0.01" name="precio" class="form-control" value="<?= htmlspecialchars($producto['precio']) ?>" required>
    
    <label>Ruta de la imagen</label>
    <input type="text" name="img_path" class="form-control" value="<?= htmlspecialchars($producto['img_path']) ?>" required>

    <div class="mb-3">
     <label class="form-label">Descripción</label>
      <textarea name="descripcion" class="form-control" rows="4" required><?= htmlspecialchars($producto['descripcion']) ?></textarea>
    </div>

    <button type="submit" class="btn-primary">Guardar cambios</button>
</form>

<a href="listado_producto.php">Volver al listado</a>
</div>
</body>
</html>
