<?php
// api/chat_asistente.php
ini_set('display_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

// Colocá tu API Key limpia de Google AI Studio (empieza con AIzaSy...)
$apiKey = 'AQ.Ab8RN6Kbb9Q-Z6pNEMauIKHZ9YYkJB9A5tolrHnCQpGzda9aYA';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$userMessage = trim($input['mensaje'] ?? '');
$history = $input['historial'] ?? [];

if (empty($userMessage)) {
    http_response_code(400);
    echo json_encode(['error' => 'El mensaje no puede estar vacío.']);
    exit;
}

// System Instruction para darle personalidad y conocimiento del sistema ProFid
$systemInstruction = "Eres ProFid Bot, el asistente virtual experto de ProFid, una plataforma de gestión de presupuestos y carga inteligente de facturas para obras de construcción.
Tus responsabilidades son:
1. Orientar al usuario sobre cómo cargar sus facturas usando el módulo de Carga IA (pueden subir PDF o imágenes PNG/JPG/WEBP o cargarlos manualmente).
2. Explicar cómo funciona el Dashboard de Obra (Presupuesto total, Gasto real ejecutado, Saldo disponible, Partidas de obra).
3. Explicar el Catálogo Unificado de Insumos (agrupa precios y proveedores sin duplicados).
4. Responder dudas sobre unidades de medida permitidas: bolsa, kg, m3, unidad, barra, litro.
Responde de forma concisa, clara, profesional y amable en idioma español.";

// Formatear el historial para el API de Gemini
$contents = [];

// Instrucción inicial
$contents[] = [
    "role" => "user",
    "parts" => [["text" => $systemInstruction]]
];
$contents[] = [
    "role" => "model",
    "parts" => [["text" => "Entendido. Soy ProFid Bot, el asistente virtual experto de la plataforma. ¿En qué puedo ayudarte hoy?"]]
];

// Agregar historial previo si existe
foreach ($history as $msg) {
    $role = ($msg['sender'] === 'user') ? 'user' : 'model';
    $contents[] = [
        "role" => $role,
        "parts" => [["text" => $msg['text']]]
    ];
}

// Agregar mensaje actual
$contents[] = [
    "role" => "user",
    "parts" => [["text" => $userMessage]]
];

$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=" . $apiKey;

$payload = [
    "contents" => $contents,
    "generationConfig" => [
        "temperature" => 0.4,
        "maxOutputTokens" => 500
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$apiResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(500);
    echo json_encode(['error' => 'Error cURL: ' . $curlError]);
    exit;
}

if ($httpCode !== 200) {
    http_response_code(500);
    $errorJson = json_decode($apiResponse, true);
    $detalleMsg = $errorJson['error']['message'] ?? 'Error de respuesta de la IA';
    echo json_encode(['error' => "Error ($httpCode): " . $detalleMsg]);
    exit;
}

$result = json_decode($apiResponse, true);
$reply = $result['candidates'][0]['content']['parts'][0]['text'] ?? 'No pude procesar tu consulta en este momento.';

echo json_encode(['respuesta' => $reply]);