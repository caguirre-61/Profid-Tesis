<?php
/**
 * Configuración de conexión a la Base de Datos (MySQL / phpMyAdmin)
 * Utilizando PDO (PHP Data Objects) para mayor seguridad y manejo de errores.
 */

// -----------------------------------------------------------------------------
// 1. PARÁMETROS DE CONFIGURACIÓN
// -----------------------------------------------------------------------------
// En un entorno local con XAMPP / WAMP / MAMP, los valores por defecto suelen ser:
// Host: '127.0.0.1' o 'localhost'
// Usuario: 'root'
// Contraseña: '' (vacío en XAMPP local) o 'root' (en MAMP / algunos entornos)

$host     = 'localhost';      // Servidor de la base de datos
$db_name  = 'u214138677_profid'; // ¡Cambia esto por el nombre de tu BD en phpMyAdmin!
$username = 'u214138677_profid';           // Usuario de MySQL
$password = '';               // Contraseña de MySQL (vacío por defecto en XAMPP)
$charset  = 'utf8mb4';        // Juego de caracteres (soporta emojis y caracteres especiales)
$port     = 3306;             // Puerto MySQL por defecto

// -----------------------------------------------------------------------------
// 2. CREACIÓN DE LA CONEXIÓN (PDO)
// -----------------------------------------------------------------------------
$dsn = "mysql:host={$host};port={$port};dbname={$db_name};charset={$charset}";

$options = [
    // Lanza excepciones cuando ocurren errores en la base de datos
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    // Devuelve los resultados como arrays asociativos por defecto
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    // Desactiva la emulación de consultas preparadas para mayor seguridad contra Inyección SQL
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Instanciar la conexión PDO
    $pdo = new PDO($dsn, $username, $password, $options);
    
    // Opcional: Mensaje de confirmación para pruebas (descomentar si deseas verificar en pantalla)
    // echo "Conexión exitosa a la base de datos.";
    
} catch (PDOException $e) {
    // Si la conexión falla, se captura el error de forma segura sin exponer credenciales sensibles
    die("Error al conectar a la base de datos: " . $e->getMessage());
}

/**
 * Función helper opcional para obtener la instancia de conexión en otros archivos
 * 
 * Uso en otros scripts:
 * require_once 'conexion.php';
 * $db = obtenerConexion();
 */
function obtenerConexion() {
    global $pdo;
    return $pdo;
}