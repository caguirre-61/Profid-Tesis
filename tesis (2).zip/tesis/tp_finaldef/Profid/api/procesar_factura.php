<?php
// Silenciar salidas HTML automáticas para garantizar que la respuesta sea un JSON válido
ini_set('display_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

// 1. Clave API de Google AI Studio (Asegúrate de colocar tu clave real que empiece por AIzaSy...)
$apiKey = 'AQ.Ab8RN6Kbb9Q-Z6pNEMauIKHZ9YYkJB9A5tolrHnCQpGzda9aYA'; 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// 2. Validar que se haya enviado el archivo
if (!isset($_FILES['factura']) || $_FILES['factura']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'No se subió ningún archivo o hubo un error en la carga']);
    exit;
}

$file = $_FILES['factura'];
$filePath = $file['tmp_name'];
$mimeType = mime_content_type($filePath);

// 3. Validar tipo de archivo
$allowedMimes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
if (!in_array($mimeType, $allowedMimes)) {
    http_response_code(400);
    echo json_encode(['error' => 'Formato no soportado. Subí un PDF o una imagen (PNG, JPG, WEBP)']);
    exit;
}

// 4. Convertir archivo a Base64
$fileData = base64_encode(file_get_contents($filePath));

// 5. Prompt estructurado para Gemini
$prompt = "Analiza este comprobante/factura de compra de materiales de construcción y extrae los siguientes datos en formato JSON estricto:
- proveedor (nombre de la empresa o vendedor)
- fecha (formato YYYY-MM-DD)
- insumo (descripción corta del material principal)
- unidad (debe ser uno de estos valores exactos: 'bolsa', 'kg', 'm3', 'unidad', 'barra', 'litro')
- cantidad (número flotante o entero)
- precio_unitario (número flotante o entero, valor unitario del insumo sin símbolos de moneda)

Responde ÚNICAMENTE con el objeto JSON.";

// 6. Endpoint de la API de Gemini (Uso del modelo rápido multimodal gemini-2.5-flash)
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=" . $apiKey;

$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $prompt],
                [
                    "inline_data" => [
                        "mime_type" => $mimeType,
                        "data" => $fileData
                    ]
                ]
            ]
        ]
    ],
    "generationConfig" => [
        "temperature" => 0.1,
        "response_mime_type" => "application/json"
    ]
];

// 7. Petición HTTP nativa con cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Evita bloqueos SSL en entornos locales (XAMPP)

$apiResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// Diagnóstico si la petición cURL falla a nivel de red
if ($curlError) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión cURL en PHP: ' . $curlError]);
    exit;
}

// Diagnóstico si Gemini responde con un código distinto a 200 (ej. clave de API inválida)
if ($httpCode !== 200) {
    http_response_code(500);
    $errorJson = json_decode($apiResponse, true);
    $detalleMsg = $errorJson['error']['message'] ?? 'Error no especificado por la API';
    echo json_encode(['error' => "Gemini API Error ($httpCode): " . $detalleMsg]);
    exit;
}

// 8. Decodificación y retorno del resultado
$result = json_decode($apiResponse, true);
$rawJsonText = $result['candidates'][0]['content']['parts'][0]['text'] ?? null;

if ($rawJsonText) {
    $parsedData = json_decode($rawJsonText, true);
    if ($parsedData) {
        echo json_encode($parsedData);
        exit;
    }
}

http_response_code(500);
echo json_encode(['error' => 'No se pudieron extraer los datos del comprobante. Intenta con una imagen más clara.']);