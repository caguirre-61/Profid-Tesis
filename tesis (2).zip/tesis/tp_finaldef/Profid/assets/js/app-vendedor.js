/* =========================================================================

   PROFID · APLICACIÓN Y CONTROLADOR DEL DASHBOARD (ES MODULE)

   ========================================================================= */



// 1. CONSTANTES Y PERSISTENCIA DE DATOS

const LS_PRODUCTS = 'pf_vendedor_products';

const LS_DOCS = 'pf_vendedor_docs';



const CATEGORY_COLORS = {

  'Cemento y Áridos': '#5AA9D6',

  'Hierro y Aceros': '#E8A33D',

  'Ladrillos y Bloques': '#18517C',

  'Aislantes e Impermeabilizantes': '#1F9D64',

  'Pinturas': '#94A3B8',

  'Otros': '#64748B'

};



function seedProducts() {

  const fechas = ['2026-04-02', '2026-05-02', '2026-06-02', '2026-07-02', '2026-08-02', '2026-09-02'];

  const mk = (precios) => fechas.map((f, i) => ({ date: f, precio: precios[i] }));

  return [

    { id: crypto.randomUUID(), nombre: 'Cemento Portland x50kg', categoria: 'Cemento y Áridos', unidad: 'bolsa', proveedor: 'Loma Negra', precio: 10200, history: mk([8200, 8700, 9150, 9500, 9800, 10200]) },

    { id: crypto.randomUUID(), nombre: 'Hierro del 8 x12m', categoria: 'Hierro y Aceros', unidad: 'barra', proveedor: 'Aceros del Litoral', precio: 14200, history: mk([11800, 12300, 12900, 13500, 13900, 14200]) },

    { id: crypto.randomUUID(), nombre: 'Ladrillo hueco 18x18x33', categoria: 'Ladrillos y Bloques', unidad: 'unidad', proveedor: 'Ladrillera Don Pedro', precio: 650, history: mk([480, 510, 540, 580, 610, 650]) },

    { id: crypto.randomUUID(), nombre: 'Arena gruesa', categoria: 'Cemento y Áridos', unidad: 'm3', proveedor: 'Áridos Norte', precio: 42500, history: mk([33000, 35500, 37800, 39900, 41200, 42500]) },

    { id: crypto.randomUUID(), nombre: 'Cal hidratada x25kg', categoria: 'Cemento y Áridos', unidad: 'bolsa', proveedor: 'Cal y Cemento SRL', precio: 6200, history: mk([4800, 5100, 5400, 5700, 5950, 6200]) },

    { id: crypto.randomUUID(), nombre: 'Membrana asfáltica rollo 10m', categoria: 'Aislantes e Impermeabilizantes', unidad: 'rollo', proveedor: 'ImperTech', precio: 58500, history: mk([44000, 47500, 50800, 53900, 56200, 58500]) }

  ];

}



function loadProducts() {

  try {

    const raw = localStorage.getItem(LS_PRODUCTS);

    if (raw) return JSON.parse(raw);

  } catch (e) {

    console.error("Error cargando productos de localStorage", e);

  }

  const seeded = seedProducts();

  saveProducts(seeded);

  return seeded;

}



function saveProducts(list) {

  localStorage.setItem(LS_PRODUCTS, JSON.stringify(list));

}



function loadDocs() {

  try {

    const raw = localStorage.getItem(LS_DOCS);

    if (raw) return JSON.parse(raw);

  } catch (e) {

    console.error("Error cargando documentos de localStorage", e);

  }

  return [];

}



function saveDocs(list) {

  try {

    localStorage.setItem(LS_DOCS, JSON.stringify(list));

  } catch (e) {

    showToast('⚠️', 'No se pudieron guardar todos los archivos (límite de almacenamiento)');

  }

}



// Estado local de la aplicación

const state = {

  products: loadProducts(),

  docs: loadDocs(),

  activeTab: 'dashboard',

  pendingDelete: null

};



// 2. UTILIDADES Y FORMATO

function fmtMoney(n) {

  return '$' + Math.round(n).toLocaleString('es-AR');

}



function fmtDate(d) {

  const dt = new Date(d + 'T00:00:00');

  return dt.toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' });

}



let toastTimer = null;

function showToast(icon, text) {

  const t = document.getElementById('toast');

  const tIcon = document.getElementById('toast-icon');

  const tText = document.getElementById('toast-text');

  if (!t || !tIcon || !tText) return;



  tIcon.textContent = icon;

  tText.textContent = text;

  t.classList.remove('opacity-0', 'pointer-events-none');

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => t.classList.add('opacity-0', 'pointer-events-none'), 2600);

}



function trendOf(product) {

  const h = product.history;

  if (!h || h.length < 2) return { dir: 'flat', pct: 0 };

  const prev = h[h.length - 2].precio, last = h[h.length - 1].precio;

  if (prev === 0) return { dir: 'flat', pct: 0 };

  const pct = ((last - prev) / prev) * 100;

  if (pct > 0.05) return { dir: 'up', pct };

  if (pct < -0.05) return { dir: 'down', pct };

  return { dir: 'flat', pct };

}



// 3. NAVEGACIÓN Y PESTAÑAS

const TAB_META = {

  dashboard: { title: 'PRECIOS DE MERCADO', sub: 'Evolución de precios de tu catálogo' },

  productos: { title: 'MIS PRODUCTOS', sub: 'Cargá y actualizá el catálogo de tu empresa' },

  documentos: { title: 'DOCUMENTOS', sub: 'Facturas y listas de precios de tu empresa' }

};



function setTab(tab) {

  state.activeTab = tab;

  document.querySelectorAll('[data-tab]').forEach(btn => {

    btn.classList.toggle('active', btn.dataset.tab === tab);

  });

  ['dashboard', 'productos', 'documentos'].forEach(t => {

    const el = document.getElementById('tab-' + t);

    if (el) el.classList.toggle('hidden-view', t !== tab);

  });



  const titleEl = document.getElementById('topbar-title');

  const subEl = document.getElementById('topbar-subtitle');

  const mobileNav = document.getElementById('mobile-nav');



  if (titleEl) titleEl.textContent = TAB_META[tab].title;

  if (subEl) subEl.textContent = TAB_META[tab].sub;

  if (mobileNav) mobileNav.value = tab;



  if (tab === 'dashboard') refreshCharts();

}



// 4. LÓGICA DE PRODUCTOS

function renderProducts() {

  const body = document.getElementById('productos-body');

  const searchInput = document.getElementById('productos-search');

  if (!body) return;



  const search = searchInput ? searchInput.value.trim().toLowerCase() : '';

  const list = state.products.filter(p => p.nombre.toLowerCase().includes(search) || p.categoria.toLowerCase().includes(search));

 

  const emptyEl = document.getElementById('productos-empty');

  if (emptyEl) emptyEl.classList.toggle('hidden-view', state.products.length !== 0);



  body.innerHTML = list.map(p => {

    const tr = trendOf(p);

    const color = CATEGORY_COLORS[p.categoria] || 'var(--pf-gray-500)';

    const trendClass = tr.dir === 'up' ? 'trend-up' : tr.dir === 'down' ? 'trend-down' : 'trend-flat';

    const trendIcon = tr.dir === 'up' ? '▲' : tr.dir === 'down' ? '▼' : '—';

    const isDeleting = state.pendingDelete === p.id;

    return `

      <tr class="hover:bg-gray-50">

        <td class="py-3 px-4 font-medium text-slate-700">${p.nombre}${p.proveedor ? `<div class="text-xs text-gray-400">${p.proveedor}</div>` : ''}</td>

        <td class="py-3 px-4"><span class="badge" style="background:${color}20; color:${color}">${p.categoria}</span></td>

        <td class="py-3 px-4 text-gray-500">${p.unidad}</td>

        <td class="py-3 px-4 text-right">

          <span class="edit-price-display font-semibold" data-id="${p.id}">${fmtMoney(p.precio)}</span>

          <input type="number" step="0.01" class="edit-price-input inline-input hidden-view border border-gray-300 rounded-lg px-2 py-1 text-sm text-right" data-id="${p.id}" value="${p.precio}">

        </td>

        <td class="py-3 px-4 text-right font-medium ${trendClass}">${trendIcon} ${Math.abs(tr.pct).toFixed(1)}%</td>

        <td class="py-3 px-4 text-right whitespace-nowrap">

          <button type="button" class="btn-edit-price text-xs font-semibold px-2 py-1 rounded" style="color:var(--pf-brand-600)" data-id="${p.id}">Actualizar precio</button>

          <button type="button" class="btn-save-price hidden-view text-xs font-semibold px-2 py-1 rounded" style="color:var(--pf-green)" data-id="${p.id}">Guardar</button>

          <button type="button" class="btn-delete text-xs font-semibold px-2 py-1 rounded ml-1" style="color:${isDeleting ? '#fff' : 'var(--pf-red)'}; background:${isDeleting ? 'var(--pf-red)' : 'transparent'}" data-id="${p.id}">${isDeleting ? 'Confirmar' : 'Eliminar'}</button>

        </td>

      </tr>`;

  }).join('') || '';



  // Eventos dinámicos en la tabla de productos

  body.querySelectorAll('.btn-edit-price').forEach(btn => {

    btn.addEventListener('click', () => {

      const row = btn.closest('tr');

      row.querySelector('.edit-price-display').classList.add('hidden-view');

      row.querySelector('.edit-price-input').classList.remove('hidden-view');

      row.querySelector('.btn-edit-price').classList.add('hidden-view');

      row.querySelector('.btn-save-price').classList.remove('hidden-view');

      row.querySelector('.edit-price-input').focus();

    });

  });



  body.querySelectorAll('.btn-save-price').forEach(btn => {

    btn.addEventListener('click', () => {

      const id = btn.dataset.id;

      const row = btn.closest('tr');

      const input = row.querySelector('.edit-price-input');

      const newPrice = parseFloat(input.value);

      if (isNaN(newPrice) || newPrice < 0) return;

      const product = state.products.find(p => p.id === id);

      if (!product) return;

      if (newPrice !== product.precio) {

        const today = new Date().toISOString().slice(0, 10);

        product.precio = newPrice;

        const last = product.history[product.history.length - 1];

        if (last && last.date === today) last.precio = newPrice;

        else product.history.push({ date: today, precio: newPrice });

        saveProducts(state.products);

        showToast('✔', 'Precio actualizado');

        renderProducts();

        renderDashboard();

        refreshCharts();

      } else {

        renderProducts();

      }

    });

  });



  body.querySelectorAll('.btn-delete').forEach(btn => {

    btn.addEventListener('click', () => {

      const id = btn.dataset.id;

      if (state.pendingDelete === id) {

        state.products = state.products.filter(p => p.id !== id);

        saveProducts(state.products);

        state.pendingDelete = null;

        showToast('🗑️', 'Producto eliminado');

        renderProducts();

        renderDashboard();

        renderProductSelect();

        refreshCharts();

      } else {

        state.pendingDelete = id;

        renderProducts();

      }

    });

  });

}



// 5. DASHBOARD, GRÁFICOS Y KPIS

let chartEvolucion = null, chartHoy = null;



function renderProductSelect() {

  const sel = document.getElementById('chart-producto-select');

  if (!sel) return;

  const current = sel.value;

  sel.innerHTML = state.products.map(p => `<option value="${p.id}">${p.nombre}</option>`).join('');

  if (state.products.some(p => p.id === current)) sel.value = current;

}



function drawEvolucionChart() {

  const sel = document.getElementById('chart-producto-select');

  const canvas = document.getElementById('chart-evolucion');

  if (!sel || !canvas) return;



  const product = state.products.find(p => p.id === sel.value) || state.products[0];

  const ctx = canvas.getContext('2d');

  const labels = product ? product.history.map(h => fmtDate(h.date)) : [];

  const data = product ? product.history.map(h => h.precio) : [];



  if (chartEvolucion) chartEvolucion.destroy();

  chartEvolucion = new Chart(ctx, {

    type: 'line',

    data: {

      labels, datasets: [{

        label: product ? product.nombre : 'Sin datos',

        data,

        borderColor: '#2B7FB0',

        backgroundColor: 'rgba(90,169,214,0.14)',

        fill: true, tension: .3, pointRadius: 4, pointBackgroundColor: '#18517C', borderWidth: 2

      }]

    },

    options: {

      responsive: true, maintainAspectRatio: false,

      plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => fmtMoney(c.parsed.y) } } },

      scales: { y: { ticks: { callback: (v) => '$' + v.toLocaleString('es-AR') }, grid: { color: '#EEF2F6' } }, x: { grid: { display: false } } }

    }

  });

}



function drawHoyChart() {

  const canvas = document.getElementById('chart-hoy');

  if (!canvas) return;



  const ctx = canvas.getContext('2d');

  const sorted = [...state.products].sort((a, b) => b.precio - a.precio).slice(0, 8);



  if (chartHoy) chartHoy.destroy();

  chartHoy = new Chart(ctx, {

    type: 'bar',

    data: {

      labels: sorted.map(p => p.nombre.length > 16 ? p.nombre.slice(0, 15) + '…' : p.nombre),

      datasets: [{

        data: sorted.map(p => p.precio),

        backgroundColor: sorted.map(p => CATEGORY_COLORS[p.categoria] || '#64748B'),

        borderRadius: 6

      }]

    },

    options: {

      indexAxis: 'y', responsive: true, maintainAspectRatio: false,

      plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => fmtMoney(c.parsed.x) } } },

      scales: { x: { ticks: { callback: (v) => '$' + v.toLocaleString('es-AR') }, grid: { color: '#EEF2F6' } }, y: { grid: { display: false } } }

    }

  });

}



function refreshCharts() {

  renderProductSelect();

  drawEvolucionChart();

  drawHoyChart();

}



function renderDashboard() {

  const n = state.products.length;

  const kpiProds = document.getElementById('kpi-productos');

  const kpiProm = document.getElementById('kpi-promedio');

  const kpiVar = document.getElementById('kpi-variacion');

  const kpiAct = document.getElementById('kpi-actualizado');

  const fechaHoy = document.getElementById('precios-hoy-fecha');



  if (kpiProds) kpiProds.textContent = n;

 

  const avg = n ? state.products.reduce((s, p) => s + p.precio, 0) / n : 0;

  if (kpiProm) kpiProm.textContent = fmtMoney(avg);



  const trends = state.products.map(trendOf).filter(t => t.dir !== 'flat');

  const avgVar = trends.length ? trends.reduce((s, t) => s + t.pct, 0) / trends.length : 0;

  if (kpiVar) {

    kpiVar.textContent = (avgVar >= 0 ? '+' : '') + avgVar.toFixed(1) + '%';

    kpiVar.style.color = avgVar > 0 ? 'var(--pf-amber)' : (avgVar < 0 ? 'var(--pf-green)' : 'var(--pf-gray-500)');

  }



  let lastDate = null;

  state.products.forEach(p => {

    const h = p.history[p.history.length - 1];

    if (h && (!lastDate || h.date > lastDate)) lastDate = h.date;

  });



  if (kpiAct) kpiAct.textContent = lastDate ? fmtDate(lastDate) : '-';

  if (fechaHoy) fechaHoy.textContent = 'Actualizado al ' + new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'long', year: 'numeric' });



  // Precios de hoy: tabla de detalle

  const hoy = [...state.products].sort((a, b) => b.precio - a.precio);

  const body = document.getElementById('precios-hoy-body');

  const emptyHoy = document.getElementById('precios-hoy-empty');



  if (emptyHoy) emptyHoy.classList.toggle('hidden-view', hoy.length !== 0);

  if (body) {

    body.innerHTML = hoy.map(p => {

      const tr = trendOf(p);

      const color = CATEGORY_COLORS[p.categoria] || 'var(--pf-gray-500)';

      const trendClass = tr.dir === 'up' ? 'trend-up' : tr.dir === 'down' ? 'trend-down' : 'trend-flat';

      const trendIcon = tr.dir === 'up' ? '▲' : tr.dir === 'down' ? '▼' : '—';

      return `<tr>

        <td class="py-2 pr-4 font-medium text-slate-700">${p.nombre}</td>

        <td class="py-2 pr-4"><span class="badge" style="background:${color}20; color:${color}">${p.categoria}</span></td>

        <td class="py-2 pr-4 text-gray-500">${p.unidad}</td>

        <td class="py-2 pr-4 text-right font-semibold">${fmtMoney(p.precio)}</td>

        <td class="py-2 pr-4 text-right font-medium ${trendClass}">${trendIcon} ${Math.abs(tr.pct).toFixed(1)}%</td>

      </tr>`;

    }).join('');

  }

}



// 6. GESTIÓN DE DOCUMENTOS

const MAX_INLINE_BYTES = 3 * 1024 * 1024; // 3MB



function handleFiles(fileList) {

  const files = Array.from(fileList);

  let processed = 0;

  files.forEach(file => {

    const isImage = file.type.startsWith('image/');

    const isPdf = file.type === 'application/pdf';

    if (!isImage && !isPdf) {

      showToast('⚠️', 'Solo se admiten PDF e imágenes');

      return;

    }

    const doc = {

      id: crypto.randomUUID(),

      nombre: file.name,

      tipo: isPdf ? 'pdf' : 'imagen',

      size: file.size,

      fecha: new Date().toISOString().slice(0, 10),

      dataUrl: null

    };

    if (file.size <= MAX_INLINE_BYTES) {

      const reader = new FileReader();

      reader.onload = () => {

        doc.dataUrl = reader.result;

        state.docs.unshift(doc);

        saveDocs(state.docs);

        renderDocs();

        processed++;

        if (processed === 1) showToast('✔', files.length > 1 ? 'Archivos subidos' : 'Archivo subido');

      };

      reader.readAsDataURL(file);

    } else {

      state.docs.unshift(doc);

      saveDocs(state.docs);

      renderDocs();

      showToast('✔', 'Archivo subido (vista previa no disponible por tamaño)');

    }

  });

}



function renderDocs() {

  const grid = document.getElementById('docs-grid');

  const emptyDocs = document.getElementById('docs-empty');

  if (!grid) return;



  if (emptyDocs) emptyDocs.classList.toggle('hidden-view', state.docs.length !== 0);



  grid.innerHTML = state.docs.map(d => {

    const preview = d.tipo === 'imagen' && d.dataUrl

      ? `<img src="${d.dataUrl}" class="doc-thumb rounded-t-lg" alt="${d.nombre}">`

      : `<div class="doc-thumb rounded-t-lg flex items-center justify-center text-4xl">📄</div>`;

    const sizeKb = (d.size / 1024).toFixed(0);

    return `<div class="border border-gray-100 rounded-lg overflow-hidden card-elevate bg-white">

      ${preview}

      <div class="p-3">

        <p class="text-xs font-semibold text-slate-700 truncate" title="${d.nombre}">${d.nombre}</p>

        <p class="text-[11px] text-gray-400">${fmtDate(d.fecha)} · ${sizeKb} KB</p>

        <div class="flex gap-2 mt-2">

          ${d.dataUrl ? `<a href="${d.dataUrl}" download="${d.nombre}" class="text-[11px] font-semibold" style="color:var(--pf-brand-600)">Descargar</a>` : ''}

          <button type="button" class="btn-delete-doc text-[11px] font-semibold ml-auto" style="color:var(--pf-red)" data-id="${d.id}">Eliminar</button>

        </div>

      </div>

    </div>`;

  }).join('');



  grid.querySelectorAll('.btn-delete-doc').forEach(btn => {

    btn.addEventListener('click', () => {

      state.docs = state.docs.filter(d => d.id !== btn.dataset.id);

      saveDocs(state.docs);

      renderDocs();

      showToast('🗑️', 'Documento eliminado');

    });

  });

}



// 7. INICIALIZACIÓN Y EVENT LISTENERS (CUANDO EL DOM ESTÉ LISTO)

document.addEventListener('DOMContentLoaded', () => {



  // Eventos de Navegación

  document.querySelectorAll('[data-tab]').forEach(btn => {

    btn.addEventListener('click', () => setTab(btn.dataset.tab));

  });



  const mobileNav = document.getElementById('mobile-nav');

  if (mobileNav) {

    mobileNav.addEventListener('change', (e) => setTab(e.target.value));

  }



  // Botones de Salir

  function cerrarSesion() {

    showToast('👋', 'Cerrando sesión...');

   

    // Si manejas datos de usuario activo en localStorage/sessionStorage los puedes limpiar aquí:

    // localStorage.removeItem('usuario_activo');

   

    setTimeout(() => {

      // Redirige al login principal ubicado en la raíz del proyecto

      window.location.href = '../login-principal.html';

      // Nota: Si index.html está en una subcarpeta (ej: /vendedor/index.html),

      // usa '../../login.principal.html' o '/login.principal.html' según tu estructura.

    }, 600);

  }



  // Event Listeners para los botones de salir

  const btnSalirSidebar = document.getElementById('btn-salir-sidebar');

  const btnSalirTopbar = document.getElementById('btn-salir-topbar');



  if (btnSalirSidebar) btnSalirSidebar.addEventListener('click', cerrarSesion);

  if (btnSalirTopbar) btnSalirTopbar.addEventListener('click', cerrarSesion);

  // Formulario Agregar Producto

  const formProducto = document.getElementById('form-producto');

  if (formProducto) {

    formProducto.addEventListener('submit', (e) => {

      e.preventDefault();

      const nombre = document.getElementById('p-nombre').value.trim();

      const categoria = document.getElementById('p-categoria').value;

      const unidad = document.getElementById('p-unidad').value;

      const precio = parseFloat(document.getElementById('p-precio').value);

      const proveedor = document.getElementById('p-proveedor').value.trim();

      if (!nombre || isNaN(precio)) return;



      const today = new Date().toISOString().slice(0, 10);

      state.products.push({

        id: crypto.randomUUID(), nombre, categoria, unidad, proveedor,

        precio, history: [{ date: today, precio }]

      });



      saveProducts(state.products);

      formProducto.reset();

      showToast('✔', 'Producto agregado al catálogo');

      renderProducts();

      renderDashboard();

      refreshCharts();

    });

  }



  // Buscador de Productos

  const searchInput = document.getElementById('productos-search');

  if (searchInput) {

    searchInput.addEventListener('input', renderProducts);

  }



  // Desplegable de Gráfico de Evolución

  const chartSelect = document.getElementById('chart-producto-select');

  if (chartSelect) {

    chartSelect.addEventListener('change', drawEvolucionChart);

  }



  // Zona Dropzone / Documentos

  const dropzone = document.getElementById('dropzone');

  const fileInput = document.getElementById('file-input');



  if (dropzone && fileInput) {

    ['dragenter', 'dragover'].forEach(evt => {

      dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.add('drag-over'); });

    });

    ['dragleave', 'drop'].forEach(evt => {

      dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.remove('drag-over'); });

    });

    dropzone.addEventListener('drop', e => {

      if (e.dataTransfer.files?.length) handleFiles(e.dataTransfer.files);

    });

    fileInput.addEventListener('change', e => {

      if (e.target.files?.length) handleFiles(e.target.files);

      fileInput.value = '';

    });

  }



  // Renderizado e Inicialización Global

  renderProducts();

  renderDashboard();

  renderDocs();

  setTab('dashboard');

});