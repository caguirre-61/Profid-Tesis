/* =========================================================================
   PROFID · ESTADO GLOBAL Y MUTACIONES DE DATOS
   ========================================================================= */

export const state = {
  usuario: { nombre: "Usuario", rol: "Sin perfil asignado", proyecto: "" },
  partidas: [],   // { id, nombre, asignado, gastado }
  catalogo: {},   // Clave = proveedor|insumo normalizado
  movimientos: [] // Historial de facturas procesadas
};

export let facturaActual = null;

export function setFacturaActual(val) {
  facturaActual = val;
}

// Utilidad para normalizar identificadores de partidas
export function slugify(text) {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || ("partida-" + Date.now());
}

// Clave única para insumos en catálogo
export function claveInsumo(proveedor, insumo) {
  return (proveedor + "|" + insumo).toLowerCase().trim();
}

// Actualiza o inserta un nuevo item en el catálogo unificado
export function actualizarCatalogo(item) {
  const key = claveInsumo(item.proveedor, item.insumo);
  state.catalogo[key] = {
    insumo: item.insumo,
    proveedor: item.proveedor,
    unidad: item.unidad,
    precio: item.precio,
    partida: item.partida,
    fecha: item.fecha,
  };
}

// Agrega una partida nueva
export function agregarPartida(nombre, asignado) {
  const nueva = { 
    id: slugify(nombre) + "-" + state.partidas.length, 
    nombre, 
    asignado: parseFloat(asignado) || 0, 
    gastado: 0 
  };
  state.partidas.push(nueva);
  return nueva;
}

// Registra la confirmación de una factura en el sistema
export function guardarFacturaGlobal(item) {
  const total = item.cantidad * item.precio;

  // 1. Impactar gasto en la partida
  const partida = state.partidas.find(p => p.id === item.partida);
  if (partida) {
    partida.gastado += total;
  }

  // 2. Actualizar catálogo unificado
  actualizarCatalogo(item);

  // 3. Registrar movimiento en historial
  state.movimientos.push({
    proveedor: item.proveedor,
    fecha: item.fecha,
    insumo: item.insumo,
    partida: item.partida,
    total
  });
}