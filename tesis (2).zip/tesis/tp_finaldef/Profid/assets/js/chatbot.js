document.addEventListener('DOMContentLoaded', () => {
    const toggleBtn = document.getElementById('btn-toggle-chat');
    const closeBtn = document.getElementById('btn-close-chat');
    const chatWindow = document.getElementById('chat-window');
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
  
    let historial = [];
  
    // Mostrar / Ocultar ventana de chat
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        chatWindow.classList.toggle('hidden');
        chatWindow.classList.toggle('flex');
        if (!chatWindow.classList.contains('hidden')) {
          chatInput.focus();
        }
      });
    }
  
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        chatWindow.classList.add('hidden');
        chatWindow.classList.remove('flex');
      });
    }
  
    // Enviar mensaje al backend PHP
    if (chatForm) {
      chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const texto = chatInput.value.trim();
        if (!texto) return;
  
        // Renderizar mensaje del usuario
        appendMessage(texto, 'user');
        chatInput.value = '';
  
        // Indicador de "Escribiendo..."
        const loadingId = appendLoading();
  
        try {
          const res = await fetch('../api/chat_asistente.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ mensaje: texto, historial: historial })
          });
  
          const data = await res.json();
          removeLoading(loadingId);
  
          if (res.ok && data.respuesta) {
            appendMessage(data.respuesta, 'bot');
            // Guardar en el historial de la sesión
            historial.push({ sender: 'user', text: texto });
            historial.push({ sender: 'bot', text: data.respuesta });
          } else {
            appendMessage(data.error || 'Ocurrió un error al responder.', 'bot');
          }
        } catch (err) {
          removeLoading(loadingId);
          appendMessage('No se pudo conectar con el servidor de asistencia.', 'bot');
        }
      });
    }
  
    function appendMessage(text, sender) {
      const msgDiv = document.createElement('div');
      msgDiv.className = sender === 'user' ? 'flex justify-end' : 'flex gap-2 items-start';
  
      if (sender === 'user') {
        msgDiv.innerHTML = `
          <div class="bg-slate-800 text-white p-3 rounded-2xl rounded-tr-none shadow-sm max-w-[85%]">
            ${escapeHtml(text)}
          </div>
        `;
      } else {
        msgDiv.innerHTML = `
          <div class="w-6 h-6 rounded-full bg-brand flex-shrink-0 flex items-center justify-center text-white text-[10px] font-bold">🤖</div>
          <div class="bg-white p-3 rounded-2xl rounded-tl-none border border-gray-200 text-slate-700 shadow-sm max-w-[85%]">
            ${escapeHtml(text)}
          </div>
        `;
      }
  
      chatMessages.appendChild(msgDiv);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  
    function appendLoading() {
      const id = 'loading-' + Date.now();
      const loadingDiv = document.createElement('div');
      loadingDiv.id = id;
      loadingDiv.className = 'flex gap-2 items-start';
      loadingDiv.innerHTML = `
        <div class="w-6 h-6 rounded-full bg-brand flex-shrink-0 flex items-center justify-center text-white text-[10px] font-bold">🤖</div>
        <div class="bg-white p-3 rounded-2xl rounded-tl-none border border-gray-200 text-slate-400 shadow-sm max-w-[85%] italic">
          Escribiendo...
        </div>
      `;
      chatMessages.appendChild(loadingDiv);
      chatMessages.scrollTop = chatMessages.scrollHeight;
      return id;
    }
  
    function removeLoading(id) {
      const el = document.getElementById(id);
      if (el) el.remove();
    }
  
    function escapeHtml(text) {
      return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    }
  });