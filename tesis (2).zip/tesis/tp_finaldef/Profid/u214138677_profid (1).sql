-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-08-2026 a las 20:21:19
-- Versión del servidor: 11.8.8-MariaDB-log
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u214138677_profid`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alertas_inflacion`
--

CREATE TABLE `alertas_inflacion` (
  `id_alerta` int(11) NOT NULL,
  `id_insumo_base` int(11) NOT NULL,
  `id_documento_origen` int(11) NOT NULL,
  `precio_anterior` decimal(12,2) NOT NULL,
  `precio_nuevo` decimal(12,2) NOT NULL,
  `porcentaje_aumento` decimal(5,2) NOT NULL,
  `leida` tinyint(1) DEFAULT 0,
  `fecha_alerta` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `alertas_inflacion`
--

INSERT INTO `alertas_inflacion` (`id_alerta`, `id_insumo_base`, `id_documento_origen`, `precio_anterior`, `precio_nuevo`, `porcentaje_aumento`, `leida`, `fecha_alerta`) VALUES
(1, 1, 1, 1200.50, 1250.00, 4.12, 0, '2026-07-13 21:32:41'),
(2, 2, 1, 3500.00, 3600.00, 2.86, 0, '2026-07-13 21:32:41');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalogo_insumos_base`
--

CREATE TABLE `catalogo_insumos_base` (
  `id_insumo_base` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre_insumo` varchar(150) NOT NULL,
  `precio_actual` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unidad_medida` varchar(20) NOT NULL,
  `ultima_actualizacion` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `catalogo_insumos_base`
--

INSERT INTO `catalogo_insumos_base` (`id_insumo_base`, `id_usuario`, `nombre_insumo`, `precio_actual`, `unidad_medida`, `ultima_actualizacion`) VALUES
(1, 3, 'Harina 0000', 1200.50, 'kg', '2026-07-13 21:30:08'),
(2, 3, 'Aceite de Girasol', 3500.00, 'litro', '2026-07-13 21:30:08'),
(3, 3, 'Huevo', 150.00, 'unidad', '2026-07-13 21:30:08'),
(4, 3, 'Azúcar Común', 1100.00, 'kg', '2026-07-13 21:30:08');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_empresa`
--

CREATE TABLE `datos_empresa` (
  `id_empresa` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `razon_social` varchar(150) NOT NULL,
  `cuit` varchar(20) NOT NULL,
  `branding_logo_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `datos_empresa`
--

INSERT INTO `datos_empresa` (`id_empresa`, `id_usuario`, `razon_social`, `cuit`, `branding_logo_url`) VALUES
(1, 1, 'Gastronomía Profesional S.A.', '30-12345678-9', 'https://empresa.com/logo.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_receta_insumos`
--

CREATE TABLE `detalle_receta_insumos` (
  `id_detalle_receta` int(11) NOT NULL,
  `id_receta` int(11) NOT NULL,
  `id_insumo_base` int(11) NOT NULL,
  `cantidad_requerida` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `detalle_receta_insumos`
--

INSERT INTO `detalle_receta_insumos` (`id_detalle_receta`, `id_receta`, `id_insumo_base`, `cantidad_requerida`) VALUES
(1, 1, 3, 6.00),
(2, 1, 1, 0.50),
(3, 1, 4, 0.30),
(4, 2, 1, 1.00),
(5, 2, 2, 0.05);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos_pdf`
--

CREATE TABLE `documentos_pdf` (
  `id_documento` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `url_archivo` varchar(255) NOT NULL,
  `proveedor_extraido` varchar(100) DEFAULT NULL,
  `fecha_factura` date DEFAULT NULL,
  `total_extraido` decimal(12,2) DEFAULT NULL,
  `estado_validacion` enum('Pendiente','Validado') DEFAULT 'Pendiente',
  `fecha_carga` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `documentos_pdf`
--

INSERT INTO `documentos_pdf` (`id_documento`, `id_usuario`, `id_proveedor`, `nombre_archivo`, `url_archivo`, `proveedor_extraido`, `fecha_factura`, `total_extraido`, `estado_validacion`, `fecha_carga`) VALUES
(1, 3, 1, 'factura_proveedor_oct.pdf', 'https://storage.com/factura1.pdf', 'Distribuidora Alimentos S.A.', '2026-07-10', 50000.00, 'Validado', '2026-07-13 21:30:34'),
(2, 3, 2, 'factura_huevos_prov.pdf', 'https://storage.com/factura2.pdf', 'Granja El Huevo de Oro', '2026-07-12', 15000.00, 'Pendiente', '2026-07-13 21:30:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_alertas`
--

CREATE TABLE `historial_alertas` (
  `id_historial` int(11) NOT NULL,
  `id_alerta` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensaje` text NOT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `fecha_notificacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items_factura_extraidos`
--

CREATE TABLE `items_factura_extraidos` (
  `id_item` int(11) NOT NULL,
  `id_documento` int(11) NOT NULL,
  `descripcion_ocr` varchar(255) NOT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `precio_unitario_ocr` decimal(12,2) NOT NULL,
  `precio_total_ocr` decimal(12,2) NOT NULL,
  `id_insumo_base_asignado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `items_factura_extraidos`
--

INSERT INTO `items_factura_extraidos` (`id_item`, `id_documento`, `descripcion_ocr`, `cantidad`, `precio_unitario_ocr`, `precio_total_ocr`, `id_insumo_base_asignado`) VALUES
(1, 1, 'HARINA 0000 1KG INDIVIDUAL', 20.00, 1250.00, 25000.00, 1),
(2, 1, 'ACEITE GIRASOL 1L CAJA', 5.00, 3600.00, 18000.00, 2),
(3, 2, 'HUEVO GRANDE MAPLE X30', 3.00, 4800.00, 14400.00, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items_presupuesto`
--

CREATE TABLE `items_presupuesto` (
  `id_item_presupuesto` int(11) NOT NULL,
  `id_presupuesto` int(11) NOT NULL,
  `id_insumo_base` int(11) DEFAULT NULL,
  `id_receta` int(11) DEFAULT NULL,
  `cantidad` decimal(10,2) NOT NULL,
  `precio_costo_momento` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `items_presupuesto`
--

INSERT INTO `items_presupuesto` (`id_item_presupuesto`, `id_presupuesto`, `id_insumo_base`, `id_receta`, `cantidad`, `precio_costo_momento`) VALUES
(1, 1, NULL, 1, 10.00, 4500.00),
(2, 1, 1, NULL, 5.00, 1200.50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `presupuestos`
--

CREATE TABLE `presupuestos` (
  `id_presupuesto` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre_proyecto` varchar(150) NOT NULL,
  `monto_inicial_asignado` decimal(15,2) NOT NULL,
  `gasto_real_acumulado` decimal(15,2) DEFAULT 0.00,
  `margen_ganancia_configurado` decimal(5,2) NOT NULL DEFAULT 30.00,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `presupuestos`
--

INSERT INTO `presupuestos` (`id_presupuesto`, `id_usuario`, `nombre_proyecto`, `monto_inicial_asignado`, `gasto_real_acumulado`, `margen_ganancia_configurado`, `fecha_creacion`) VALUES
(1, 2, 'Catering Evento Empresarial Julio', 150000.00, 42000.00, 35.00, '2026-07-13 21:33:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL,
  `id_empresa` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `cuit_rut` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefono` varchar(50) DEFAULT NULL,
  `direccion` text DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_proveedor`, `id_empresa`, `nombre`, `cuit_rut`, `email`, `telefono`, `direccion`, `fecha_creacion`) VALUES
(1, 1, 'Distribuidora Alimentos S.A.', '30-98765432-1', 'contacto@alimentos.com', '1144445555', 'Av. Principal 123', '2026-08-10 22:05:47'),
(2, 1, 'Granja El Huevo de Oro', '30-88888888-2', 'ventas@huevodeoro.com', '1122223333', 'Ruta 8 Km 45', '2026-08-10 22:05:47');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetas_procedimientos`
--

CREATE TABLE `recetas_procedimientos` (
  `id_receta` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `nombre_receta` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `costo_total_actual` decimal(12,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `recetas_procedimientos`
--

INSERT INTO `recetas_procedimientos` (`id_receta`, `id_usuario`, `nombre_receta`, `descripcion`, `costo_total_actual`) VALUES
(1, 2, 'Bizcochuelo de Vainilla', 'Mezclar huevos, azúcar, incorporar harina y hornear a 180°C por 40 minutos.', 4500.00),
(2, 2, 'Pan Casero', 'Amasar harina, agua, levadura y sal. Dejar leudar y hornear.', 2400.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes_generados`
--

CREATE TABLE `reportes_generados` (
  `id_reporte` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_empresa` int(11) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `tipo_reporte` varchar(100) NOT NULL COMMENT 'ej: costos, inflacion, presupuestos',
  `filtros_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`filtros_json`)),
  `archivo_path` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `rol` enum('Usuario','Administrador','Vendedor') NOT NULL DEFAULT 'Usuario',
  `sector` enum('Construcción','Gastronomía','Salud') NOT NULL DEFAULT 'Gastronomía',
  `fecha_registro` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `email`, `password_hash`, `rol`, `sector`, `fecha_registro`) VALUES
(1, 'Admin General', 'admin@empresa.com', 'admin123', 'Administrador', 'Gastronomía', '2026-07-13 21:29:17'),
(2, 'Juan Pérez', 'juan.perez@empresa.com', 'Juan123', 'Usuario', 'Gastronomía', '2026-07-13 21:29:17'),
(3, 'María López', 'maria.lopez@empresa.com', 'Maria123', 'Usuario', 'Gastronomía', '2026-07-13 21:29:17');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alertas_inflacion`
--
ALTER TABLE `alertas_inflacion`
  ADD PRIMARY KEY (`id_alerta`),
  ADD KEY `id_insumo_base` (`id_insumo_base`),
  ADD KEY `id_documento_origen` (`id_documento_origen`);

--
-- Indices de la tabla `catalogo_insumos_base`
--
ALTER TABLE `catalogo_insumos_base`
  ADD PRIMARY KEY (`id_insumo_base`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `datos_empresa`
--
ALTER TABLE `datos_empresa`
  ADD PRIMARY KEY (`id_empresa`),
  ADD UNIQUE KEY `cuit` (`cuit`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `detalle_receta_insumos`
--
ALTER TABLE `detalle_receta_insumos`
  ADD PRIMARY KEY (`id_detalle_receta`),
  ADD KEY `id_receta` (`id_receta`),
  ADD KEY `id_insumo_base` (`id_insumo_base`);

--
-- Indices de la tabla `documentos_pdf`
--
ALTER TABLE `documentos_pdf`
  ADD PRIMARY KEY (`id_documento`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_proveedor` (`id_proveedor`);

--
-- Indices de la tabla `historial_alertas`
--
ALTER TABLE `historial_alertas`
  ADD PRIMARY KEY (`id_historial`),
  ADD KEY `id_alerta` (`id_alerta`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `items_factura_extraidos`
--
ALTER TABLE `items_factura_extraidos`
  ADD PRIMARY KEY (`id_item`),
  ADD KEY `id_documento` (`id_documento`),
  ADD KEY `id_insumo_base_asignado` (`id_insumo_base_asignado`);

--
-- Indices de la tabla `items_presupuesto`
--
ALTER TABLE `items_presupuesto`
  ADD PRIMARY KEY (`id_item_presupuesto`),
  ADD KEY `id_presupuesto` (`id_presupuesto`),
  ADD KEY `id_insumo_base` (`id_insumo_base`),
  ADD KEY `id_receta` (`id_receta`);

--
-- Indices de la tabla `presupuestos`
--
ALTER TABLE `presupuestos`
  ADD PRIMARY KEY (`id_presupuesto`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id_proveedor`),
  ADD KEY `id_empresa` (`id_empresa`);

--
-- Indices de la tabla `recetas_procedimientos`
--
ALTER TABLE `recetas_procedimientos`
  ADD PRIMARY KEY (`id_receta`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `reportes_generados`
--
ALTER TABLE `reportes_generados`
  ADD PRIMARY KEY (`id_reporte`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_empresa` (`id_empresa`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alertas_inflacion`
--
ALTER TABLE `alertas_inflacion`
  MODIFY `id_alerta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `catalogo_insumos_base`
--
ALTER TABLE `catalogo_insumos_base`
  MODIFY `id_insumo_base` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `datos_empresa`
--
ALTER TABLE `datos_empresa`
  MODIFY `id_empresa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `detalle_receta_insumos`
--
ALTER TABLE `detalle_receta_insumos`
  MODIFY `id_detalle_receta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `documentos_pdf`
--
ALTER TABLE `documentos_pdf`
  MODIFY `id_documento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `historial_alertas`
--
ALTER TABLE `historial_alertas`
  MODIFY `id_historial` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `items_factura_extraidos`
--
ALTER TABLE `items_factura_extraidos`
  MODIFY `id_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `items_presupuesto`
--
ALTER TABLE `items_presupuesto`
  MODIFY `id_item_presupuesto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `presupuestos`
--
ALTER TABLE `presupuestos`
  MODIFY `id_presupuesto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `recetas_procedimientos`
--
ALTER TABLE `recetas_procedimientos`
  MODIFY `id_receta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `reportes_generados`
--
ALTER TABLE `reportes_generados`
  MODIFY `id_reporte` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alertas_inflacion`
--
ALTER TABLE `alertas_inflacion`
  ADD CONSTRAINT `alertas_inflacion_ibfk_1` FOREIGN KEY (`id_insumo_base`) REFERENCES `catalogo_insumos_base` (`id_insumo_base`),
  ADD CONSTRAINT `alertas_inflacion_ibfk_2` FOREIGN KEY (`id_documento_origen`) REFERENCES `documentos_pdf` (`id_documento`);

--
-- Filtros para la tabla `catalogo_insumos_base`
--
ALTER TABLE `catalogo_insumos_base`
  ADD CONSTRAINT `catalogo_insumos_base_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `datos_empresa`
--
ALTER TABLE `datos_empresa`
  ADD CONSTRAINT `datos_empresa_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Filtros para la tabla `detalle_receta_insumos`
--
ALTER TABLE `detalle_receta_insumos`
  ADD CONSTRAINT `detalle_receta_insumos_ibfk_1` FOREIGN KEY (`id_receta`) REFERENCES `recetas_procedimientos` (`id_receta`) ON DELETE CASCADE,
  ADD CONSTRAINT `detalle_receta_insumos_ibfk_2` FOREIGN KEY (`id_insumo_base`) REFERENCES `catalogo_insumos_base` (`id_insumo_base`);

--
-- Filtros para la tabla `documentos_pdf`
--
ALTER TABLE `documentos_pdf`
  ADD CONSTRAINT `documentos_pdf_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `documentos_pdf_ibfk_2` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`) ON DELETE SET NULL;

--
-- Filtros para la tabla `historial_alertas`
--
ALTER TABLE `historial_alertas`
  ADD CONSTRAINT `historial_alertas_ibfk_1` FOREIGN KEY (`id_alerta`) REFERENCES `alertas_inflacion` (`id_alerta`) ON DELETE CASCADE,
  ADD CONSTRAINT `historial_alertas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Filtros para la tabla `items_factura_extraidos`
--
ALTER TABLE `items_factura_extraidos`
  ADD CONSTRAINT `items_factura_extraidos_ibfk_1` FOREIGN KEY (`id_documento`) REFERENCES `documentos_pdf` (`id_documento`) ON DELETE CASCADE,
  ADD CONSTRAINT `items_factura_extraidos_ibfk_2` FOREIGN KEY (`id_insumo_base_asignado`) REFERENCES `catalogo_insumos_base` (`id_insumo_base`) ON DELETE SET NULL;

--
-- Filtros para la tabla `items_presupuesto`
--
ALTER TABLE `items_presupuesto`
  ADD CONSTRAINT `items_presupuesto_ibfk_1` FOREIGN KEY (`id_presupuesto`) REFERENCES `presupuestos` (`id_presupuesto`) ON DELETE CASCADE,
  ADD CONSTRAINT `items_presupuesto_ibfk_2` FOREIGN KEY (`id_insumo_base`) REFERENCES `catalogo_insumos_base` (`id_insumo_base`),
  ADD CONSTRAINT `items_presupuesto_ibfk_3` FOREIGN KEY (`id_receta`) REFERENCES `recetas_procedimientos` (`id_receta`);

--
-- Filtros para la tabla `presupuestos`
--
ALTER TABLE `presupuestos`
  ADD CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD CONSTRAINT `proveedores_ibfk_1` FOREIGN KEY (`id_empresa`) REFERENCES `datos_empresa` (`id_empresa`) ON DELETE CASCADE;

--
-- Filtros para la tabla `recetas_procedimientos`
--
ALTER TABLE `recetas_procedimientos`
  ADD CONSTRAINT `recetas_procedimientos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `reportes_generados`
--
ALTER TABLE `reportes_generados`
  ADD CONSTRAINT `reportes_generados_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `reportes_generados_ibfk_2` FOREIGN KEY (`id_empresa`) REFERENCES `datos_empresa` (`id_empresa`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
