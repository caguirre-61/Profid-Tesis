<?php
session_start();

if (!isset($_SESSION['pedido_cocina'])) {
    echo "No hay pedidos para preparar.";
    exit;
}

$pedido = $_SESSION['pedido_cocina'];
?>
<h1>Pedido para preparar</h1>

<?php foreach ($pedido as $item): ?>
    <p>
        <strong><?= $item['nombre'] ?></strong> x<?= $item['cantidad'] ?>
        — $<?= number_format($item['precio'] * $item['cantidad'], 0, ',', '.') ?>
    </p>
<?php endforeach; ?>
