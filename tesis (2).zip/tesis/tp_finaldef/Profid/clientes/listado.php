<?php
require 'conexion.php';

$criterio = $_GET['criterio'] ?? '';

if ($criterio != '') {
    $query = $cnx->prepare("SELECT * FROM clientes WHERE nombre LIKE :criterio");
    $query->bindValue(":criterio", "%$criterio%");
} else {
    $query = $cnx->prepare("SELECT * FROM clientes");
}

$query->execute();
$datos = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Listado de Clientes</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #000;
      color: #fff;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 40px 20px;
    }

    .container-box {
      background-color: #111;
      border-radius: 18px;
      border: 2px solid #ffc107;
      max-width: 950px;
      width: 100%;
      padding: 30px 40px;
      box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
    }

    .logo-side {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      margin-bottom: 25px;
      color: #ffc107;
    }

    .logo-circle {
      width: 90px;
      height: 90px;
      border: 4px solid #ffc107;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      font-size: 26px;
      margin-bottom: 10px;
      color: #ffc107;
    }

    h1, h2 {
      color: #ffc107;
      font-weight: bold;
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 30px;
    }

    .form-control {
      border-radius: 10px;
      border: 2px solid #ffc107;
      background-color: #222;
      color: #fff;
      padding: 10px 15px;
      width: 250px;
      font-size: 16px;
      transition: border-color 0.3s;
    }

    .form-control:focus {
      outline: none;
      border-color: #fff;
      background-color: #333;
    }

    .btn-primary {
      background-color: #ffc107;
      border: none;
      color: #000;
      font-weight: bold;
      padding: 10px 25px;
      border-radius: 50px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .btn-primary:hover {
      background-color: #e6b006;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      text-align: center;
      border-radius: 10px;
      overflow: hidden;
    }

    thead {
      background-color: #ffc107;
      color: #000;
    }

    th, td {
      padding: 15px;
      border-bottom: 1px solid #444;
      font-weight: 500;
    }

    tbody tr:hover {
      background-color: #222;
    }

    .btn-danger {
      background-color: #e6b006;
      border: none;
      color: #fff;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 14px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .btn-danger:hover {
      background-color: #e6b006;
    }

    .btn-warning {
      background-color: #ffc107;
      border: none;
      color: #000;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 14px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .btn-warning:hover {
      background-color: #e6b006;
    }
  </style>
</head>
<body>
  <div class="container-box">
    <div class="logo-side">
      <div class="logo-circle">McK</div>
      <h1>McKing</h1>
    </div>

    <h2>Listado de Clientes</h2>

    <form method="get" class="row g-2 justify-content-center">
      <input type="text" name="criterio" class="form-control" placeholder="Buscar por nombre" value="<?= htmlspecialchars($criterio) ?>">
      <button type="submit" class="btn-primary">Buscar</button>
    </form>

    <a href="registrar.php" class="btn-primary mb-3" style="display: inline-block; margin-bottom: 20px;">Agregar nuevo</a>

    <table>
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Usuario</th>
          <th>Password</th>
          <th>Eliminar</th>
          <th>Modificar</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($datos) > 0): ?>
            <?php foreach ($datos as $fila): ?>
            <tr>
              <td><?= htmlspecialchars($fila['nombre']); ?></td>
              <td><?= htmlspecialchars($fila['usuario']); ?></td>
              <td><?= htmlspecialchars($fila['password']); ?></td>
              <td>
                <a href="eliminar.php?id=<?= $fila['id_cliente']; ?>" class="btn-danger" onclick="return confirm('¿Estás seguro que querés eliminar?')">Eliminar</a>
              </td>
              <td>
                <a href="form-modificar.php?id=<?= $fila['id_cliente']; ?>" class="btn-warning">Modificar</a>
              </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
              <td colspan="5" class="text-center text-muted" style="color:#999;">No se encontraron clientes</td>
            </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
