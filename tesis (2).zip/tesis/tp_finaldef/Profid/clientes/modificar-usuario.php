<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['id'])) {
    header("Location: login-principal.html");
    exit;
}

$id_cliente = $_SESSION['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($nombre === "" || $usuario === "" || $password === "") {
        $mensaje = '<div class="alert alert-danger">Por favor, completá todos los campos.</div>';
    } else {
        try {
            $consulta = $cnx->prepare("
                UPDATE clientes 
                SET nombre = :nombre, usuario = :usuario, password = :password
                WHERE id_cliente = :id_cliente
            ");
            $consulta->bindValue(':id_cliente', $id_cliente, PDO::PARAM_INT);
            $consulta->bindValue(':nombre', $nombre);
            $consulta->bindValue(':usuario', $usuario);
            $consulta->bindValue(':password', $password);
            $validacion = $consulta->execute();

            if ($validacion) {
                $_SESSION['usuario'] = $usuario;
                $mensaje = '<div class="alert alert-success">Datos modificados correctamente.</div>';
            } else {
                $mensaje = '<div class="alert alert-danger">Error al modificar los datos.</div>';
            }
        } catch (PDOException $e) {
            $mensaje = '<div class="alert alert-danger">Error de base de datos: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }
}

$consulta = $cnx->prepare("SELECT * FROM clientes WHERE id_cliente = :id_cliente");
$consulta->bindValue(':id_cliente', $id_cliente, PDO::PARAM_INT);
$consulta->execute();
$cliente = $consulta->fetch(PDO::FETCH_ASSOC);

if (!$cliente) {
    die("Error: usuario no encontrado.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Modificar Usuario - McKing</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
<style>

body {
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    height: 100vh;
    background: linear-gradient(135deg, #000000 50%, #ffcc00 50%);
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
}

.container-box {
    background: #111;
    padding: 35px;
    width: 450px;
    border-radius: 20px;
    border: 2px solid #ffc107;
    box-shadow: 0 6px 25px rgba(255,193,7,0.4);
    text-align: center;
}

h2 {
    color: #ffc107;
    font-weight: bold;
    margin-bottom: 25px;
}

label {
    display: block;
    text-align: left;
    font-weight: bold;
    margin-bottom: 5px;
    color: #ffc107;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    border: 2px solid #ffc107;
    background: #222;
    color: #fff;
    font-size: 16px;
    margin-bottom: 18px;
}

.btn-primary,
button.btn-primary {
    display: block;
    width: 100%;
    background: #ffc107;
    color: #000;
    padding: 12px;
    border-radius: 50px;
    font-weight: bold;
    border: none;
    cursor: pointer;
    transition: 0.3s;
}

.btn-primary:hover,
button.btn-primary:hover {
    background: #e6b800;
}

.btn-secondary {
    display: block;
    margin-top: 15px;
    padding: 12px;
    border-radius: 50px;
    border: 2px solid #ffc107;
    color: #ffc107;
    text-decoration: none;
    font-weight: bold;
    transition: 0.3s;
}

.btn-secondary:hover {
    background: #ffc107;
    color: #000;
}

.alert-success, .alert-danger {
    margin-bottom: 20px;
    padding: 12px;
    border-radius: 10px;
    font-weight: bold;
}

.alert-success {
    background: #2d4d1a;
    color: #c3e88d;
}

.alert-danger {
    background: #5a1e1e;
    color: #f9b3b3;
}

</style>


</head>
<body>
  <div class="container-box">
    <h2>Modificar mis datos</h2>

    <?php if (isset($mensaje)) echo $mensaje; ?>

    <form method="POST" action="">
      <label for="nombre">Nombre</label>
      <input type="text" name="nombre" id="nombre" value="<?= htmlspecialchars($cliente['nombre']) ?>" required>

      <label for="usuario">Usuario</label>
      <input type="text" name="usuario" id="usuario" value="<?= htmlspecialchars($cliente['usuario']) ?>" required>

      <label for="password">Contraseña</label>
      <input type="password" name="password" id="password" value="<?= htmlspecialchars($cliente['password']) ?>" required>

      <button type="submit" class="btn-primary">Guardar cambios</button>
    </form>

    <a href="index.php" class="btn btn-secondary">Volver al menu</a>
  </div>
</body>
</html>
