<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login-principal.html");
    exit;
}

require 'conexion.php';

// Obtener el ID del cliente desde la sesión
$id_cliente = $_SESSION['id'];

// Pedidos pendientes
$pendientes = $cnx->prepare("
    SELECT * FROM pedidos
    WHERE estado = 'pendiente' AND id_cliente = ?
    ORDER BY fecha_hora DESC
");
$pendientes->execute([$id_cliente]);
$pendientes = $pendientes->fetchAll(PDO::FETCH_ASSOC);

// Pedidos realizados (finalizados)
$finalizados = $cnx->prepare("
    SELECT * FROM pedidos
    WHERE estado = 'realizado' AND id_cliente = ?
    ORDER BY fecha_hora DESC
");
$finalizados->execute([$id_cliente]);
$finalizados = $finalizados->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis pedidos</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
<style>
body {
    background:#000;
    color:#fff;
    font-family:'Montserrat';
    padding:40px;
}

h1 {
    color:#ffc107;
}

/* 🔥 BOTÓN VOLVER ESTILIZADO */
.btn-volver {
    position: absolute;
    top: 25px;
    right: 40px;
    background: #ffc107;
    color: #000;
    padding: 10px 20px;
    border-radius: 10px;
    font-weight: bold;
    text-decoration: none;
    border: 2px solid #000;
    transition: 0.2s ease;
}

.btn-volver:hover {
    background: #e6b006;
}

/* Cajas */
.box {
    background:#111;
    padding:20px;
    border:2px solid #ffc107;
    border-radius:10px;
    margin-bottom:30px;
}

.pedido {
    padding:12px 0;
    border-bottom:1px solid #ffc10755;
}

.estado {
    font-size:14px;
    opacity:0.8;
}
</style>
</head>

<body>
    <!-- 🔥 Botón volver arriba a la derecha -->
<a href="index.php" class="btn-volver">Volver</a>

<h1>Pedidos del usuario: <?= htmlspecialchars($_SESSION['usuario']) ?></h1>

<div class="box">
    <h2>Pendientes</h2>

    <?php if ($pendientes): ?>
        <?php foreach ($pendientes as $p): ?>
            <div class="pedido">
                <strong>Pedido #<?= $p['id_pedido'] ?></strong><br>
                Total: $<?= number_format($p['total'],0,',','.') ?><br>
                Fecha: <?= $p['fecha_hora'] ?><br>
                <span class="estado">Estado: <?= $p['estado'] ?></span>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No hay pedidos pendientes.</p>
    <?php endif; ?>

</div>

<div class="box">
    <h2>Realizados</h2>

    <?php if ($finalizados): ?>
        <?php foreach ($finalizados as $p): ?>
            <div class="pedido">
                <strong>Pedido #<?= $p['id_pedido'] ?></strong><br>
                Total: $<?= number_format($p['total'],0,',','.') ?><br>
                Fecha: <?= $p['fecha_hora'] ?><br>
                <span class="estado">Estado: <?= $p['estado'] ?></span>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No hay pedidos realizados aún.</p>
    <?php endif; ?>


</div>

</body>
</html>
