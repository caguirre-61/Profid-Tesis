<?php
session_start();

if (isset($_GET['eliminar_id'])) {
    $id_producto = (int)$_GET['eliminar_id'];
    
    if (isset($_SESSION['carrito'][$id_producto])) {
        if ($_SESSION['carrito'][$id_producto]['cantidad'] > 1) {
            $_SESSION['carrito'][$id_producto]['cantidad']--;
        } else {
            unset($_SESSION['carrito'][$id_producto]);
        }
    }
}

header("Location: index.php");
exit;
?>