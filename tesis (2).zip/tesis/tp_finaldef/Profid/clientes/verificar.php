<?php
session_start();
require 'conexion.php';
$usuario = $_POST["usuario"];
$password = $_POST["password"];

$query = $cnx->prepare(
    "SELECT * FROM clientes WHERE usuario = :usuario AND password = :password"
);
$query->bindValue(':usuario', $usuario);
$query->bindValue(':password', $password);
$query->execute();

$cliente = $query->fetchAll(PDO::FETCH_ASSOC);

if (count($cliente) == 1){
  print_r ($cliente);
  $_SESSION['id'] = $cliente[0]['id_cliente'];
  $_SESSION['usuario'] = $cliente[0]['usuario'];
  header('location:index.php');

}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Resultado de Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
   <style>
    body {
      font-family: 'Roboto', sans-serif;
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #000000 50%, #ffcc00 50%);
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      overflow: hidden;
    }

    .container-box {
      position: relative;
      z-index: 2;
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #ffffff;
      border-radius: 18px;
      box-shadow: 0 6px 25px rgba(0,0,0,0.3);
      overflow: hidden;
      max-width: 700px;
      width: 90%;
    }

    .logo-side {
      flex: 1;
      text-align: center;
      padding: 40px;
    }

    .form-side {
      flex: 1;
      padding: 40px;
      text-align: center;
    }

    .logo-circle {
      width: 90px;
      height: 90px;
      border: 4px solid #ffcc00;
      border-radius: 50%;
      color: #ffcc00;
      display: flex;
      justify-content: center;
      align-items: center;
      font-weight: bold;
      font-size: 26px;
      margin: 0 auto 10px;
    }

    h1, h2 {
      color: #ffcc00;
      font-weight: bold;
      margin-bottom: 25px;
    }

    .alert-box {
      text-align: center;
      padding: 20px 0;
    }

    .btn-return {
      margin-top: 20px;
      width: 100%;
      font-weight: bold;
      border-radius: 50px;
      padding: 12px 30px;
      text-decoration: none;
      display: inline-block;
      transition: 0.3s;
    }

    .btn-return-primary {
      background-color: #ffcc00;
      color: #000;
      border: none;
    }

    .btn-return-primary:hover {
      background-color: #e6b800;
    }

    .btn-return-secondary {
      background-color: #fff;
      border: 1px solid #ccc;
      color: #333;
    }

    .btn-return-secondary:hover {
      background-color: #f5f5f5;
    }

    @media (max-width: 768px) {
      body {
        background: linear-gradient(180deg, #000 40%, #ffcc00 60%);
      }
      .container-box {
        flex-direction: column;
      }
    }
  </style>
</head>
<body>
  <div class="container-box">
    <div class="logo-side">
      <div class="logo-circle">McK</div>
      <h1>McKing</h1>
    </div>

    <div class="form-side">
      <h2>Resultado de Login</h2>
      <div class="alert-box">
        <?php if(count($cliente) == 1): ?>
          <div class="alert alert-success" role="alert">
            ¡Inicio exitoso! Bienvenido, <?= htmlspecialchars($usuario) ?>.
          </div>
          <a href="index.php" class="btn-return btn-return-primary">Ir al Inicio</a>
        <?php else: ?>
          <div class="alert alert-danger" role="alert">
            Usuario o contraseña incorrectos.
          </div>
          <a href="login-cliente.html" class="btn-return btn-return-secondary">Volver al Login</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</body>
</html>