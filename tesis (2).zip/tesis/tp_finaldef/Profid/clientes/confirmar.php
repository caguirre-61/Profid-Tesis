<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: login-cliente.html");
    exit;
}

if (empty($_SESSION['carrito'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Confirmar Pedido</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />

<style>


body {
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    height: 100vh;
    background: linear-gradient(135deg, #000000 50%, #ffcc00 50%);
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    color: #fff;
}

.container {
    background: #111;
    padding: 35px;
    width: 420px;
    border-radius: 20px;
    border: 2px solid #ffc107;
    box-shadow: 0 6px 25px rgba(255,193,7,0.4);
}

h1 {
    color: #ffc107;
    text-align: center;
    font-weight: bold;
    margin-bottom: 25px;
}

.item {
    border-bottom: 1px solid #ffc10744;
    padding: 12px 0;
    font-size: 16px;
}

.total {
    font-size: 22px;
    margin-top: 20px;
    text-align: right;
    color: #ffc107;
}

.btn {
    display: block;
    background: #ffc107;
    color: #000;
    padding: 12px;
    text-align: center;
    margin-top: 20px;
    border-radius: 50px;
    font-weight: bold;
    text-decoration: none;
    transition: 0.3s;
}

.btn:hover {
    background: #e6b800;
    color: #000;
}

.btn-secondary {
    display: block;
    background: transparent;
    border: 2px solid #ffc107;
    color: #ffc107;
    padding: 12px;
    text-align: center;
    margin-top: 12px;
    border-radius: 50px;
    font-weight: bold;
    text-decoration: none;
    transition: 0.3s;
}

.btn-secondary:hover {
    background: #ffc107;
    color: #000;
}

</style>
</head>
<body>

<div class="container">
    <h1>Confirmar Pedido</h1>

    <?php
    $total = 0;
    foreach ($_SESSION['carrito'] as $item) {
        $subtotal = $item['precio'] * $item['cantidad'];
        $total = $total + $subtotal;
        echo "<div class='item'>
                <strong>{$item['nombre']}</strong> x{$item['cantidad']} - $" . number_format($subtotal, 0, ',', '.') . "
              </div>";
    }
    ?>

    <div class="total">TOTAL: $<?= number_format($total, 0, ',', '.') ?></div>

    <a href="enviar-pedido.php" class="btn">Confirmar pedido</a>
    <a href="index.php" class="btn-secondary">Volver al inicio</a>
</div>

</body>
</html>
