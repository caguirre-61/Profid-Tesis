<?php
session_start();
require 'conexion.php';

$nombre = $_POST['nombre'] ?? '';
$usuario = $_POST['usuario'] ?? '';
$password = $_POST['password'] ?? '';

if (!isset($_SESSION['id'])) {
    die("Error: no se especificó el cliente a modificar.");
}

$consulta = $cnx->prepare("
    UPDATE clientes 
    SET nombre = :nombre, usuario = :usuario, password = :password 
    WHERE id_cliente = :id_cliente
");

$consulta->bindValue(':id_cliente', $_SESSION['id']);
$consulta->bindValue(':nombre', $nombre);
$consulta->bindValue(':usuario', $usuario);
$consulta->bindValue(':password', $password);

$validacion = $consulta->execute();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado de modificación</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center">
        <div class="card shadow p-4 mt-5" style="max-width:500px; width:100%;">
            <h3 class="text-center mb-3">Resultado</h3>

            <?php if ($validacion): ?>
                <div class="alert alert-success">
                    Cliente modificado correctamente
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    Hubo un error al modificar
                </div>
            <?php endif; ?>

            <div class="text-center mt-3">
                <a href="listado.php" class="btn btn-primary">Volver al listado</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>