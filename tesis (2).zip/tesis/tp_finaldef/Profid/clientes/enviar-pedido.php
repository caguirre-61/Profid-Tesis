<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario']) || empty($_SESSION['carrito'])) {
    header("Location: index.php");
    exit;
}

$id_cliente = $_SESSION['id'];
$carrito = $_SESSION['carrito'];

//calcula el total
$total = 0;
foreach ($carrito as $item) {
    $total += $item['precio'] * $item['cantidad'];
}

//inserta el pedido
$stmt = $cnx->prepare("
    INSERT INTO pedidos (id_cliente, fecha_hora, total, estado)
    VALUES (?, NOW(), ?, 'pendiente')
");
$stmt->execute([$id_cliente, $total]);

// Obtener ID del pedido recién creado
$id_pedido = $cnx->lastInsertId();

//detalles del pedido
$stmt_item = $cnx->prepare("
    INSERT INTO detalle_pedidos (id_pedido, id_producto, cantidad, precio)
    VALUES (?, ?, ?, ?)
");

foreach ($carrito as $item) {
    $id_producto = $item['id'];  

    $stmt_item->execute([
        $id_pedido,
        $id_producto,
        $item['cantidad'],
        $item['precio']
    ]);
}


//vacio el carrito
unset($_SESSION['carrito']);

header("Location: pedidos.php");
exit;
?>
