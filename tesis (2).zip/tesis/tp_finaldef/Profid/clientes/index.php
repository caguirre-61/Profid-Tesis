<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login-principal.html");
    exit;
}

require 'conexion.php';

$query = $cnx->prepare("SELECT * FROM productos");
$query->execute();
$productos = $query->fetchAll(PDO::FETCH_ASSOC);

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

//agregar productos
if (isset($_GET['producto_id'])) {
    $id = (int)$_GET['producto_id'];
    $nombre = $_GET['nombre'];
    $precio = $_GET['precio'];

    if (isset($_SESSION['carrito'][$id])) {
        $_SESSION['carrito'][$id]['cantidad']++;
    } else {
        $_SESSION['carrito'][$id] = [
            'nombre' => $nombre,
            'precio' => $precio,
            'cantidad' => 1
        ];
    }
    header("Location: index.php");
    exit;
}

//sumar productos
if (isset($_GET['sumar_id'])) {
    $id = (int)$_GET['sumar_id'];
    if (isset($_SESSION['carrito'][$id])) {
        $_SESSION['carrito'][$id]['cantidad']++;
    }
    header("Location: index.php");
    exit;
}

//restar productos
if (isset($_GET['restar_id'])) {
    $id = (int)$_GET['restar_id'];
    if (isset($_SESSION['carrito'][$id])) {
        if ($_SESSION['carrito'][$id]['cantidad'] > 1) {
            $_SESSION['carrito'][$id]['cantidad']--;
        } else {
            unset($_SESSION['carrito'][$id]);
        }
    }
    header("Location: index.php");
    exit;
}

//desahacer
if (isset($_GET['deshacer_todo'])) {
    $_SESSION['carrito'] = [];
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>McKing - Menú</title>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />

<style>
body { font-family:'Montserrat', sans-serif; background:#000; color:#fff; margin:0; padding:0; }

header { background:#ffc107; padding:20px 60px; display:flex; justify-content:space-between; align-items:center; }
.logo { font-size:28px; font-weight:bold; color:#000; }

nav a.btn-modificar {
    background-color:#000;
    color:#ffc107;
    padding:8px 14px;
    border-radius:6px;
    border:2px solid #000;
    font-weight:bold;
    text-decoration:none;
    margin-left:10px;
}

nav a.btn-modificar:hover {
    background:#222;
}

main { display:flex; gap:20px; padding:40px; }

.menu-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:30px; flex:3; }
.menu-item { background:#111; padding:20px; border-radius:10px; text-align:center; border:1px solid #ffc10733; }
.menu-item img { width:100%; border-radius:10px; }

.carrito {
    background:#111;
    border:2px solid #ffc107;
    padding:20px;
    border-radius:10px;
    flex:1;
    max-width:350px;
    height:fit-content;
    position:sticky;
    top:20px;
}

.item-carrito {
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ffc10755;
}

.item-carrito h3 {
    margin: 0 0 6px 0;
    font-size: 16px;
}

.controls {
    margin: 6px 0;
    display: flex;
    gap: 8px;
}

.restar, .sumar {
    color:#ffc107;
    text-decoration:none;
    padding:4px 8px;
    border:1px solid #ffc107;
    border-radius:4px;
    font-weight:bold;
}

.price {
    font-weight:bold;
    margin-top:5px;
}

.btn-confirmar, .btn-deshacer {
    display:block;
    width:100%;
    text-align:center;
    padding:12px;
    margin-top:12px;
    border-radius:8px;
    font-weight:bold;
    text-decoration:none;
    font-size:15px;
}

.btn-confirmar { background:#ffc107; color:#000; }
.btn-confirmar:hover { background:#e0ac00; }

.btn-deshacer { background:#dc3545; color:#fff; }
.btn-deshacer:hover { background:#b52a36; }
.carrito {
    background:#111;
    border:2px solid #ffc107;
    padding:25px;
    border-radius:10px;
    flex:1;
    max-width:380px;
    height:fit-content;
    position:sticky;
    top:20px;
}

.totales {
    margin-top:20px;
}

.btn-confirmar, .btn-deshacer {
    display:block;
    width:100%;
    padding:10px;
    margin-top:12px;
    border-radius:8px;
    font-weight:bold;
    text-align:center;
}

</style>
</head>

<body>

<header>
    <div class="logo">McKing</div>
    <nav>
        <span>Hola, <?= htmlspecialchars($_SESSION['usuario']) ?></span>
        <a href="pedidos.php" class="btn-modificar">Pedidos</a>
        <a href="modificar-usuario.php" class="btn-modificar">Modificar usuario</a>
        <a href="../index-principal.php" class="btn-modificar">Cerrar sesión</a>
    </nav>
</header>

<main>
    <div class="menu-grid">
        <?php foreach ($productos as $producto): ?>
        <div class="menu-item">
            <h3><?= htmlspecialchars($producto['nombre']) ?></h3>
            <img src="<?= htmlspecialchars($producto['img_path']) ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>" />
            <p><?= htmlspecialchars($producto['descripcion']) ?></p>
            <div class="price">$<?= number_format($producto['precio'],0,',','.') ?></div>

            <a href="index.php?producto_id=<?= $producto['id_producto'] ?>&nombre=<?= urlencode($producto['nombre']) ?>&precio=<?= $producto['precio'] ?>" class="btn-modificar">
                Ordenar
            </a>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="carrito">
        <h2>Mi Pedido</h2>

        <?php
        $total = 0;

        if (!empty($_SESSION['carrito'])):
            foreach ($_SESSION['carrito'] as $id => $producto):
                $subtotal = $producto['precio'] * $producto['cantidad'];
                $total += $subtotal;
        ?>
        <div class="item-carrito">
            <h3><?= htmlspecialchars($producto['nombre']) ?> x<?= $producto['cantidad'] ?></h3>

            <div class="controls">
                <a href="index.php?restar_id=<?= $id ?>" class="restar">-</a>
                <a href="index.php?sumar_id=<?= $id ?>" class="sumar">+</a>
            </div>

            <div class="price">$<?= number_format($subtotal,0,',','.') ?></div>
        </div>

        <?php endforeach; else: ?>
            <p>El carrito está vacío.</p>
        <?php endif; ?>

        <div class="totales">
            <p><strong>SUBTOTAL:</strong> $<?= number_format($total,0,',','.') ?></p>
            <p><strong>TOTAL:</strong> $<?= number_format($total,0,',','.') ?></p>

            <a href="confirmar.php" class="btn-confirmar">Confirmar pedido</a>
            <a href="index.php?deshacer_todo=1" class="btn-deshacer">Deshacer todo</a>
        </div>
    </div>

</main>
</body>
</html>
