<?php
session_start();

// Configuración de la base de datos (descomentar cuando la conectes)
/*
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "profid_obras";

$conn = new mysqli($host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
*/

$mensaje = "";
$tipo_mensaje = ""; // "exito" o "error"

// Procesar el formulario de Login
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $mensaje = "Por favor, completa todos los campos.";
        $tipo_mensaje = "error";
    } else {
        /*
        // ==========================================
        // CONSULTA A LA BASE DE DATOS
        // ==========================================
        $stmt = $conn->prepare("SELECT id, nombre, empresa, password FROM vendedores WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($usuario = $resultado->fetch_assoc()) {
            if (password_verify($password, $usuario['password'])) {
                $_SESSION['vendedor_id'] = $usuario['id'];
                $_SESSION['vendedor_nombre'] = $usuario['nombre'];
                $_SESSION['vendedor_empresa'] = $usuario['empresa'];
                
                header("Location: index.html");
                exit;
            } else {
                $mensaje = "La contraseña es incorrecta.";
                $tipo_mensaje = "error";
            }
        } else {
            $mensaje = "No existe una cuenta de vendedor vinculada a este correo.";
            $tipo_mensaje = "error";
        }
        $stmt->close();
        */

        // Simulación para prueba sin BD:
        header("Location: index.html");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --pf-navy-950:#08182A;
      --pf-navy-900:#0C2338;
      --pf-navy-800:#123A5C;
      --pf-brand-700:#18517C;
      --pf-brand-600:#1F6690;
      --pf-brand-500:#2B7FB0;
      --pf-sky-400:#5AA9D6;
      --pf-sky-300:#8FC6E6;
      --pf-gray-300:#CBD5E1;
      --pf-gray-400:#94A3B8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: var(--pf-navy-950);
      color: #fff;
      overflow-x: hidden;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      background: linear-gradient(120deg, var(--pf-brand-700), var(--pf-brand-600));
      padding: 20px 60px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
      z-index: 10;
      box-shadow: 0 4px 18px rgba(8,24,42,0.35);
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
      font-family: 'Barlow Condensed', sans-serif;
      font-size: 30px;
      font-weight: 800;
      color: #fff;
      letter-spacing: 0.02em;
      text-decoration: none;
    }

    nav {
      display: flex;
      align-items: center;
    }

    nav a.nav-link {
      color: rgba(255,255,255,0.85);
      margin: 0 16px;
      text-decoration: none;
      font-weight: 600;
      font-size: 15px;
      padding: 8px 4px;
      border-bottom: 2px solid transparent;
      transition: all 0.3s ease;
    }

    nav a.nav-link:hover {
      color: #fff;
      border-color: var(--pf-sky-300);
    }

    nav a.btn-login {
      color: #fff;
      margin-left: 24px;
      text-decoration: none;
      font-weight: 700;
      font-size: 15px;
      padding: 10px 22px;
      border-radius: 50px;
      border: 2px solid rgba(255,255,255,0.6);
      transition: all 0.3s ease;
    }

    nav a.btn-login:hover,
    nav a.btn-login.active {
      color: var(--pf-brand-700);
      background-color: #fff;
      border-color: #fff;
    }

    main {
      flex: 1;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 60px 20px;
      background: radial-gradient(circle at 80% 20%, rgba(90,169,214,0.10), transparent 45%),
                  radial-gradient(circle at 10% 85%, rgba(43,127,176,0.12), transparent 40%),
                  var(--pf-navy-900);
    }

    .auth-container {
      width: 100%;
      max-width: 480px;
      background: linear-gradient(160deg, var(--pf-navy-800), var(--pf-navy-900));
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 25px 60px -25px rgba(0,0,0,0.6);
      position: relative;
      z-index: 2;
    }

    .auth-header {
      text-align: center;
      margin-bottom: 24px;
    }

    .auth-header h2 {
      font-family: 'Barlow Condensed', sans-serif;
      font-size: 36px;
      font-weight: 800;
      text-transform: uppercase;
      color: var(--pf-sky-400);
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }

    .auth-header p {
      color: var(--pf-gray-300);
      font-size: 14.5px;
    }

    .alert {
      padding: 12px 16px;
      border-radius: 10px;
      font-size: 14px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 600;
    }
    .alert.error {
      background: rgba(220, 38, 38, 0.15);
      border: 1px solid rgba(220, 38, 38, 0.4);
      color: #fca5a5;
    }
    .alert.exito {
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #6ee7b7;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-size: 12.5px;
      color: var(--pf-gray-300);
      margin-bottom: 6px;
      font-weight: 600;
    }

    .form-group input {
      width: 100%;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 10px;
      padding: 12px 14px;
      color: #fff;
      font-family: 'Montserrat', sans-serif;
      font-size: 14px;
      transition: border-color 0.3s;
    }

    .form-group input::placeholder {
      color: var(--pf-gray-400);
    }

    .form-group input:focus {
      outline: none;
      border-color: var(--pf-sky-400);
    }

    .btn-submit {
      width: 100%;
      background: linear-gradient(120deg, var(--pf-brand-600), var(--pf-brand-700));
      color: #fff;
      border: none;
      padding: 14px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 15px;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 10px;
    }

    .btn-submit:hover {
      filter: brightness(1.1);
      transform: translateY(-2px);
    }

    .auth-switch {
      text-align: center;
      margin-top: 24px;
      padding-top: 20px;
      border-top: 1px solid rgba(255,255,255,0.08);
      font-size: 14px;
      color: var(--pf-gray-400);
    }

    .auth-switch a {
      color: var(--pf-sky-300);
      font-weight: 600;
      text-decoration: none;
      margin-left: 5px;
      transition: color 0.3s;
    }

    .auth-switch a:hover {
      color: #fff;
      text-decoration: underline;
    }

    footer {
      background: var(--pf-navy-950);
      border-top: 1px solid rgba(255,255,255,0.07);
      padding: 32px 80px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }

    footer .logo {
      font-size: 22px;
    }

    footer p {
      color: var(--pf-gray-400);
      font-size: 13px;
    }

    footer nav a {
      color: var(--pf-gray-300);
      text-decoration: none;
      font-size: 13px;
      margin-left: 22px;
      transition: 0.3s;
    }

    footer nav a:hover {
      color: var(--pf-sky-400);
    }

    @media screen and (max-width: 992px) {
      header { padding: 18px 24px; }
      nav a.nav-link { display: none; }
      footer {
        flex-direction: column;
        text-align: center;
        padding: 28px 24px;
      }
      footer nav a { margin: 0 10px; }
    }
  </style>
</head>
<body>

  <header>
    <a href="#" class="logo">MARCA</a>
    <nav>
      <a href="#" class="nav-link">Inicio</a>
      <a href="#" class="nav-link">Nosotros</a>
      <a href="#" class="nav-link">Contacto</a>
      <a href="login.php" class="btn-login active">Ingresar</a>
    </nav>
  </header>

  <main>
    <div class="auth-container">
      <div class="auth-header">
        <h2>Iniciar Sesión</h2>
        <p>Ingresa a tu cuenta para continuar</p>
      </div>

      <?php if (!empty($mensaje)): ?>
        <div class="alert <?php echo $tipo_mensaje; ?>">
          <?php echo $mensaje; ?>
        </div>
      <?php endif; ?>

      <form action="login.php" method="POST">
        <div class="form-group">
          <label for="email">Correo Electrónico</label>
          <input type="email" id="email" name="email" placeholder="usuario@correo.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
        </div>

        <div class="form-group">
          <label for="password">Contraseña</label>
          <input type="password" id="password" name="password" placeholder="••••••••" required>
        </div>

        <button type="submit" class="btn-submit">Ingresar</button>
      </form>

      <div class="auth-switch">
        ¿No tienes una cuenta? <a href="registrar.php">Regístrate aquí</a>
      </div>
    </div>
  </main>

  <footer>
    <div class="logo">MARCA</div>
    <p>&copy; 2026 Todos los derechos reservados.</p>
    <nav>
      <a href="#">Privacidad</a>
      <a href="#">Términos</a>
    </nav>
  </footer>

</body>
</html>