<?php
// conexión a la base
try {
    $config = "mysql:host=localhost;dbname=mcking;charset=utf8";
    $cnx = new PDO($config, 'root', '');
    $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $error) {
    die("Hubo un error en la conexión: " . $error->getMessage());
}
?>