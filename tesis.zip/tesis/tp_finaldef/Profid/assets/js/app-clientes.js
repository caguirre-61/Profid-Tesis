/* =========================================================================

   PROFID · INTERACCIÓN CON EL DOM, IA Y RENDERIZADO

   ========================================================================= */



   import {

    state,

    agregarPartida,

    guardarFacturaGlobal,

    setFacturaActual

  } from './state.js';

 

  // ---------- UTILIDADES DOM Y FORMATO ----------

  const $ = (sel) => document.querySelector(sel);

  const $$ = (sel) => document.querySelectorAll(sel);

 

  function formatMoney(n) {

    return "$" + Math.round(n || 0).toLocaleString("es-AR");

  }

 

  function formatFecha(iso) {

    if (!iso) return "-";

    const [y, m, d] = iso.split("-");

    return `${d}/${m}/${y}`;

  }

 

  function showToast(text, icon = "✔") {

    const t = $("#toast");

    if (!t) return;

    const iconEl = $("#toast-icon");

    const textEl = $("#toast-text");

   

    if (iconEl) iconEl.textContent = icon;

    if (textEl) textEl.textContent = text;

   

    t.classList.remove("opacity-0", "pointer-events-none");

    t.classList.add("opacity-100");

    clearTimeout(window._toastTimer);

    window._toastTimer = setTimeout(() => {

      t.classList.add("opacity-0", "pointer-events-none");

      t.classList.remove("opacity-100");

    }, 2600);

  }

 

  function unidadLabel(u) {

    const map = { bolsa: "Bolsa", kg: "kg", m3: "m³", unidad: "Unidad", barra: "Barra", litro: "Litro" };

    return map[u] || u;

  }

 

  // ---------- NAVEGACIÓN Y PESTAÑAS ----------

  const tabTitles = {

    dashboard: "DASHBOARD DE OBRA",

    carga: "CARGA DE FACTURAS IA",

    catalogo: "CATÁLOGO DE INSUMOS",

  };

 

  function switchTab(tab) {

    ["dashboard", "carga", "catalogo"].forEach(t => {

      const elem = $("#tab-" + t);

      if (elem) elem.classList.toggle("hidden-view", t !== tab);

    });

    $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));

    if ($("#topbar-title")) $("#topbar-title").textContent = tabTitles[tab];

    if ($("#mobile-nav")) $("#mobile-nav").value = tab;

   

    if (tab === "dashboard") renderDashboard();

    if (tab === "catalogo") renderCatalogo();

    if (tab === "carga") poblarSelectPartidas();

  }

 

  // ---------- DASHBOARD DE OBRA ----------

  let chartInstancia = null;

 

  function renderDashboard() {

    const totalAsignado = state.partidas.reduce((s, p) => s + p.asignado, 0);

    const totalGastado = state.partidas.reduce((s, p) => s + p.gastado, 0);

    const disponible = totalAsignado - totalGastado;

    const porcentaje = totalAsignado ? Math.min(100, (totalGastado / totalAsignado) * 100) : 0;

 

    if ($("#metric-total")) $("#metric-total").textContent = formatMoney(totalAsignado);

    if ($("#metric-gastado")) $("#metric-gastado").textContent = formatMoney(totalGastado);

    if ($("#metric-disponible")) $("#metric-disponible").textContent = formatMoney(disponible);

    if ($("#metric-porcentaje")) $("#metric-porcentaje").textContent = porcentaje.toFixed(1) + "%";

    if ($("#metric-porcentaje-bar")) $("#metric-porcentaje-bar").style.width = porcentaje + "%";

 

    // Render de Barras de Progreso por Partida

    const cont = $("#partidas-container");

    if (cont) {

      cont.innerHTML = "";

      if ($("#partidas-empty")) $("#partidas-empty").classList.toggle("hidden-view", state.partidas.length > 0);

 

      state.partidas.forEach(p => {

        const pct = p.asignado ? Math.min(100, (p.gastado / p.asignado) * 100) : 0;

        const excedido = p.gastado > p.asignado;

        const barStyle = excedido ? "background:var(--pf-red)" : (pct > 80 ? "background:var(--pf-amber)" : "");

 

        const row = document.createElement("div");

        row.innerHTML = `

          <div class="flex items-center justify-between mb-1.5 flex-wrap gap-1">

            <span class="text-sm font-semibold text-slate-700">${p.nombre}</span>

            <span class="text-xs ${excedido ? "font-semibold" : "text-gray-500"}" style="${excedido ? "color:var(--pf-red)" : ""}">

              ${formatMoney(p.gastado)} / ${formatMoney(p.asignado)} ${excedido ? "· ¡Excedido!" : ""}

            </span>

          </div>

          <div class="progress-track h-3">

            <div class="progress-fill h-3" style="width:${pct}%; ${barStyle}"></div>

          </div>

        `;

        cont.appendChild(row);

      });

    }

 

    // Tabla de Movimientos

    const body = $("#movimientos-body");

    if (body) {

      body.innerHTML = "";

      const ultimos = [...(state.movimientos || [])].reverse().slice(0, 8);

      if ($("#movimientos-empty")) $("#movimientos-empty").classList.toggle("hidden-view", ultimos.length > 0);

 

      ultimos.forEach(m => {

        const partidaNombre = state.partidas.find(p => p.id === m.partida)?.nombre || m.partida;

        const tr = document.createElement("tr");

        tr.innerHTML = `

          <td class="py-2.5 pr-4 font-medium text-slate-700">${m.proveedor}</td>

          <td class="py-2.5 pr-4 text-gray-500">${formatFecha(m.fecha)}</td>

          <td class="py-2.5 pr-4 text-gray-500">${m.insumo}</td>

          <td class="py-2.5 pr-4"><span class="badge" style="background:var(--pf-gray-100); color:var(--pf-gray-700)">${partidaNombre}</span></td>

          <td class="py-2.5 pr-4 text-right font-semibold text-slate-700">${formatMoney(m.total)}</td>

        `;

        body.appendChild(tr);

      });

    }

 

    // Actualización de Chart.js

    const canvasChart = document.getElementById("chartPresupuesto");

    if (canvasChart && typeof Chart !== "undefined") {

      if (chartInstancia) chartInstancia.destroy();

     

      chartInstancia = new Chart(canvasChart.getContext("2d"), {

        type: "bar",

        data: {

          labels: state.partidas.map(p => p.nombre),

          datasets: [

            { label: "Asignado", data: state.partidas.map(p => p.asignado), backgroundColor: "rgba(18, 58, 92, 0.85)" },

            { label: "Gastado", data: state.partidas.map(p => p.gastado), backgroundColor: "rgba(90, 169, 214, 0.85)" }

          ]

        },

        options: { responsive: true, maintainAspectRatio: false }

      });

    }

  }

 

  // ---------- CATÁLOGO DE INSUMOS ----------

  function renderCatalogo() {

    const filtro = $("#catalogo-filter");

    if (!filtro) return;

 

    const valorPrevio = filtro.value;

    filtro.innerHTML = '<option value="">Todas las partidas</option>';

    state.partidas.forEach(p => {

      const opt = document.createElement("option");

      opt.value = p.id;

      opt.textContent = p.nombre;

      filtro.appendChild(opt);

    });

    filtro.value = valorPrevio;

 

    const items = Object.values(state.catalogo || {});

    const term = ($("#catalogo-search")?.value || "").trim().toLowerCase();

    const partidaSel = filtro.value;

 

    const filtrados = items.filter(it => {

      const matchTerm = !term || it.insumo.toLowerCase().includes(term) || it.proveedor.toLowerCase().includes(term);

      const matchPartida = !partidaSel || it.partida === partidaSel;

      return matchTerm && matchPartida;

    }).sort((a, b) => a.insumo.localeCompare(b.insumo));

 

    const body = $("#catalogo-body");

    if (!body) return;

    body.innerHTML = "";

 

    if (filtrados.length === 0) {

      body.innerHTML = `<tr><td colspan="6" class="text-center text-gray-400 text-sm py-10">Aún no hay insumos cargados. Procesá una factura o conectá tu base de datos.</td></tr>`;

    }

 

    filtrados.forEach(it => {

      const partidaNombre = state.partidas.find(p => p.id === it.partida)?.nombre || it.partida;

      const tr = document.createElement("tr");

      tr.className = "hover:bg-gray-50";

      tr.innerHTML = `

        <td class="py-2.5 px-4 font-medium text-slate-700">${it.insumo}</td>

        <td class="py-2.5 px-4"><span class="badge" style="background:var(--pf-gray-100); color:var(--pf-gray-700)">${partidaNombre}</span></td>

        <td class="py-2.5 px-4 text-gray-500">${it.proveedor}</td>

        <td class="py-2.5 px-4 text-gray-500">${unidadLabel(it.unidad)}</td>

        <td class="py-2.5 px-4 text-right font-semibold text-slate-700">${formatMoney(it.precio)}</td>

        <td class="py-2.5 px-4 text-right text-gray-400 text-xs">${formatFecha(it.fecha)}</td>

      `;

      body.appendChild(tr);

    });

 

    const proveedoresUnicos = new Set(items.map(i => i.proveedor));

    const promedio = items.length ? items.reduce((s, i) => s + i.precio, 0) / items.length : 0;

    const ultimaFecha = items.reduce((max, i) => (!max || i.fecha > max) ? i.fecha : max, null);

 

    if ($("#cat-stat-items")) $("#cat-stat-items").textContent = items.length;

    if ($("#cat-stat-prov")) $("#cat-stat-prov").textContent = proveedoresUnicos.size;

    if ($("#cat-stat-avg")) $("#cat-stat-avg").textContent = formatMoney(promedio);

    if ($("#cat-stat-updated")) $("#cat-stat-updated").textContent = ultimaFecha ? formatFecha(ultimaFecha) : "-";

  }

 

  // ---------- MÓDULO EXTRACCIÓN IA / CARGA MANUAL ----------

  function poblarSelectPartidas() {

    const sel = $("#f-partida");

    if (!sel) return;

    const valorPrevio = sel.value;

    sel.innerHTML = "";

    state.partidas.forEach(p => {

      const opt = document.createElement("option");

      opt.value = p.id;

      opt.textContent = p.nombre;

      sel.appendChild(opt);

    });

    sel.value = valorPrevio;

    const sinPartidas = state.partidas.length === 0;

    if ($("#f-partida-warning")) $("#f-partida-warning").classList.toggle("hidden-view", !sinPartidas);

    sel.disabled = sinPartidas;

  }

 

  function setStep(n) {

    const dots = $$("#steps-row .step-dot, .step-dot");

    const lines = $$("#steps-row .step-line, .step-line");

 

    dots.forEach((dot, idx) => {

      const i = idx + 1;

      dot.classList.remove("active", "done");

      if (i < n) dot.classList.add("done");

      if (i === n) dot.classList.add("active");

    });

 

    lines.forEach((line, idx) => {

      const i = idx + 1;

      line.classList.toggle("done", n > i);

    });

  }

 

  function actualizarTotalFactura() {

    const cant = parseFloat($("#f-cantidad")?.value) || 0;

    const precio = parseFloat($("#f-precio")?.value) || 0;

    if ($("#f-total")) $("#f-total").textContent = formatMoney(cant * precio);

  }

 

  async function procesarFacturaConIA(file) {

    $("#ia-empty")?.classList.add("hidden-view");

    $("#ia-form")?.classList.add("hidden-view");

    $("#ia-success")?.classList.add("hidden-view");

    $("#ia-scanning")?.classList.remove("hidden-view");

    setStep(1);

 

    const mensajes = [

      "Subiendo documento...",

      "Analizando comprobante con Gemini IA...",

      "Extrayendo proveedor, insumos y montos...",

      "Preparando formulario de validación..."

    ];

    let msgIdx = 0;

    if ($("#ia-scanning-text")) $("#ia-scanning-text").innerHTML = mensajes[0] + '<span class="pulse-dot">...</span>';

   

    const timer = setInterval(() => {

      msgIdx = (msgIdx + 1) % mensajes.length;

      if ($("#ia-scanning-text")) $("#ia-scanning-text").innerHTML = mensajes[msgIdx] + '<span class="pulse-dot">...</span>';

    }, 900);

 

    const formData = new FormData();

    formData.append("factura", file);

 

    try {

      const res = await fetch("../api/procesar_factura.php", {

        method: "POST",

        body: formData

      });

 

      const data = await res.json();

      clearInterval(timer);

 

      if (!res.ok || data.error) {

        throw new Error(data.error || "Error en el procesamiento del servidor");

      }

 

      if ($("#f-proveedor")) $("#f-proveedor").value = data.proveedor || "";

      if ($("#f-fecha")) $("#f-fecha").value = data.fecha || new Date().toISOString().split("T")[0];

      if ($("#f-insumo")) $("#f-insumo").value = data.insumo || "";

      if ($("#f-unidad")) $("#f-unidad").value = (data.unidad || "unidad").toLowerCase();

      if ($("#f-cantidad")) $("#f-cantidad").value = data.cantidad || 1;

      if ($("#f-precio")) $("#f-precio").value = data.precio_unitario || 0;

 

      actualizarTotalFactura();

 

      $("#ia-scanning")?.classList.add("hidden-view");

      $("#ia-form")?.classList.remove("hidden-view");

      setStep(2);

      poblarSelectPartidas();

 

      showToast("Lectura completada por IA");

    } catch (err) {

      clearInterval(timer);

      resetIA();

      showToast(err.message || "No se pudo procesar la factura", "⚠");

      console.error(err);

    }

  }

 

  function resetIA() {

    setFacturaActual(null);

    if ($("#file-input")) $("#file-input").value = "";

   

    const form = $("#ia-form");

    if (form) {

      form.reset();

      form.classList.add("hidden-view");

      form.style.display = "none";

    }

 

    ["#ia-scanning", "#ia-success"].forEach(id => {

      const el = $(id);

      if (el) {

        el.classList.add("hidden-view");

        el.style.display = "none";

      }

    });

 

    const empty = $("#ia-empty");

    if (empty) {

      empty.classList.remove("hidden-view");

      empty.style.display = "block";

    }

 

    actualizarTotalFactura();

    setStep(0);

  }

 

  function renderAll() {

    renderDashboard();

    renderCatalogo();

  }

 

  // ---------- INICIALIZACIÓN Y EVENT LISTENERS ----------

  function initEvents() {

    // Navegación Pestañas

    $$(".nav-item").forEach(btn => {

      btn.addEventListener("click", () => switchTab(btn.dataset.tab));

    });

    if ($("#mobile-nav")) {

      $("#mobile-nav").addEventListener("change", (e) => switchTab(e.target.value));

    }

 

    // BOTÓN: Carga Manual Directa

    const btnCargaManual = $("#btn-carga-manual");

    if (btnCargaManual) {

      btnCargaManual.addEventListener("click", (e) => {

        e.preventDefault();

        e.stopPropagation();

   

        // 1. Ocultar los otros estados del módulo IA

        ["#ia-empty", "#ia-scanning", "#ia-success"].forEach(id => {

          const el = $(id);

          if (el) {

            el.classList.add("hidden-view");

            el.style.display = "none"; // Refuerzo directo

          }

        });

   

        // 2. Mostrar el formulario

        const form = $("#ia-form");

        if (form) {

          form.reset();

          form.classList.remove("hidden-view");

          form.style.display = "block"; // Fuerza la visibilidad ignorando reglas CSS previas

        }

   

        // 3. Cargar datos básicos de inicio

        if ($("#f-fecha")) {

          $("#f-fecha").value = new Date().toISOString().split("T")[0];

        }

   

        poblarSelectPartidas();

        actualizarTotalFactura();

        setStep(2);

      });

    }

 

    // Alta de Partidas

    if ($("#btn-nueva-partida")) {

      $("#btn-nueva-partida").addEventListener("click", () => $("#form-partida")?.classList.toggle("hidden-view"));

    }

    if ($("#btn-cancelar-partida")) {

      $("#btn-cancelar-partida").addEventListener("click", () => {

        $("#form-partida")?.classList.add("hidden-view");

        $("#form-partida")?.reset();

      });

    }

    if ($("#form-partida")) {

      $("#form-partida").addEventListener("submit", (e) => {

        e.preventDefault();

        const nombre = $("#np-nombre")?.value.trim();

        const asignado = $("#np-asignado")?.value;

        if (!nombre) return;

 

        agregarPartida(nombre, asignado);

        $("#form-partida").reset();

        $("#form-partida").classList.add("hidden-view");

        showToast("Partida de obra agregada");

        renderAll();

      });

    }

 

    // Búsqueda y Filtros en Catálogo

    if ($("#catalogo-search")) $("#catalogo-search").addEventListener("input", renderCatalogo);

    if ($("#catalogo-filter")) $("#catalogo-filter").addEventListener("change", renderCatalogo);

 

    // Carga de Archivos e IA (Eventos de Selección y Drag & Drop)

    const dropzone = $("#dropzone");

    const fileInput = $("#file-input");

 

    if (dropzone && fileInput) {

      dropzone.addEventListener("click", (e) => {

        if (e.target.closest("#btn-carga-manual")) return;

        fileInput.click();

      });

 

      fileInput.addEventListener("change", (e) => {

        const file = e.target.files[0];

        if (file) procesarFacturaConIA(file);

      });

 

      ['dragenter', 'dragover'].forEach(evt => {

        dropzone.addEventListener(evt, (e) => {

          e.preventDefault();

          e.stopPropagation();

          dropzone.classList.add("drag-over");

        });

      });

 

      ['dragleave', 'drop'].forEach(evt => {

        dropzone.addEventListener(evt, (e) => {

          e.preventDefault();

          e.stopPropagation();

          dropzone.classList.remove("drag-over");

        });

      });

 

      dropzone.addEventListener("drop", (e) => {

        const files = e.dataTransfer.files;

        if (files && files.length > 0) {

          fileInput.files = files;

          procesarFacturaConIA(files[0]);

        }

      });

    }

 

    // Recálculo dinámico de total al tipear

    ["f-cantidad", "f-precio"].forEach(id => {

      const el = $("#" + id);

      if (el) el.addEventListener("input", actualizarTotalFactura);

    });

 

    if ($("#btn-cancelar-ia")) $("#btn-cancelar-ia").addEventListener("click", resetIA);

    if ($("#btn-nueva-factura")) $("#btn-nueva-factura").addEventListener("click", resetIA);

    if ($("#btn-ver-dashboard")) {

      $("#btn-ver-dashboard").addEventListener("click", () => {

        resetIA();

        switchTab("dashboard");

      });

    }

 

    // Formulario Confirmación de Factura

    if ($("#ia-form")) {

      $("#ia-form").addEventListener("submit", (e) => {

        e.preventDefault();

 

        if (state.partidas.length === 0) {

          showToast("Agregá una partida de obra antes de guardar", "⚠");

          return;

        }

 

        const item = {

          proveedor: $("#f-proveedor")?.value.trim(),

          fecha: $("#f-fecha")?.value,

          insumo: $("#f-insumo")?.value.trim(),

          unidad: $("#f-unidad")?.value,

          cantidad: parseFloat($("#f-cantidad")?.value) || 0,

          precio: parseFloat($("#f-precio")?.value) || 0,

          partida: $("#f-partida")?.value,

        };

 

        if (!item.proveedor || !item.insumo || !item.fecha) {

          showToast("Completá proveedor, insumo y fecha", "⚠");

          return;

        }

 

        guardarFacturaGlobal(item);

 

        $("#ia-form").classList.add("hidden-view");

        $("#ia-success")?.classList.remove("hidden-view");

        setStep(3);

 

        showToast("Factura guardada · presupuesto y catálogo actualizados");

        renderAll();

      });

    }

  }

 

  function initUsuario() {

    if ($("#sidebar-avatar")) $("#sidebar-avatar").textContent = "U";

    if ($("#topbar-avatar")) $("#topbar-avatar").textContent = "U";

    if ($("#sidebar-name") && state.usuario) $("#sidebar-name").textContent = state.usuario.nombre || "Usuario";

    if ($("#sidebar-role") && state.usuario) $("#sidebar-role").textContent = state.usuario.rol || "Administrador";

    if ($("#topbar-project") && state.usuario) $("#topbar-project").textContent = state.usuario.proyecto || "Sin obra asignada";

  }

 

  // Inicializar la aplicación al cargar el DOM

  document.addEventListener("DOMContentLoaded", () => {

    setStep(0);

    initUsuario();

    initEvents();

    renderAll();

  }); 

