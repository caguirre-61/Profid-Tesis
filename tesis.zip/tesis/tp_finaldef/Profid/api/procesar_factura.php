<?php
header('Content-Type: application/json; charset=utf-8');

// 1. Clave de API de Google Gemini (Debe empezar con AIzaSy...)
$apiKey = 'AIzaSyAb8RN6IseJ6uFU17lOSH8f5yLQKZ3CVYpfcEYZx6XvhkyhRGmg'; 

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// 2. Validar que se haya subido un archivo sin errores
if (!isset($_FILES['factura']) || $_FILES['factura']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'No se subió ningún archivo o hubo un error en la carga']);
    exit;
}

$file = $_FILES['factura'];
$mimeType = mime_content_type($file['tmp_name']); // Detección segura del tipo MIME
$filePath = $file['tmp_name'];

// 3. Validar tipo de archivo (PDF e imágenes)
$allowedMimes = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg', 'image/webp'];
if (!in_array($mimeType, $allowedMimes)) {
    http_response_code(400);
    echo json_encode(['error' => 'Formato no soportado. Subí un PDF o una imagen (PNG, JPG, WEBP)']);
    exit;
}

// 4. Convertir archivo a Base64
$fileData = base64_encode(file_get_contents($filePath));

// 5. Prompt estructurado para Gemini
$prompt = "Analiza este comprobante/factura de compra de materiales de construcción y extrae los siguientes datos en formato JSON estricto:
- proveedor (nombre de la empresa o vendedor)
- fecha (formato YYYY-MM-DD)
- insumo (descripción corta del material principal)
- unidad (debe ser uno de estos valores exactos: 'bolsa', 'kg', 'm3', 'unidad', 'barra', 'litro')
- cantidad (número flotante o entero)
- precio_unitario (número flotante o entero, valor unitario del insumo sin símbolos de moneda)

Responde ÚNICAMENTE con el objeto JSON.";

// 6. Configurar la URL sin la clave en el parámetro
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";

$payload = [
    "contents" => [
        [
            "parts" => [
                ["text" => $prompt],
                [
                    "inline_data" => [
                        "mime_type" => $mimeType,
                        "data" => $fileData
                    ]
                ]
            ]
        ]
    ],
    "generationConfig" => [
        "temperature" => 0.1,
        "response_mime_type" => "application/json"
    ]
];

// 7. Petición enviando la clave AQ en el Header
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey, // Envío como Bearer token
    'x-goog-api-key: ' . $apiKey        // Envío como API Key header alternativa
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$apiResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// Desactivar verificación SSL solo si estás en un entorno local (XAMPP) con certificados desactualizados
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$apiResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

// Diagnóstico si falla la conexión cURL (ej. cURL desactivado o sin internet)
if ($curlError) {
    http_response_code(500);
    echo json_encode(['error' => 'Error cURL en PHP: ' . $curlError]);
    exit;
}

// Diagnóstico si Gemini responde con un error HTTP (ej. 400 por API Key inválida)
if ($httpCode !== 200) {
    http_response_code(500);
    $errorJson = json_decode($apiResponse, true);
    $detalleMsg = $errorJson['error']['message'] ?? 'Error no especificado por la API';
    echo json_encode(['error' => "Gemini API Error ($httpCode): " . $detalleMsg]);
    exit;
}

// 8. Decodificación y entrega del resultado
$result = json_decode($apiResponse, true);
$rawJsonText = $result['candidates'][0]['content']['parts'][0]['text'] ?? null;

if ($rawJsonText) {
    $parsedData = json_decode($rawJsonText, true);
    if ($parsedData) {
        echo json_encode($parsedData);
        exit;
    }
}

http_response_code(500);
echo json_encode(['error' => 'No se pudieron extraer los datos del comprobante. Intenta con una imagen más clara.']);