<?php
// guardar_factura.php
header('Content-Type: application/json');
require_once '../api/conexion.php';

$data = json_decode(file_get_contents('php://input'), true);

if ($data) {
    $sql = "INSERT INTO facturas (proveedor, fecha, insumo, unidad, cantidad, precio_unitario, total, partida_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $exito = $stmt->execute([
        $data['proveedor'],
        $data['fecha'],
        $data['insumo'],
        $data['unidad'],
        $data['cantidad'],
        $data['precio'],
        $data['total'],
        $data['partida_id']
    ]);

    echo json_encode(['success' => $exito]);
}
?>