<?php
session_start();
require_once '../api/conexion.php'; // Ajusta la ruta a tu conexion.php si es necesario

// Obtener la instancia de conexión PDO
$pdo = obtenerConexion();

$mensaje = "";
$tipo_mensaje = ""; // "exito" o "error"

// Procesar el formulario de Registro
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre   = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $rol      = $_POST['rol'] ?? 'obra';
    $proyecto = trim($_POST['proyecto'] ?? '');
    $empresa  = trim($_POST['empresa'] ?? '');
    $cuit     = trim($_POST['cuit'] ?? '');
    $password = $_POST['password'] ?? '';

    // Sanitizar campos vacíos
    $apellido = $apellido === '' ? NULL : $apellido;
    $telefono = $telefono === '' ? NULL : $telefono;
    $proyecto = ($rol === 'obra' && $proyecto !== '') ? $proyecto : NULL;
    $empresa  = ($rol === 'vendedor' && $empresa !== '') ? $empresa : NULL;
    $cuit     = $cuit === '' ? NULL : $cuit;

    if (empty($nombre) || empty($email) || empty($password)) {
        $mensaje = "Por favor, completa los campos obligatorios (*).";
        $tipo_mensaje = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "El correo electrónico no es válido.";
        $tipo_mensaje = "error";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        try {
            // Inserción adaptada a PDO mediante Marcadores Nombrados
            $sql = "INSERT INTO usuarios (nombre, apellido, email, telefono, password_hash, rol, proyecto, empresa, cuit) 
                    VALUES (:nombre, :apellido, :email, :telefono, :password_hash, :rol, :proyecto, :empresa, :cuit)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nombre'        => $nombre,
                ':apellido'      => $apellido,
                ':email'         => $email,
                ':telefono'      => $telefono,
                ':password_hash' => $password_hash,
                ':rol'           => $rol,
                ':proyecto'      => $proyecto,
                ':empresa'       => $empresa,
                ':cuit'          => $cuit
            ]);

            // Redirigir al login informando éxito
            header("Location: login.php?registro=exito");
            exit;

        } catch (PDOException $e) {
            // Capturar error de duplicado de email (Código de error estándar MySQL 23000 / 1062)
            if ($e->getCode() == 23000 || strpos($e->getMessage(), '1062') !== false) {
                $mensaje = "El correo electrónico ya está registrado.";
            } else {
                $mensaje = "Ocurrió un error al registrar la cuenta: " . $e->getMessage();
            }
            $tipo_mensaje = "error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro de Usuario - PROFID</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{
      --pf-navy-950:#08182A;
      --pf-navy-900:#0C2338;
      --pf-navy-800:#123A5C;
      --pf-brand-700:#18517C;
      --pf-brand-600:#1F6690;
      --pf-brand-500:#2B7FB0;
      --pf-sky-400:#5AA9D6;
      --pf-sky-300:#8FC6E6;
      --pf-gray-300:#CBD5E1;
      --pf-gray-400:#94A3B8;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: var(--pf-navy-950);
      color: #fff;
      overflow-x: hidden;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      background: linear-gradient(120deg, var(--pf-brand-700), var(--pf-brand-600));
      padding: 20px 60px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
      z-index: 10;
      box-shadow: 0 4px 18px rgba(8,24,42,0.35);
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
      font-family: 'Barlow Condensed', sans-serif;
      font-size: 30px;
      font-weight: 800;
      color: #fff;
      letter-spacing: 0.02em;
      text-decoration: none;
    }

    nav {
      display: flex;
      align-items: center;
    }

    nav a.nav-link {
      color: rgba(255,255,255,0.85);
      margin: 0 16px;
      text-decoration: none;
      font-weight: 600;
      font-size: 15px;
      padding: 8px 4px;
      border-bottom: 2px solid transparent;
      transition: all 0.3s ease;
    }

    nav a.nav-link:hover {
      color: #fff;
      border-color: var(--pf-sky-300);
    }

    nav a.btn-login {
      color: #fff;
      margin-left: 24px;
      text-decoration: none;
      font-weight: 700;
      font-size: 15px;
      padding: 10px 22px;
      border-radius: 50px;
      border: 2px solid rgba(255,255,255,0.6);
      transition: all 0.3s ease;
    }

    nav a.btn-login:hover,
    nav a.btn-login.active {
      color: var(--pf-brand-700);
      background-color: #fff;
      border-color: #fff;
    }

    main {
      flex: 1;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 60px 20px;
      background: radial-gradient(circle at 80% 20%, rgba(90,169,214,0.10), transparent 45%),
                  radial-gradient(circle at 10% 85%, rgba(43,127,176,0.12), transparent 40%),
                  var(--pf-navy-900);
    }

    .auth-container {
      width: 100%;
      max-width: 520px;
      background: linear-gradient(160deg, var(--pf-navy-800), var(--pf-navy-900));
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 25px 60px -25px rgba(0,0,0,0.6);
      position: relative;
      z-index: 2;
    }

    .auth-header {
      text-align: center;
      margin-bottom: 24px;
    }

    .auth-header h2 {
      font-family: 'Barlow Condensed', sans-serif;
      font-size: 36px;
      font-weight: 800;
      text-transform: uppercase;
      color: var(--pf-sky-400);
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }

    .auth-header p {
      color: var(--pf-gray-300);
      font-size: 14.5px;
    }

    .alert {
      padding: 12px 16px;
      border-radius: 10px;
      font-size: 14px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 600;
    }
    .alert.error {
      background: rgba(220, 38, 38, 0.15);
      border: 1px solid rgba(220, 38, 38, 0.4);
      color: #fca5a5;
    }
    .alert.exito {
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.4);
      color: #6ee7b7;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-size: 12.5px;
      color: var(--pf-gray-300);
      margin-bottom: 6px;
      font-weight: 600;
    }

    .form-group input, .form-group select {
      width: 100%;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 10px;
      padding: 12px 14px;
      color: #fff;
      font-family: 'Montserrat', sans-serif;
      font-size: 14px;
      transition: border-color 0.3s;
    }

    .form-group select option {
      background: var(--pf-navy-900);
      color: #fff;
    }

    .form-group input::placeholder {
      color: var(--pf-gray-400);
    }

    .form-group input:focus, .form-group select:focus {
      outline: none;
      border-color: var(--pf-sky-400);
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    .btn-submit {
      width: 100%;
      background: linear-gradient(120deg, var(--pf-brand-600), var(--pf-brand-700));
      color: #fff;
      border: none;
      padding: 14px;
      border-radius: 10px;
      font-weight: 700;
      font-size: 15px;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 10px;
    }

    .btn-submit:hover {
      filter: brightness(1.1);
      transform: translateY(-2px);
    }

    .auth-switch {
      text-align: center;
      margin-top: 24px;
      padding-top: 20px;
      border-top: 1px solid rgba(255,255,255,0.08);
      font-size: 14px;
      color: var(--pf-gray-400);
    }

    .auth-switch a {
      color: var(--pf-sky-300);
      font-weight: 600;
      text-decoration: none;
      margin-left: 5px;
      transition: color 0.3s;
    }

    .auth-switch a:hover {
      color: #fff;
      text-decoration: underline;
    }

    footer {
      background: var(--pf-navy-950);
      border-top: 1px solid rgba(255,255,255,0.07);
      padding: 32px 80px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }

    footer .logo {
      font-size: 22px;
    }

    footer p {
      color: var(--pf-gray-400);
      font-size: 13px;
    }

    footer nav a {
      color: var(--pf-gray-300);
      text-decoration: none;
      font-size: 13px;
      margin-left: 22px;
      transition: 0.3s;
    }

    footer nav a:hover {
      color: var(--pf-sky-400);
    }

    @media screen and (max-width: 992px) {
      header { padding: 18px 24px; }
      nav a.nav-link { display: none; }
      footer {
        flex-direction: column;
        text-align: center;
        padding: 28px 24px;
      }
      footer nav a { margin: 0 10px; }
      .form-row { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

  <header>
    <a href="#" class="logo">PROFID</a>
    <nav>
      <a href="#" class="nav-link">Inicio</a>
      <a href="#" class="nav-link">Nosotros</a>
      <a href="#" class="nav-link">Contacto</a>
      <a href="login.php" class="btn-login">Ingresar</a>
    </nav>
  </header>

  <main>
    <div class="auth-container">
      <div class="auth-header">
        <h2>Registro de Usuario</h2>
        <p>Crea tu cuenta para ingresar al sistema</p>
      </div>

      <?php if (!empty($mensaje)): ?>
        <div class="alert <?php echo $tipo_mensaje; ?>">
          <?php echo $mensaje; ?>
        </div>
      <?php endif; ?>

      <form action="registrar.php" method="POST">
        <div class="form-row">
          <div class="form-group">
            <label for="nombre">Nombre *</label>
            <input type="text" id="nombre" name="nombre" placeholder="Juan" value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>" required>
          </div>
          <div class="form-group">
            <label for="apellido">Apellido</label>
            <input type="text" id="apellido" name="apellido" placeholder="Pérez" value="<?php echo htmlspecialchars($_POST['apellido'] ?? ''); ?>">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="email">Correo Electrónico *</label>
            <input type="email" id="email" name="email" placeholder="usuario@correo.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
          </div>
          <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="tel" id="telefono" name="telefono" placeholder="+54 11 1234-5678" value="<?php echo htmlspecialchars($_POST['telefono'] ?? ''); ?>">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="rol">Tipo de Cuenta *</label>
            <select id="rol" name="rol" onchange="toggleCamposRol(this.value)">
              <option value="obra" <?php echo (($_POST['rol'] ?? '') === 'obra') ? 'selected' : ''; ?>>Usuario Obra</option>
              <option value="vendedor" <?php echo (($_POST['rol'] ?? '') === 'vendedor') ? 'selected' : ''; ?>>Vendedor / Proveedor</option>
            </select>
          </div>
          <div class="form-group">
            <label for="cuit">CUIT</label>
            <input type="text" id="cuit" name="cuit" placeholder="30-12345678-9" value="<?php echo htmlspecialchars($_POST['cuit'] ?? ''); ?>">
          </div>
        </div>

        <!-- Campo dinámico según el Rol elegido -->
        <div class="form-group" id="grupo-proyecto">
          <label for="proyecto">Nombre de la Obra / Proyecto</label>
          <input type="text" id="proyecto" name="proyecto" placeholder="Ej: Casa Familia Gómez" value="<?php echo htmlspecialchars($_POST['proyecto'] ?? ''); ?>">
        </div>

        <div class="form-group" id="grupo-empresa" style="display: none;">
          <label for="empresa">Razón Social / Empresa</label>
          <input type="text" id="empresa" name="empresa" placeholder="Ej: Corralón San Martín" value="<?php echo htmlspecialchars($_POST['empresa'] ?? ''); ?>">
        </div>

        <div class="form-group">
          <label for="password">Contraseña *</label>
          <input type="password" id="password" name="password" placeholder="Crea una contraseña segura" required>
        </div>

        <button type="submit" class="btn-submit">Crear Cuenta</button>
      </form>

      <div class="auth-switch">
        ¿Ya tienes una cuenta? <a href="login.php">Inicia sesión</a>
      </div>
    </div>
  </main>

  <footer>
    <div class="logo">PROFID</div>
    <p>&copy; 2026 Todos los derechos reservados.</p>
    <nav>
      <a href="#">Privacidad</a>
      <a href="#">Términos</a>
    </nav>
  </footer>

  <script>
    function toggleCamposRol(rol) {
      const grupoProyecto = document.getElementById('grupo-proyecto');
      const grupoEmpresa  = document.getElementById('grupo-empresa');
      if (rol === 'vendedor') {
        grupoProyecto.style.display = 'none';
        grupoEmpresa.style.display  = 'block';
      } else {
        grupoProyecto.style.display = 'block';
        grupoEmpresa.style.display  = 'none';
      }
    }
    // Ejecutar al cargar para mantener estado
    toggleCamposRol(document.getElementById('rol').value);
  </script>
</body>
</html>