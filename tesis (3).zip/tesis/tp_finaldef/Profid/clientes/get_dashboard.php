<?php
// get_dashboard.php
header('Content-Type: application/json');
require_once '../api/conexion.php';

// Ejemplo para traer partidas y totales
$stmt = $pdo->query("SELECT id, nombre, presupuesto_asignado, gasto_real FROM partidas");
$partidas = $stmt->fetchAll();

$totalPresupuesto = 0;
$totalGastado = 0;

foreach ($partidas as $p) {
    $totalPresupuesto += $p['presupuesto_asignado'];
    $totalGastado += $p['gasto_real'];
}

echo json_encode([
    'total' => $totalPresupuesto,
    'gastado' => $totalGastado,
    'disponible' => $totalPresupuesto - $totalGastado,
    'porcentaje' => $totalPresupuesto > 0 ? round(($totalGastado / $totalPresupuesto) * 100, 2) : 0,
    'partidas' => $partidas
]);
?>