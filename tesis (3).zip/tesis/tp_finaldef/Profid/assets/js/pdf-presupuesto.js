/* ProFid · Generador de PDF del presupuesto (jsPDF, 100% en el navegador) */
const money = (n) => "$" + Math.round(n || 0).toLocaleString("es-AR");

export function construirPDF(JsPDF, d) {
  const doc = new JsPDF({ unit: "mm", format: "a4" });
  const W = 210, M = 15, CW = W - M * 2, LIMITE = 272;
  const cols = [{ t: "Material", w: 78 }, { t: "Unidad", w: 20 }, { t: "Cantidad", w: 24 }, { t: "P. unitario", w: 28 }, { t: "Subtotal", w: 30 }];

  // Encabezado
  doc.setFillColor(12, 35, 56); doc.rect(0, 0, W, 26, "F");
  doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(20); doc.text("ProFid", M, 16);
  doc.setFont("helvetica", "normal"); doc.setFontSize(9);
  doc.text("Presupuesto de materiales de obra", M + 30, 16);
  doc.text(d.fecha, W - M, 16, { align: "right" });

  let y = 38;
  doc.setTextColor(15, 23, 42); doc.setFont("helvetica", "bold"); doc.setFontSize(15);
  doc.text(doc.splitTextToSize(d.titulo, CW), M, y); y += 9;

  doc.setFont("helvetica", "normal"); doc.setFontSize(10); doc.setTextColor(71, 85, 105);
  const info = [["Sistema", d.sistema], ["Medida", d.medida]].concat(d.opciones || []);
  if (d.partida) info.push(["Partida", d.partida]);
  if (d.ubicacion) info.push(["Ubicación", d.ubicacion]);
  info.forEach(([k, v]) => {
    const lineas = doc.splitTextToSize(String(v), CW - 32);
    doc.setFont("helvetica", "bold"); doc.text(k + ":", M, y);
    doc.setFont("helvetica", "normal"); doc.text(lineas, M + 32, y);
    y += 5.2 * lineas.length;
  });
  y += 4;

  const cabecera = () => {
    doc.setFillColor(24, 81, 124); doc.rect(M, y, CW, 8, "F");
    doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(9);
    let x = M;
    cols.forEach((c, i) => { i === 0 ? doc.text(c.t, x + 2, y + 5.5) : doc.text(c.t, x + c.w - 2, y + 5.5, { align: "right" }); x += c.w; });
    y += 8;
  };
  cabecera();

  doc.setFontSize(9);
  d.materiales.forEach((m, idx) => {
    const nombre = doc.splitTextToSize(m.nombre, cols[0].w - 4);
    const h = Math.max(7, nombre.length * 4.4 + 2.6);
    if (y + h > LIMITE) { doc.addPage(); y = 20; cabecera(); doc.setFontSize(9); }
    if (idx % 2 === 0) { doc.setFillColor(238, 242, 246); doc.rect(M, y, CW, h, "F"); }
    doc.setTextColor(15, 23, 42); doc.setFont("helvetica", "normal");
    doc.text(nombre, M + 2, y + 4.8);
    let x = M + cols[0].w;
    const celdas = [m.unidad, m.cantidad.toLocaleString("es-AR"), money(m.precio), money(m.cantidad * m.precio)];
    celdas.forEach((t, i) => { doc.text(String(t), x + cols[i + 1].w - 2, y + 4.8, { align: "right" }); x += cols[i + 1].w; });
    y += h;
  });

  // Total
  if (y + 14 > LIMITE) { doc.addPage(); y = 20; }
  y += 4;
  doc.setFillColor(12, 35, 56); doc.rect(M + CW - 80, y, 80, 11, "F");
  doc.setTextColor(255); doc.setFont("helvetica", "bold"); doc.setFontSize(10);
  doc.text("TOTAL ESTIMADO", M + CW - 77, y + 7);
  doc.setFontSize(12); doc.text(money(d.total), M + CW - 3, y + 7.3, { align: "right" });
  y += 18;

  // Datos técnicos
  const tec = Object.entries(d.tecnicos || {});
  if (tec.length) {
    if (y + 10 > LIMITE) { doc.addPage(); y = 20; }
    doc.setTextColor(15, 23, 42); doc.setFontSize(10); doc.text("Datos técnicos del cómputo", M, y); y += 6;
    doc.setFont("helvetica", "normal"); doc.setFontSize(9); doc.setTextColor(71, 85, 105);
    tec.forEach(([k, v]) => { if (y > LIMITE) { doc.addPage(); y = 20; } doc.text(`${k}: ${v}`, M, y); y += 5; });
  }

  // Pie de página
  const n = doc.internal.getNumberOfPages();
  for (let i = 1; i <= n; i++) {
    doc.setPage(i); doc.setFont("helvetica", "normal"); doc.setFontSize(8); doc.setTextColor(148, 163, 184);
    doc.text("Presupuesto estimativo: los precios son referenciales y pueden variar según el proveedor.", M, 288);
    doc.text(`Página ${i} de ${n}`, W - M, 288, { align: "right" });
  }
  return doc;
}