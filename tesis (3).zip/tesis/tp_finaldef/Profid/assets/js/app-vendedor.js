// 0. HELPERS GENERALES
const $ = id => document.getElementById(id);
const uuid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : 'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
// Fecha LOCAL en formato YYYY-MM-DD (toISOString usa UTC y de noche en Argentina devuelve el día siguiente)
const isoDate = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
const LS_CLIENTS = 'pf_vendedor_clients';
const LS_SYN = 'pf_vendedor_synonyms';
function loadJSON(k, d) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : d; } catch (e) { return d; } }
function saveJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { showToast('⚠️', 'No se pudo guardar (almacenamiento lleno)'); } }

// 1. CONSTANTES Y PERSISTENCIA DE DATOS
const LS_PRODUCTS = 'pf_vendedor_products';
const LS_DOCS = 'pf_vendedor_docs';
const LS_SALES = 'pf_vendedor_sales';
const LS_COLUMNS = 'pf_vendedor_custom_columns';
const CATEGORY_COLORS = {
  'Cemento y Áridos': '#5AA9D6',
  'Hierro y Aceros': '#E8A33D',
  'Ladrillos y Bloques': '#18517C',
  'Aislantes e Impermeabilizantes': '#1F9D64',
  'Pinturas': '#94A3B8',
  'Otros': '#64748B'
};
function seedProducts() {
  const fechas = ['2026-04-02', '2026-05-02', '2026-06-02', '2026-07-02', '2026-08-02', '2026-09-02'];
  const mk = (precios) => fechas.map((f, i) => ({ date: f, precio: precios[i] }));
  return [
    { id: uuid(), nombre: 'Cemento Portland x50kg', categoria: 'Cemento y Áridos', unidad: 'bolsa', proveedor: 'Loma Negra', precio: 10200, history: mk([8200, 8700, 9150, 9500, 9800, 10200]), customFields: {} },
    { id: uuid(), nombre: 'Hierro del 8 x12m', categoria: 'Hierro y Aceros', unidad: 'barra', proveedor: 'Aceros del Litoral', precio: 14200, history: mk([11800, 12300, 12900, 13500, 13900, 14200]), customFields: {} },
    { id: uuid(), nombre: 'Ladrillo hueco 18x18x33', categoria: 'Ladrillos y Bloques', unidad: 'unidad', proveedor: 'Ladrillera Don Pedro', precio: 650, history: mk([480, 510, 540, 580, 610, 650]), customFields: {} },
    { id: uuid(), nombre: 'Arena gruesa', categoria: 'Cemento y Áridos', unidad: 'm3', proveedor: 'Áridos Norte', precio: 42500, history: mk([33000, 35500, 37800, 39900, 41200, 42500]), customFields: {} },
    { id: uuid(), nombre: 'Cal hidratada x25kg', categoria: 'Cemento y Áridos', unidad: 'bolsa', proveedor: 'Cal y Cemento SRL', precio: 6200, history: mk([4800, 5100, 5400, 5700, 5950, 6200]), customFields: {} },
    { id: uuid(), nombre: 'Membrana asfáltica rollo 10m', categoria: 'Aislantes e Impermeabilizantes', unidad: 'rollo', proveedor: 'ImperTech', precio: 58500, history: mk([44000, 47500, 50800, 53900, 56200, 58500]), customFields: {} }
  ];
}
function loadProducts() {
  try {
    const raw = localStorage.getItem(LS_PRODUCTS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error cargando productos de localStorage", e);
  }
  const seeded = seedProducts();
  saveProducts(seeded);
  return seeded;
}
function saveProducts(list) {
  localStorage.setItem(LS_PRODUCTS, JSON.stringify(list));
}
function loadDocs() {
  try {
    const raw = localStorage.getItem(LS_DOCS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error cargando documentos de localStorage", e);
  }
  return [];
}
function saveDocs(list) {
  try {
    localStorage.setItem(LS_DOCS, JSON.stringify(list));
  } catch (e) {
    showToast('⚠️', 'No se pudieron guardar todos los archivos (límite de almacenamiento)');
  }
}
function seedSales(products) {
  if (!products || products.length < 3) return [];
  const hoy = isoDate();
  const haceDias = (n) => { const d = new Date(); d.setDate(d.getDate() - n); return isoDate(d); };
  return [
    { id: uuid(), cliente: 'Constructora Rivadavia SRL', productoId: products[0].id, productoNombre: products[0].nombre, cantidad: 40, fecha: haceDias(10), estado: 'Completado' },
    { id: uuid(), cliente: 'Constructora Rivadavia SRL', productoId: products[3].id, productoNombre: products[3].nombre, cantidad: 6, fecha: haceDias(3), estado: 'Pendiente' },
    { id: uuid(), cliente: 'Corralón San Martín', productoId: products[2].id, productoNombre: products[2].nombre, cantidad: 500, fecha: haceDias(6), estado: 'Completado' },
    { id: uuid(), cliente: 'Juan Pérez', productoId: products[1].id, productoNombre: products[1].nombre, cantidad: 12, fecha: hoy, estado: 'Pendiente' }
  ];
}
function loadSales() {
  try {
    const raw = localStorage.getItem(LS_SALES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error cargando ventas de localStorage", e);
  }
  const seeded = seedSales(loadProducts());
  saveSales(seeded);
  return seeded;
}
function saveSales(list) {
  localStorage.setItem(LS_SALES, JSON.stringify(list));
}
function loadCustomColumns() {
  try {
    const raw = localStorage.getItem(LS_COLUMNS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error("Error cargando columnas personalizadas de localStorage", e);
  }
  return [];
}
function saveCustomColumns(list) {
  localStorage.setItem(LS_COLUMNS, JSON.stringify(list));
}
// Estado local de la aplicación
const state = {
  products: loadProducts(),
  docs: loadDocs(),
  sales: loadSales(),
  customColumns: loadCustomColumns(),
  clients: loadJSON(LS_CLIENTS, []),
  synonyms: loadJSON(LS_SYN, []),
  activeTab: 'dashboard',
  pendingDelete: null,
  pendingDeleteVenta: null
};
// 2. UTILIDADES Y FORMATO
function fmtMoney(n) {
  return '$' + Math.round(n).toLocaleString('es-AR');
}
function fmtDate(d) {
  const dt = new Date(d + 'T00:00:00');
  return dt.toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' });
}
let toastTimer = null;
function showToast(icon, text) {
  const t = document.getElementById('toast');
  const tIcon = document.getElementById('toast-icon');
  const tText = document.getElementById('toast-text');
  if (!t || !tIcon || !tText) return;
  tIcon.textContent = icon;
  tText.textContent = text;
  t.classList.remove('opacity-0', 'pointer-events-none');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('opacity-0', 'pointer-events-none'), 2600);
}
function trendOf(product) {
  const h = product.history;
  if (!h || h.length < 2) return { dir: 'flat', pct: 0 };
  const prev = h[h.length - 2].precio, last = h[h.length - 1].precio;
  if (prev === 0) return { dir: 'flat', pct: 0 };
  const pct = ((last - prev) / prev) * 100;
  if (pct > 0.05) return { dir: 'up', pct };
  if (pct < -0.05) return { dir: 'down', pct };
  return { dir: 'flat', pct };
}

// 2B. POP UPS, ALERTAS Y HELPERS DE UI
const toast = (msg, icon = '✔') => showToast(icon, msg);
function popup({ title, msg, icon = '❓', ok = 'Aceptar', cancel = true, onOk }) {
  $('pp-title').textContent = title; $('pp-msg').textContent = msg; $('pp-icon').textContent = icon;
  $('pp-ok').textContent = ok; $('pp-cancel').style.display = cancel ? '' : 'none';
  $('popup').classList.remove('hidden-view');
  $('pp-ok').onclick = () => { $('popup').classList.add('hidden-view'); if (onOk) onOk(); };
  $('pp-cancel').onclick = () => $('popup').classList.add('hidden-view');
}
const alerta = (title, msg) => popup({ title, msg, icon: '⚠️', cancel: false });
const openModal = id => $(id).classList.remove('hidden-view');
const opts = (arr, sel) => arr.map(o => `<option${o === sel ? ' selected' : ''}>${esc(o)}</option>`).join('');

// 3. NAVEGACIÓN Y PESTAÑAS
const TAB_META = {
  dashboard: { title: 'PRECIOS DE MERCADO', sub: 'Evolución de precios de tu catálogo' },
  productos: { title: 'MIS PRODUCTOS', sub: 'Catálogo editable de tu empresa' },
  documentos: { title: 'DOCUMENTOS', sub: 'Facturas, listas de precios y sinónimos para la IA' },
  ventas: { title: 'VENTAS Y CLIENTES', sub: 'Registrá una venta en 3 pasos' }
};
function setTab(tab) {
  if (!tab || !TAB_META[tab]) return;
  state.activeTab = tab;
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  Object.keys(TAB_META).forEach(t => { const el = $('tab-' + t); if (el) el.classList.toggle('hidden-view', t !== tab); });
  $('topbar-title').textContent = TAB_META[tab].title;
  $('topbar-subtitle').textContent = TAB_META[tab].sub;
  if ($('mobile-nav')) $('mobile-nav').value = tab;
  if (tab === 'dashboard') { renderDashboard(); refreshCharts(); }
  if (tab === 'productos') renderProducts();
  if (tab === 'documentos') { renderDocs(); renderSynonyms(); }
  if (tab === 'ventas') { goStep(W.step); renderVentaProductoSelect(); renderVentas(); renderClientesSelect(); }
  window.scrollTo({ top: 0 });
}

// 4. LÓGICA DE PRODUCTOS
const CATS = Object.keys(CATEGORY_COLORS);
const UNIS = ['bolsa', 'kg', 'm3', 'unidad', 'barra', 'rollo', 'litro'];
// Busca un producto por nombre exacto o por sinónimo definido para la IA
function findProduct(nombre) {
  const n = norm(nombre); if (!n) return null;
  const s = state.synonyms.find(x => norm(x.alias) === n);
  return state.products.find(p => s ? p.id === s.productoId : norm(p.nombre) === n) || null;
}
function setPrice(p, precio) {
  if (precio === p.precio) return;
  p.precio = precio;
  const hoy = isoDate(), last = p.history[p.history.length - 1];
  if (last && last.date === hoy) last.precio = precio; else p.history.push({ date: hoy, precio });
}
function upsertProduct(o) {
  const p = findProduct(o.nombre);
  if (p) { setPrice(p, o.precio); return 'actualizado'; }
  state.products.push({
    id: uuid(), nombre: o.nombre, categoria: CATS.includes(o.categoria) ? o.categoria : 'Otros',
    unidad: UNIS.includes(o.unidad) ? o.unidad : 'unidad', proveedor: o.proveedor || '',
    precio: o.precio, history: [{ date: isoDate(), precio: o.precio }], customFields: {}
  });
  return 'nuevo';
}
function refreshProductViews() {
  saveProducts(state.products);
  renderProducts(); renderDashboard(); renderVentaProductoSelect();
  if (state.activeTab === 'dashboard') refreshCharts();
}
function renderProducts() {
  const body = $('productos-body'); if (!body) return;
  const cols = state.customColumns;
  $('productos-thead-row').innerHTML =
    ['Producto', 'Categoría', 'Unidad'].map(h => `<th class="py-3 px-3 font-medium">${h}</th>`).join('') +
    '<th class="py-3 px-3 font-medium text-right">Precio</th>' +
    cols.map(c => `<th class="py-3 px-3 font-medium">${esc(c.nombre)}</th>`).join('') +
    '<th class="py-3 px-3 font-medium text-right">Tendencia</th><th></th>';
  const q = norm($('productos-search').value);
  const list = state.products.filter(p => norm(p.nombre).includes(q) || norm(p.categoria).includes(q));
  $('productos-empty').classList.toggle('hidden-view', state.products.length > 0);
  body.innerHTML = list.map(p => {
    const tr = trendOf(p);
    const cls = tr.dir === 'up' ? 'trend-up' : tr.dir === 'down' ? 'trend-down' : 'trend-flat';
    const icon = tr.dir === 'up' ? '▲' : tr.dir === 'down' ? '▼' : '—';
    return `<tr data-id="${p.id}">
      <td class="px-2 py-1"><input class="cell" data-f="nombre" value="${esc(p.nombre)}"><input class="cell text-xs text-gray-400" data-f="proveedor" placeholder="Proveedor" value="${esc(p.proveedor)}"></td>
      <td class="px-2 py-1"><select class="cell" data-f="categoria">${opts(CATS, p.categoria)}</select></td>
      <td class="px-2 py-1"><select class="cell" data-f="unidad">${opts(UNIS, p.unidad)}</select></td>
      <td class="px-2 py-1"><input class="cell text-right" type="number" min="0" step="0.01" data-f="precio" value="${p.precio}"></td>
      ${cols.map(c => `<td class="px-2 py-1"><input class="cell" data-f="x:${c.id}" value="${esc((p.customFields || {})[c.id] ?? '')}"></td>`).join('')}
      <td class="px-3 py-1 text-right font-medium ${cls}">${icon} ${Math.abs(tr.pct).toFixed(1)}%</td>
      <td class="px-2 py-1 text-right"><button type="button" class="del-prod text-red-500 hover:bg-red-50 rounded px-2 py-1" title="Eliminar">🗑</button></td></tr>`;
  }).join('');
}
function onProductEdit(e) {
  const f = e.target.dataset.f; if (!f) return;
  const p = state.products.find(x => x.id === e.target.closest('tr').dataset.id); if (!p) return;
  const v = e.target.value.trim();
  if (f === 'nombre') { if (!v) { alerta('Nombre vacío', 'El producto necesita un nombre.'); e.target.value = p.nombre; return; } p.nombre = v; }
  else if (f === 'precio') {
    const n = parseFloat(v);
    if (isNaN(n) || n < 0) { alerta('Precio inválido', 'Ingresá un número mayor o igual a 0.'); e.target.value = p.precio; return; }
    setPrice(p, n);
  }
  else if (f.startsWith('x:')) { (p.customFields = p.customFields || {})[f.slice(2)] = v; }
  else p[f] = v;
  refreshProductViews(); toast('Cambio guardado');
}
function onProductDelete(e) {
  if (!e.target.closest('.del-prod')) return;
  const p = state.products.find(x => x.id === e.target.closest('tr').dataset.id); if (!p) return;
  popup({ title: 'Eliminar producto', msg: `¿Eliminar "${p.nombre}" del catálogo?`, icon: '🗑', ok: 'Eliminar', onOk: () => {
    state.products = state.products.filter(x => x !== p); refreshProductViews(); toast('Producto eliminado', '🗑️');
  } });
}
function addBlankRow() {
  state.products.unshift({ id: uuid(), nombre: 'Nuevo producto', categoria: 'Otros', unidad: 'unidad', proveedor: '', precio: 0, history: [{ date: isoDate(), precio: 0 }], customFields: {} });
  $('productos-search').value = ''; refreshProductViews();
  const i = $('productos-body').querySelector('input'); if (i) { i.focus(); i.select(); }
}
function submitProducto(e) {
  e.preventDefault();
  const nombre = $('p-nombre').value.trim(), precio = parseFloat($('p-precio').value);
  if (!nombre || isNaN(precio) || precio < 0) return alerta('Faltan datos', 'Completá el nombre y un precio válido.');
  popup({ title: 'Agregar producto', msg: `¿Agregar "${nombre}" a ${fmtMoney(precio)}?`, icon: '📦', ok: 'Agregar', onOk: () => {
    const r = upsertProduct({ nombre, categoria: $('p-categoria').value, unidad: $('p-unidad').value, precio, proveedor: $('p-proveedor').value.trim() });
    $('form-producto').reset(); refreshProductViews();
    toast(r === 'nuevo' ? 'Producto agregado al catálogo' : 'Ya existía: precio actualizado');
  } });
}

// 4B. CARGA MASIVA
function parseBulk(txt) {
  const ok = [], bad = [];
  txt.split(/\r?\n/).map(l => l.trim()).filter(Boolean).forEach(l => {
    const c = (/[\t;]/.test(l) ? l.split(/[\t;]/) : l.split(',')).map(x => x.trim());
    const precio = parseFloat((c.length >= 4 ? c[3] : c[c.length - 1]).replace(',', '.'));
    if (!c[0] || isNaN(precio) || precio < 0) return bad.push(l);
    ok.push(c.length >= 4 ? { nombre: c[0], categoria: c[1], unidad: c[2], precio, proveedor: c[4] } : { nombre: c[0], precio });
  });
  return { ok, bad };
}
function updateBulkCount() {
  const r = parseBulk($('m-text').value);
  $('m-count').textContent = `${r.ok.length} válidos` + (r.bad.length ? ` · ${r.bad.length} con error` : '');
}
function submitBulk() {
  const { ok, bad } = parseBulk($('m-text').value);
  if (!ok.length) return alerta('Nada para cargar', 'No hay líneas válidas. Formato: nombre; categoría; unidad; precio; proveedor');
  popup({ title: 'Carga masiva', msg: `Se van a ingresar ${ok.length} productos.` + (bad.length ? ` (${bad.length} líneas con error se omiten)` : ''), icon: '📥', ok: 'Cargar', onOk: () => {
    let n = 0, a = 0; ok.forEach(o => upsertProduct(o) === 'nuevo' ? n++ : a++);
    $('m-text').value = ''; updateBulkCount(); $('modal-masiva').classList.add('hidden-view');
    refreshProductViews(); setTab('productos'); toast(`${n} nuevos, ${a} actualizados`);
  } });
}


// 5. DASHBOARD, GRÁFICOS Y KPIS
let chartEvolucion = null, chartHoy = null;
function renderProductSelect() {
  const sel = document.getElementById('chart-producto-select');
  if (!sel) return;
  const current = sel.value;
  sel.innerHTML = state.products.map(p => `<option value="${p.id}">${esc(p.nombre)}</option>`).join('');
  if (state.products.some(p => p.id === current)) sel.value = current;
}
function drawEvolucionChart() {
  if (typeof Chart === 'undefined') return;
  const sel = document.getElementById('chart-producto-select');
  const canvas = document.getElementById('chart-evolucion');
  if (!sel || !canvas) return;
  const product = state.products.find(p => p.id === sel.value) || state.products[0];
  const ctx = canvas.getContext('2d');
  const labels = product ? product.history.map(h => fmtDate(h.date)) : [];
  const data = product ? product.history.map(h => h.precio) : [];
  if (chartEvolucion) chartEvolucion.destroy();
  chartEvolucion = new Chart(ctx, {
    type: 'line',
    data: {
      labels, datasets: [{
        label: product ? product.nombre : 'Sin datos',
        data,
        borderColor: '#2B7FB0',
        backgroundColor: 'rgba(90,169,214,0.14)',
        fill: true, tension: .3, pointRadius: 4, pointBackgroundColor: '#18517C', borderWidth: 2
      }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => fmtMoney(c.parsed.y) } } },
      scales: { y: { ticks: { callback: (v) => '$' + v.toLocaleString('es-AR') }, grid: { color: '#EEF2F6' } }, x: { grid: { display: false } } }
    }
  });
}
function drawHoyChart() {
  if (typeof Chart === 'undefined') return;
  const canvas = document.getElementById('chart-hoy');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const sorted = [...state.products].sort((a, b) => b.precio - a.precio).slice(0, 8);
  if (chartHoy) chartHoy.destroy();
  chartHoy = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: sorted.map(p => p.nombre.length > 16 ? p.nombre.slice(0, 15) + '…' : p.nombre),
      datasets: [{
        data: sorted.map(p => p.precio),
        backgroundColor: sorted.map(p => CATEGORY_COLORS[p.categoria] || '#64748B'),
        borderRadius: 6
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => fmtMoney(c.parsed.x) } } },
      scales: { x: { ticks: { callback: (v) => '$' + v.toLocaleString('es-AR') }, grid: { color: '#EEF2F6' } }, y: { grid: { display: false } } }
    }
  });
}
function refreshCharts() {
  renderProductSelect();
  if (typeof Chart === 'undefined') { showToast('⚠️', 'No se pudo cargar Chart.js (revisá tu conexión)'); return; }
  drawEvolucionChart();
  drawHoyChart();
}
function renderDashboard() {
  const n = state.products.length;
  const kpiProds = document.getElementById('kpi-productos');
  const kpiProm = document.getElementById('kpi-promedio');
  const kpiVar = document.getElementById('kpi-variacion');
  const kpiAct = document.getElementById('kpi-actualizado');
  const fechaHoy = document.getElementById('precios-hoy-fecha');
  if (kpiProds) kpiProds.textContent = n;
  const avg = n ? state.products.reduce((s, p) => s + p.precio, 0) / n : 0;
  if (kpiProm) kpiProm.textContent = fmtMoney(avg);
  const trends = state.products.map(trendOf).filter(t => t.dir !== 'flat');
  const avgVar = trends.length ? trends.reduce((s, t) => s + t.pct, 0) / trends.length : 0;
  if (kpiVar) {
    kpiVar.textContent = (avgVar >= 0 ? '+' : '') + avgVar.toFixed(1) + '%';
    kpiVar.style.color = avgVar > 0 ? 'var(--pf-amber)' : (avgVar < 0 ? 'var(--pf-green)' : 'var(--pf-gray-500)');
  }
  let lastDate = null;
  state.products.forEach(p => {
    const h = p.history[p.history.length - 1];
    if (h && (!lastDate || h.date > lastDate)) lastDate = h.date;
  });
  if (kpiAct) kpiAct.textContent = lastDate ? fmtDate(lastDate) : '-';
  if (fechaHoy) fechaHoy.textContent = 'Actualizado al ' + new Date().toLocaleDateString('es-AR', { day: '2-digit', month: 'long', year: 'numeric' });
  // Precios de hoy: tabla de detalle
  const hoy = [...state.products].sort((a, b) => b.precio - a.precio);
  const body = document.getElementById('precios-hoy-body');
  const emptyHoy = document.getElementById('precios-hoy-empty');
  if (emptyHoy) emptyHoy.classList.toggle('hidden-view', hoy.length !== 0);
  if (body) {
    body.innerHTML = hoy.map(p => {
      const tr = trendOf(p);
      const color = CATEGORY_COLORS[p.categoria] || 'var(--pf-gray-500)';
      const trendClass = tr.dir === 'up' ? 'trend-up' : tr.dir === 'down' ? 'trend-down' : 'trend-flat';
      const trendIcon = tr.dir === 'up' ? '▲' : tr.dir === 'down' ? '▼' : '—';
      return `<tr>
        <td class="py-2 pr-4 font-medium text-slate-700">${esc(p.nombre)}</td>
        <td class="py-2 pr-4"><span class="badge" style="background:${color}20; color:${color}">${esc(p.categoria)}</span></td>
        <td class="py-2 pr-4 text-gray-500">${esc(p.unidad)}</td>
        <td class="py-2 pr-4 text-right font-semibold">${fmtMoney(p.precio)}</td>
        <td class="py-2 pr-4 text-right font-medium ${trendClass}">${trendIcon} ${Math.abs(tr.pct).toFixed(1)}%</td>
      </tr>`;
    }).join('');
  }
}
// 5B. GESTIÓN DE COLUMNAS PERSONALIZADAS DEL CATÁLOGO
function renderColumnasModalList() {
  const list = document.getElementById('columnas-lista');
  if (!list) return;
  if (!state.customColumns.length) {
    list.innerHTML = '<p class="text-sm text-gray-400 text-center py-3">Todavía no agregaste columnas personalizadas.</p>';
    return;
  }
  list.innerHTML = state.customColumns.map(col => `
    <div class="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
      <span class="text-sm text-slate-700">${esc(col.nombre)}</span>
      <button type="button" class="btn-eliminar-columna text-xs font-semibold" style="color:var(--pf-red)" data-id="${col.id}">Eliminar</button>
    </div>`).join('');
  list.querySelectorAll('.btn-eliminar-columna').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      state.customColumns = state.customColumns.filter(c => c.id !== id);
      state.products.forEach(p => { if (p.customFields) delete p.customFields[id]; });
      saveCustomColumns(state.customColumns);
      saveProducts(state.products);
      renderColumnasModalList();
      renderProducts();
      showToast('🗑️', 'Columna eliminada');
    });
  });
}
// 5C. VENTAS Y CLIENTES
function renderVentaProductoSelect() {
  const sel = document.getElementById('v-producto');
  if (!sel) return;
  const current = sel.value;
  sel.innerHTML = state.products.map(p => `<option value="${p.id}">${esc(p.nombre)}</option>`).join('');
  if (state.products.some(p => p.id === current)) sel.value = current;
}
function renderVentas() {
  const body = document.getElementById('ventas-body');
  if (!body) return;
  const filtroCliente = (document.getElementById('ventas-filtro-cliente')?.value || '').trim().toLowerCase();
  const filtroFecha = document.getElementById('ventas-filtro-fecha')?.value || '';
  const filtroEstado = document.getElementById('ventas-filtro-estado')?.value || '';
  let list = [...state.sales].sort((a, b) => b.fecha.localeCompare(a.fecha));
  if (filtroCliente) list = list.filter(v => v.cliente.toLowerCase().includes(filtroCliente));
  if (filtroFecha) list = list.filter(v => v.fecha === filtroFecha);
  if (filtroEstado) list = list.filter(v => v.estado === filtroEstado);
  const emptyEl = document.getElementById('ventas-empty');
  if (emptyEl) emptyEl.classList.toggle('hidden-view', list.length !== 0);
  const estadoColor = { Completado: 'var(--pf-green)', Pendiente: 'var(--pf-amber)', Cancelado: 'var(--pf-red)' };
  body.innerHTML = list.map(v => {
    const color = estadoColor[v.estado] || 'var(--pf-gray-500)';
    const isDeleting = state.pendingDeleteVenta === v.id;
    return `
      <tr class="hover:bg-gray-50">
        <td class="py-3 px-4 font-medium text-slate-700">${esc(v.cliente)}</td>
        <td class="py-3 px-4 text-gray-600">${esc(v.productoNombre)}</td>
        <td class="py-3 px-4 text-gray-600 text-right">${v.cantidad}</td>
        <td class="py-3 px-4 text-gray-500">${fmtDate(v.fecha)}</td>
        <td class="py-3 px-4"><span class="badge" style="background:${color}20; color:${color}">${v.estado}</span></td>
        <td class="py-3 px-4 text-right whitespace-nowrap">
          <button type="button" class="btn-delete-venta text-xs font-semibold px-2 py-1 rounded" style="color:${isDeleting ? '#fff' : 'var(--pf-red)'}; background:${isDeleting ? 'var(--pf-red)' : 'transparent'}" data-id="${v.id}">${isDeleting ? 'Confirmar' : 'Eliminar'}</button>
        </td>
      </tr>`;
  }).join('');
  body.querySelectorAll('.btn-delete-venta').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      if (state.pendingDeleteVenta === id) {
        state.sales = state.sales.filter(v => v.id !== id);
        saveSales(state.sales);
        state.pendingDeleteVenta = null;
        showToast('🗑️', 'Venta eliminada');
        renderVentas();
        renderClientesSelect();
      } else {
        state.pendingDeleteVenta = id;
        renderVentas();
      }
    });
  });
}
function renderClientePreferencia(cliente) {
  const resumenEl = document.getElementById('cliente-preferencias-resumen');
  if (!resumenEl) return;
  if (!cliente) { resumenEl.innerHTML = ''; return; }
  const comprasCliente = state.sales.filter(v => v.cliente === cliente);
  const porProducto = {};
  comprasCliente.forEach(v => {
    if (!porProducto[v.productoNombre]) porProducto[v.productoNombre] = { cantidad: 0, compras: 0 };
    porProducto[v.productoNombre].cantidad += Number(v.cantidad) || 0;
    porProducto[v.productoNombre].compras += 1;
  });
  const productos = Object.entries(porProducto).sort((a, b) => b[1].cantidad - a[1].cantidad);
  const totalCompras = comprasCliente.length;
  resumenEl.innerHTML = `
    <p class="text-xs text-gray-400 mb-3">${totalCompras} compra${totalCompras !== 1 ? 's' : ''} registrada${totalCompras !== 1 ? 's' : ''}</p>
    <div class="space-y-2">
      ${productos.map(([nombre, info]) => `
        <div class="flex items-center justify-between border border-gray-100 rounded-lg px-3 py-2">
          <div>
            <p class="text-sm font-medium text-slate-700">${esc(nombre)}</p>
            <p class="text-xs text-gray-400">${info.compras} compra${info.compras !== 1 ? 's' : ''}</p>
          </div>
          <span class="badge" style="background:rgba(90,169,214,0.14); color:var(--pf-brand-600)">${info.cantidad} u.</span>
        </div>`).join('')}
    </div>`;
}
function renderClientesSelect() {
  const sel = document.getElementById('cliente-preferencias-select');
  if (!sel) return;
  const current = sel.value;
  const clientes = [...new Set(state.sales.map(v => v.cliente))].sort((a, b) => a.localeCompare(b));
  const emptyEl = document.getElementById('cliente-preferencias-empty');
  if (emptyEl) emptyEl.classList.toggle('hidden-view', clientes.length !== 0);
  sel.classList.toggle('hidden-view', clientes.length === 0);
  sel.innerHTML = clientes.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
  if (clientes.includes(current)) sel.value = current;
  renderClientePreferencia(clientes.length ? sel.value : null);
}

// 5D. VENTAS EN 3 PASOS (1 buscar/registrar cliente · 2 productos · 3 confirmar)
// Capa de datos de clientes: para conectar la base real, reemplazar SOLO estas funciones.
const DB = {
  // TODO(base de datos): autocompletado del nombre con el historial. Debe devolver [{ id, nombre }].
  // Ej: return (await fetch('/api/clientes?q=' + encodeURIComponent(q))).json();
  async sugerirClientes(q) { return []; }, // desactivado por ahora
  async buscarClientes(q) { const n = norm(q); return clientesConocidos().filter(c => norm(c.nombre).includes(n)); },
  async guardarCliente(nombre) { const c = { id: uuid(), nombre }; state.clients.push(c); saveJSON(LS_CLIENTS, state.clients); return c; },
  async guardarVenta(items) { state.sales.push(...items); saveSales(state.sales); }
};
// Clientes registrados + clientes que ya aparecen en el historial de ventas
function clientesConocidos() {
  const m = new Map();
  state.clients.forEach(c => m.set(norm(c.nombre), c));
  state.sales.forEach(v => { if (!m.has(norm(v.cliente))) m.set(norm(v.cliente), { id: 'h-' + norm(v.cliente), nombre: v.cliente }); });
  return [...m.values()].sort((a, b) => a.nombre.localeCompare(b.nombre));
}
let W = { step: 1, cliente: null, items: [] };
let lastRes = [];
const STEPS = ['Buscar / registrar cliente', 'Agregar productos', 'Confirmar venta'];
const totalVenta = () => W.items.reduce((a, i) => a + i.cantidad * i.precio, 0);
function goStep(n) {
  if (n >= 2 && !W.cliente) return alerta('Falta el cliente', 'Buscá o registrá un cliente para continuar.');
  if (n === 3 && !W.items.length) return alerta('Sin productos', 'Agregá al menos un producto a la venta.');
  W.step = n;
  [1, 2, 3].forEach(i => $('step-' + i).classList.toggle('hidden-view', i !== n));
  $('stepper').innerHTML = STEPS.map((s, i) => `<div class="flex items-center gap-2 ${i + 1 === n ? 'step-on' : i + 1 < n ? 'step-done' : ''}"><span class="step-dot">${i + 1 < n ? '✓' : i + 1}</span><span class="hidden sm:inline ${i + 1 === n ? 'font-semibold' : 'text-gray-500'}">${s}</span></div>${i < 2 ? '<span class="flex-1 h-px bg-gray-200"></span>' : ''}`).join('');
  if (n === 2) { $('s2-cliente').textContent = W.cliente.nombre; renderVentaProductoSelect(); renderItems(); }
  if (n === 3) {
    if (!$('v-fecha').value) $('v-fecha').value = isoDate();
    $('s3-resumen').innerHTML = `<p class="mb-2">Cliente: <b>${esc(W.cliente.nombre)}</b></p>` +
      W.items.map(i => `<div class="flex justify-between py-1 border-b border-gray-100"><span>${i.cantidad} × ${esc(i.productoNombre)}</span><span>${fmtMoney(i.cantidad * i.precio)}</span></div>`).join('') +
      `<p class="text-right font-bold mt-2">Total: ${fmtMoney(totalVenta())}</p>`;
  }
}
function resetWizard() { W = { step: 1, cliente: null, items: [] }; $('c-nombre').value = ''; $('c-result').innerHTML = ''; $('c-sugg').classList.add('hidden-view'); goStep(1); }
function pickCliente(c) { W.cliente = c; $('c-sugg').classList.add('hidden-view'); goStep(2); }
// Paso 1: buscar
async function buscarCliente() {
  const q = $('c-nombre').value.trim();
  if (!q) return alerta('Escribí un nombre', 'Ingresá el nombre o empresa del cliente.');
  lastRes = await DB.buscarClientes(q);
  const exact = lastRes.some(c => norm(c.nombre) === norm(q));
  $('c-result').innerHTML =
    (lastRes.length
      ? '<p class="text-sm text-gray-500 mb-2">Clientes registrados:</p>' + lastRes.map((c, i) => `<div class="flex items-center justify-between border border-gray-200 rounded-lg px-3 py-2 mb-2 text-sm"><span>👤 ${esc(c.nombre)}</span><button type="button" class="pick btn-primary text-xs font-bold px-3 py-1.5 rounded-lg" data-i="${i}">Seleccionar</button></div>`).join('')
      : '<p class="text-sm text-gray-500 mb-2">No hay ningún cliente registrado con ese nombre.</p>') +
    (exact ? '' : `<button type="button" id="c-reg" class="btn2">+ Registrar "${esc(q)}" como cliente nuevo</button>`);
  $('c-result').querySelectorAll('.pick').forEach(b => b.onclick = () => pickCliente(lastRes[b.dataset.i]));
  const r = $('c-reg'); if (r) r.onclick = agregarCliente;
}
// Paso 1: agregar (si no está)
async function agregarCliente() {
  const q = $('c-nombre').value.trim();
  if (!q) return alerta('Escribí un nombre', 'Ingresá el nombre del cliente que querés agregar.');
  const ex = clientesConocidos().find(c => norm(c.nombre) === norm(q));
  if (ex) return popup({ title: 'Ya está registrado', msg: `"${ex.nombre}" ya existe. ¿Usarlo para esta venta?`, icon: '👤', ok: 'Usarlo', onOk: () => pickCliente(ex) });
  popup({ title: 'Registrar cliente', msg: `¿Agregar a "${q}" como cliente nuevo?`, icon: '👤', ok: 'Agregar', onOk: async () => {
    const c = await DB.guardarCliente(q); toast('Cliente registrado'); pickCliente(c);
  } });
}
// Paso 1: autocompletado (listo; se activa cuando DB.sugerirClientes devuelva datos)
let sugTimer;
function onClienteInput() {
  clearTimeout(sugTimer);
  sugTimer = setTimeout(async () => {
    const q = $('c-nombre').value.trim(), box = $('c-sugg');
    if (q.length < 2) return box.classList.add('hidden-view');
    const s = await DB.sugerirClientes(q);
    if (!s || !s.length) return box.classList.add('hidden-view');
    box.innerHTML = s.map(c => `<button type="button" class="block w-full text-left px-3 py-2 text-sm hover:bg-gray-50">${esc(c.nombre)}</button>`).join('');
    box.classList.remove('hidden-view');
    box.querySelectorAll('button').forEach((b, i) => b.onclick = () => { $('c-nombre').value = s[i].nombre; box.classList.add('hidden-view'); buscarCliente(); });
  }, 250);
}
// Paso 2
function renderItems() {
  $('items-body').innerHTML = W.items.map((i, k) => `<tr><td class="px-3 py-2">${esc(i.productoNombre)}</td><td class="px-3 py-2 text-right">${i.cantidad}</td><td class="px-3 py-2 text-right">${fmtMoney(i.precio)}</td><td class="px-3 py-2 text-right">${fmtMoney(i.cantidad * i.precio)}</td><td class="px-2 text-right"><button type="button" data-k="${k}" class="rm text-red-500 px-2">🗑</button></td></tr>`).join('') +
    (W.items.length ? `<tr class="font-bold"><td colspan="3" class="px-3 py-2 text-right">Total</td><td class="px-3 py-2 text-right">${fmtMoney(totalVenta())}</td><td></td></tr>` : '');
  $('items-empty').classList.toggle('hidden-view', W.items.length > 0);
}
function addItem() {
  const p = state.products.find(x => x.id === $('v-producto').value), c = parseInt($('v-cantidad').value, 10);
  if (!p) return alerta('Sin productos', 'Primero cargá productos en "Mis Productos".');
  if (!c || c < 1) return alerta('Cantidad inválida', 'La cantidad debe ser 1 o más.');
  const ex = W.items.find(i => i.productoId === p.id);
  if (ex) ex.cantidad += c; else W.items.push({ productoId: p.id, productoNombre: p.nombre, cantidad: c, precio: p.precio });
  $('v-cantidad').value = 1; renderItems(); toast('Producto agregado');
}
// Paso 3: confirmar y mandar a Ventas
function confirmarVenta() {
  if (!$('v-fecha').value) return alerta('Falta la fecha', 'Elegí la fecha de la venta.');
  popup({ title: 'Confirmar venta', msg: `${W.items.length} producto(s) para ${W.cliente.nombre} por ${fmtMoney(totalVenta())}.`, icon: '🛒', ok: 'Confirmar', onOk: async () => {
    const ventaId = uuid(), fecha = $('v-fecha').value, estado = $('v-estado').value;
    await DB.guardarVenta(W.items.map(i => ({ id: uuid(), ventaId, cliente: W.cliente.nombre, productoId: i.productoId, productoNombre: i.productoNombre, cantidad: i.cantidad, precio: i.precio, fecha, estado })));
    resetWizard(); $('v-fecha').value = isoDate();
    renderVentas(); renderClientesSelect(); toast('Venta registrada en el historial');
    $('ventas-historial').scrollIntoView({ behavior: 'smooth' });
  } });
}

// 6. GESTIÓN DE DOCUMENTOS + IA
const MAX_INLINE_BYTES = 3 * 1024 * 1024; // 3MB
let PREV = [];
// Punto de conexión para la IA que lee facturas/listas. Debe devolver [{ nombre, unidad, precio }].
window.ProFidIA = window.ProFidIA || { async extraer(file) { return []; } };
async function handleFiles(fileList) {
  for (const file of Array.from(fileList)) {
    const isImage = file.type.startsWith('image/'), isPdf = file.type === 'application/pdf';
    if (!isImage && !isPdf) { showToast('⚠️', 'Solo se admiten PDF e imágenes'); continue; }
    const doc = { id: uuid(), nombre: file.name, tipo: isPdf ? 'pdf' : 'imagen', size: file.size, fecha: isoDate(), dataUrl: null };
    if (file.size <= MAX_INLINE_BYTES) doc.dataUrl = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.onerror = () => r(null); fr.readAsDataURL(file); });
    state.docs.unshift(doc); saveDocs(state.docs); renderDocs();
    showToast('🤖', 'Analizando con IA…');
    let items = [];
    try { items = (await window.ProFidIA.extraer(file)) || []; } catch (e) { alerta('Error de IA', 'No se pudo leer el documento. Podés cargar las filas a mano.'); }
    PREV = items.length ? items.map(i => ({ nombre: i.nombre, unidad: i.unidad || 'unidad', precio: i.precio })) : [{ nombre: '', unidad: 'unidad', precio: '' }];
    $('prev-doc').textContent = file.name; $('prev-card').classList.remove('hidden-view'); renderPrev();
    if (!items.length) showToast('ℹ️', 'IA sin conectar: cargá las filas a mano');
  }
}
function renderDocs() {
  const grid = $('docs-grid'); if (!grid) return;
  $('docs-empty').classList.toggle('hidden-view', state.docs.length !== 0);
  grid.innerHTML = state.docs.map(d => {
    const preview = d.tipo === 'imagen' && d.dataUrl ? `<img src="${d.dataUrl}" class="doc-thumb rounded-t-lg" alt="${esc(d.nombre)}">` : '<div class="doc-thumb rounded-t-lg flex items-center justify-center text-4xl">📄</div>';
    return `<div class="border border-gray-100 rounded-lg overflow-hidden card-elevate bg-white">${preview}
      <div class="p-3"><p class="text-xs font-semibold text-slate-700 truncate" title="${esc(d.nombre)}">${esc(d.nombre)}</p>
      <p class="text-[11px] text-gray-400">${fmtDate(d.fecha)} · ${(d.size / 1024).toFixed(0)} KB</p>
      <div class="flex gap-2 mt-2">${d.dataUrl ? `<a href="${d.dataUrl}" download="${esc(d.nombre)}" class="text-[11px] font-semibold" style="color:var(--pf-brand-600)">Descargar</a>` : ''}
      <button type="button" class="btn-delete-doc text-[11px] font-semibold ml-auto" style="color:var(--pf-red)" data-id="${d.id}">Eliminar</button></div></div></div>`;
  }).join('');
  grid.querySelectorAll('.btn-delete-doc').forEach(btn => btn.onclick = () => popup({ title: 'Eliminar documento', msg: '¿Eliminar este documento?', icon: '🗑', ok: 'Eliminar', onOk: () => {
    state.docs = state.docs.filter(d => d.id !== btn.dataset.id); saveDocs(state.docs); renderDocs(); showToast('🗑️', 'Documento eliminado');
  } }));
}
// Vista previa tipo tabla de lo que se va a ingresar
function renderPrev() {
  $('prev-body').innerHTML = PREV.map((r, i) => {
    const p = findProduct(r.nombre);
    return `<tr data-i="${i}"><td class="px-2 py-1"><input class="cell" data-f="nombre" value="${esc(r.nombre)}" placeholder="Producto"></td>
      <td class="px-2 py-1"><select class="cell" data-f="unidad">${opts(UNIS, r.unidad)}</select></td>
      <td class="px-2 py-1"><input class="cell text-right" type="number" min="0" step="0.01" data-f="precio" value="${r.precio ?? ''}"></td>
      <td class="px-3 py-1 text-xs">${p ? `<span class="badge" style="background:#FDF3E1;color:#9A6A12">Actualiza: ${esc(p.nombre)}</span>` : '<span class="badge" style="background:#E3F5EC;color:#15754A">Producto nuevo</span>'}</td>
      <td class="px-2 py-1"><button type="button" class="prev-del text-red-500 px-2">🗑</button></td></tr>`;
  }).join('');
}
function confirmarPrev() {
  const rows = PREV.filter(r => r.nombre && r.nombre.trim());
  if (!rows.length || rows.some(r => isNaN(r.precio) || r.precio === '' || r.precio < 0)) return alerta('Revisá la tabla', 'Cada fila necesita un producto y un precio válido.');
  popup({ title: 'Confirmar ingreso', msg: `Se van a ingresar ${rows.length} filas al catálogo.`, icon: '🤖', ok: 'Ingresar', onOk: () => {
    let n = 0, a = 0; rows.forEach(r => upsertProduct({ nombre: r.nombre.trim(), unidad: r.unidad, precio: r.precio }) === 'nuevo' ? n++ : a++);
    PREV = []; $('prev-card').classList.add('hidden-view'); refreshProductViews(); renderSynonyms(); toast(`${n} nuevos, ${a} actualizados`);
  } });
}
// Sinónimos para la IA
function renderSynonyms() {
  $('syn-prod').innerHTML = state.products.map(p => `<option value="${p.id}">${esc(p.nombre)}</option>`).join('') || '<option value="">(sin productos)</option>';
  $('syn-list').innerHTML = state.synonyms.length
    ? state.synonyms.map(s => `<div class="flex justify-between items-center py-1.5 border-b border-gray-100"><span>"${esc(s.alias)}" → <b>${esc((state.products.find(p => p.id === s.productoId) || {}).nombre || '¿?')}</b></span><button type="button" data-id="${s.id}" class="del-syn text-red-500 px-2">🗑</button></div>`).join('')
    : '<p class="text-gray-400">Sin sinónimos todavía.</p>';
}

// 7. INICIALIZACIÓN Y EVENT LISTENERS
function init() {
  // Navegación
  document.querySelectorAll('[data-tab]').forEach(btn => btn.addEventListener('click', e => setTab(e.target.closest('[data-tab]')?.dataset.tab)));
  if ($('mobile-nav')) $('mobile-nav').addEventListener('change', e => setTab(e.target.value));
  // Salir
  function cerrarSesion() { showToast('👋', 'Cerrando sesión...'); setTimeout(() => { window.location.href = '../login-principal.html'; }, 600); }
  ['btn-salir-sidebar', 'btn-salir-topbar'].forEach(id => $(id) && $(id).addEventListener('click', () => popup({ title: 'Cerrar sesión', msg: '¿Querés salir del portal?', icon: '👋', ok: 'Salir', onOk: cerrarSesion })));
  // Modales
  document.querySelectorAll('.close-modal').forEach(b => b.addEventListener('click', () => b.closest('.fixed').classList.add('hidden-view')));
  ['modal-columnas', 'modal-masiva'].forEach(id => $(id).addEventListener('click', e => { if (e.target === $(id)) $(id).classList.add('hidden-view'); }));
  // Productos
  $('p-categoria').innerHTML = opts(CATS); $('p-unidad').innerHTML = opts(UNIS);
  $('form-producto').addEventListener('submit', submitProducto);
  $('productos-body').addEventListener('change', onProductEdit);
  $('productos-body').addEventListener('click', onProductDelete);
  $('productos-search').addEventListener('input', renderProducts);
  $('btn-fila').addEventListener('click', addBlankRow);
  // Carga masiva
  $('btn-masiva').addEventListener('click', () => { openModal('modal-masiva'); $('m-text').focus(); });
  $('m-text').addEventListener('input', updateBulkCount);
  $('m-ok').addEventListener('click', submitBulk);
  $('m-file').addEventListener('change', e => { const f = e.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { $('m-text').value = r.result; updateBulkCount(); }; r.readAsText(f); e.target.value = ''; });
  // Columnas personalizadas
  $('btn-configurar-columnas').addEventListener('click', () => { renderColumnasModalList(); openModal('modal-columnas'); });
  $('form-nueva-columna').addEventListener('submit', e => {
    e.preventDefault();
    const input = $('nueva-columna-nombre'), nombre = input.value.trim();
    if (!nombre) return alerta('Nombre vacío', 'Escribí el nombre de la columna.');
    if (state.customColumns.some(c => norm(c.nombre) === norm(nombre))) return alerta('Columna repetida', 'Ya existe una columna con ese nombre.');
    state.customColumns.push({ id: uuid(), nombre }); saveCustomColumns(state.customColumns);
    input.value = ''; renderColumnasModalList(); renderProducts(); showToast('✔', 'Columna agregada');
  });
  // Documentos + IA
  const dz = $('file-dropzone'), fi = $('file-input');
  dz.addEventListener('click', () => fi.click());
  fi.addEventListener('change', e => { if (e.target.files.length) handleFiles(e.target.files); e.target.value = ''; });
  ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('drag-over'); }));
  ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('drag-over'); }));
  dz.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); });
  $('prev-body').addEventListener('change', e => { const f = e.target.dataset.f; if (!f) return; const r = PREV[e.target.closest('tr').dataset.i]; r[f] = f === 'precio' ? parseFloat(e.target.value) : e.target.value; renderPrev(); });
  $('prev-body').addEventListener('click', e => { if (e.target.closest('.prev-del')) { PREV.splice(e.target.closest('tr').dataset.i, 1); renderPrev(); } });
  $('prev-fila').addEventListener('click', () => { PREV.push({ nombre: '', unidad: 'unidad', precio: '' }); renderPrev(); });
  $('prev-cancel').addEventListener('click', () => { PREV = []; $('prev-card').classList.add('hidden-view'); });
  $('prev-ok').addEventListener('click', confirmarPrev);
  $('form-syn').addEventListener('submit', e => {
    e.preventDefault();
    const alias = $('syn-alias').value.trim(), productoId = $('syn-prod').value;
    if (!alias || !productoId) return alerta('Faltan datos', 'Escribí el nombre alternativo y elegí el producto.');
    state.synonyms.push({ id: uuid(), alias, productoId }); saveJSON(LS_SYN, state.synonyms);
    $('syn-alias').value = ''; renderSynonyms(); toast('Sinónimo guardado');
  });
  $('syn-list').addEventListener('click', e => { const b = e.target.closest('.del-syn'); if (b) { state.synonyms = state.synonyms.filter(s => s.id !== b.dataset.id); saveJSON(LS_SYN, state.synonyms); renderSynonyms(); } });
  // Ventas
  $('c-buscar').addEventListener('click', buscarCliente);
  $('c-agregar').addEventListener('click', agregarCliente);
  $('c-nombre').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); buscarCliente(); } });
  $('c-nombre').addEventListener('input', onClienteInput);
  $('s2-cambiar').addEventListener('click', () => { W.cliente = null; goStep(1); });
  document.querySelectorAll('.go-step').forEach(b => b.addEventListener('click', () => goStep(+b.dataset.go)));
  $('v-add').addEventListener('click', addItem);
  $('items-body').addEventListener('click', e => { const b = e.target.closest('.rm'); if (b) { W.items.splice(b.dataset.k, 1); renderItems(); } });
  $('v-confirm').addEventListener('click', confirmarVenta);
  ['ventas-filtro-cliente', 'ventas-filtro-fecha', 'ventas-filtro-estado'].forEach(id => { $(id).addEventListener('input', renderVentas); $(id).addEventListener('change', renderVentas); });
  $('cliente-preferencias-select').addEventListener('change', e => renderClientePreferencia(e.target.value));
  // Dashboard
  $('chart-producto-select').addEventListener('change', drawEvolucionChart);
  // Botón flotante (todas las vistas)
  $('fab').addEventListener('click', () => { $('fab-menu').classList.toggle('hidden-view'); $('fab').classList.toggle('open'); });
  $('fab-menu').addEventListener('click', e => {
    const a = e.target.closest('[data-fab]')?.dataset.fab; if (!a) return;
    $('fab-menu').classList.add('hidden-view'); $('fab').classList.remove('open');
    if (a === 'venta') { setTab('ventas'); resetWizard(); $('c-nombre').focus(); }
    if (a === 'producto') { setTab('productos'); $('p-nombre').focus(); }
    if (a === 'masiva') { setTab('productos'); openModal('modal-masiva'); $('m-text').focus(); }
    if (a === 'doc') { setTab('documentos'); $('file-input').click(); }
  });
  // Carga inicial
  $('v-fecha').value = isoDate();
  setTab(state.activeTab);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();