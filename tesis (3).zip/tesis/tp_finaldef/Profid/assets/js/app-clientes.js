// para borrar los saltos de linea pegar ^\s*\n en el cuadro de busqwuda (ctrl+f) (tildar la opcion .*) y luego reemplazar todo con espacio vacio
import {
  state,
  agregarPartida,
  guardarFacturaGlobal,
  setFacturaActual
} from './state.js';
import { construirPDF } from './pdf-presupuesto.js';
// ---------- UTILIDADES DOM Y FORMATO ----------
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);
function formatMoney(n) {
  return "$" + Math.round(n || 0).toLocaleString("es-AR");
}
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function formatFecha(iso) {
  if (!iso) return "-";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
function showToast(text, icon = "✔") {
  const t = $("#toast");
  if (!t) return;
  const iconEl = $("#toast-icon");
  const textEl = $("#toast-text");
  if (iconEl) iconEl.textContent = icon;
  if (textEl) textEl.textContent = text;
  t.classList.remove("opacity-0", "pointer-events-none");
  t.classList.add("opacity-100");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => {
    t.classList.add("opacity-0", "pointer-events-none");
    t.classList.remove("opacity-100");
  }, 2600);
}
function unidadLabel(u) {
  const map = { bolsa: "Bolsa", kg: "kg", m3: "m³", unidad: "Unidad", barra: "Barra", litro: "Litro" };
  return map[u] || u;
}
// ---------- NAVEGACIÓN Y PESTAÑAS ----------
const tabTitles = {
  dashboard: "DASHBOARD DE OBRA",
  carga: "CARGA DE FACTURAS IA",
  catalogo: "CATÁLOGO DE INSUMOS",
  presupuesto: "GENERAR MI PRESUPUESTO",
};
function getTabs() {
  return [...document.querySelectorAll('[id^="tab-"]')].map(el => el.id.replace("tab-", ""));
}
function switchTab(tab) {
  const tabs = getTabs();
  if (!tabs.includes(tab)) tab = tabs[0] || "dashboard";
  tabs.forEach(t => {
    const elem = $("#tab-" + t);
    if (elem) elem.classList.toggle("hidden-view", t !== tab);
  });
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  if ($("#topbar-title")) {
    $("#topbar-title").textContent = tabTitles[tab] || tab.toUpperCase();
  }
  if ($("#mobile-nav")) $("#mobile-nav").value = tab;
  if (tab === "dashboard") renderDashboard();
  if (tab === "catalogo") renderCatalogo();
  if (tab === "carga") poblarSelectPartidas();
  if (tab === "presupuesto") renderTiposProyecto();
}
// ---------- DASHBOARD DE OBRA ----------
let chartInstancia = null;
function renderDashboard() {
  const totalAsignado = state.partidas.reduce((s, p) => s + p.asignado, 0);
  const totalGastado = state.partidas.reduce((s, p) => s + p.gastado, 0);
  const disponible = totalAsignado - totalGastado;
  const porcentaje = totalAsignado ? Math.min(100, (totalGastado / totalAsignado) * 100) : 0;
  if ($("#metric-total")) $("#metric-total").textContent = formatMoney(totalAsignado);
  if ($("#metric-gastado")) $("#metric-gastado").textContent = formatMoney(totalGastado);
  if ($("#metric-disponible")) $("#metric-disponible").textContent = formatMoney(disponible);
  if ($("#metric-porcentaje")) $("#metric-porcentaje").textContent = porcentaje.toFixed(1) + "%";
  if ($("#metric-porcentaje-bar")) $("#metric-porcentaje-bar").style.width = porcentaje + "%";
  const badge = $("#resumen-estado");
  if (badge) {
    if (!state.partidas.length) {
      badge.textContent = "Sin datos";
      badge.style.background = "var(--pf-gray-100)";
      badge.style.color = "var(--pf-gray-700)";
    } else if (totalGastado > totalAsignado) {
      badge.textContent = "Presupuesto excedido";
      badge.style.background = "rgba(226,69,75,0.12)";
      badge.style.color = "var(--pf-red)";
    } else if (porcentaje > 80) {
      badge.textContent = "Cerca del límite";
      badge.style.background = "rgba(232,163,61,0.15)";
      badge.style.color = "var(--pf-amber)";
    } else {
      badge.textContent = "Dentro del presupuesto";
      badge.style.background = "rgba(31,157,100,0.12)";
      badge.style.color = "var(--pf-green)";
    }
  }
  const cont = $("#partidas-container");
  if (cont) {
    cont.innerHTML = "";
    if ($("#partidas-empty")) $("#partidas-empty").classList.toggle("hidden-view", state.partidas.length > 0);
    state.partidas.forEach(p => {
      const pct = p.asignado ? Math.min(100, (p.gastado / p.asignado) * 100) : 0;
      const excedido = p.gastado > p.asignado;
      const barStyle = excedido ? "background:var(--pf-red)" : (pct > 80 ? "background:var(--pf-amber)" : "");
      const row = document.createElement("div");
      row.innerHTML = `
        <div class="flex items-center justify-between mb-1.5 flex-wrap gap-1">
          <span class="text-sm font-semibold text-slate-700">${p.nombre}</span>
          <span class="text-xs ${excedido ? "font-semibold" : "text-gray-500"}" style="${excedido ? "color:var(--pf-red)" : ""}">
            ${formatMoney(p.gastado)} / ${formatMoney(p.asignado)} ${excedido ? "· ¡Excedido!" : ""}
          </span>
        </div>
        <div class="progress-track h-3">
          <div class="progress-fill h-3" style="width:${pct}%; ${barStyle}"></div>
        </div>
        ${p.ubicacion ? `<p class="text-xs text-gray-500 mt-1.5">📍 <a href="https://www.openstreetmap.org/?mlat=${p.ubicacion.lat}&mlon=${p.ubicacion.lon}#map=17/${p.ubicacion.lat}/${p.ubicacion.lon}" target="_blank" rel="noopener" class="underline">${esc(p.ubicacion.dir) || "Ver ubicación en el mapa"}</a></p>` : ""}
        ${(p.presupuestos || []).map(b => `<p class="text-xs text-gray-400 mt-0.5">🧮 ${esc(b.nombre)}: ${formatMoney(b.total)}</p>`).join("")}
      `;
      cont.appendChild(row);
    });
  }
  const body = $("#movimientos-body");
  if (body) {
    body.innerHTML = "";
    const ultimos = [...(state.movimientos || [])].reverse().slice(0, 8);
    if ($("#movimientos-empty")) $("#movimientos-empty").classList.toggle("hidden-view", ultimos.length > 0);
    ultimos.forEach(m => {
      const partidaNombre = state.partidas.find(p => p.id === m.partida)?.nombre || m.partida;
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="py-2.5 pr-4 font-medium text-slate-700">${m.proveedor}</td>
        <td class="py-2.5 pr-4 text-gray-500">${formatFecha(m.fecha)}</td>
        <td class="py-2.5 pr-4 text-gray-500">${m.insumo}</td>
        <td class="py-2.5 pr-4"><span class="badge" style="background:var(--pf-gray-100); color:var(--pf-gray-700)">${partidaNombre}</span></td>
        <td class="py-2.5 pr-4 text-right font-semibold text-slate-700">${formatMoney(m.total)}</td>
      `;
      body.appendChild(tr);
    });
  }
  const canvasChart = document.getElementById("chartPresupuesto");
  const chartEmpty = $("#chart-empty");
  const hayPartidas = state.partidas.length > 0;
  if (chartEmpty) chartEmpty.classList.toggle("hidden-view", hayPartidas);
  if (canvasChart) canvasChart.parentElement.classList.toggle("hidden-view", !hayPartidas);
  if (canvasChart && hayPartidas && typeof Chart !== "undefined") {
    if (chartInstancia) chartInstancia.destroy();
    chartInstancia = new Chart(canvasChart.getContext("2d"), {
      type: "bar",
      data: {
        labels: state.partidas.map(p => p.nombre),
        datasets: [
          { label: "Asignado", data: state.partidas.map(p => p.asignado), backgroundColor: "rgba(18, 58, 92, 0.85)", borderRadius: 4 },
          { label: "Gastado", data: state.partidas.map(p => p.gastado), backgroundColor: "rgba(90, 169, 214, 0.85)", borderRadius: 4 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ${ctx.dataset.label}: ${formatMoney(ctx.parsed.y)}`
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { callback: (v) => formatMoney(v) },
            grid: { color: "rgba(226,232,240,0.7)" }
          },
          x: { grid: { display: false } }
        }
      }
    });
  }
}
// ---------- CATÁLOGO DE INSUMOS ----------
function renderCatalogo() {
  const filtro = $("#catalogo-filter");
  if (!filtro) return;
  const valorPrevio = filtro.value;
  filtro.innerHTML = '<option value="">Todas las partidas</option>';
  state.partidas.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.nombre;
    filtro.appendChild(opt);
  });
  filtro.value = valorPrevio;
  const items = Object.values(state.catalogo || {});
  const term = ($("#catalogo-search")?.value || "").trim().toLowerCase();
  const partidaSel = filtro.value;
  const filtrados = items.filter(it => {
    const matchTerm = !term || it.insumo.toLowerCase().includes(term) || it.proveedor.toLowerCase().includes(term);
    const matchPartida = !partidaSel || it.partida === partidaSel;
    return matchTerm && matchPartida;
  }).sort((a, b) => a.insumo.localeCompare(b.insumo));
  const body = $("#catalogo-body");
  if (!body) return;
  body.innerHTML = "";
  if (filtrados.length === 0) {
    body.innerHTML = `<tr><td colspan="6" class="text-center text-gray-400 text-sm py-10">Aún no hay insumos cargados. Procesá una factura o conectá tu base de datos.</td></tr>`;
  }
  filtrados.forEach(it => {
    const partidaNombre = state.partidas.find(p => p.id === it.partida)?.nombre || it.partida;
    const tr = document.createElement("tr");
    tr.className = "hover:bg-gray-50";
    tr.innerHTML = `
      <td class="py-2.5 px-4 font-medium text-slate-700">${it.insumo}</td>
      <td class="py-2.5 px-4"><span class="badge" style="background:var(--pf-gray-100); color:var(--pf-gray-700)">${partidaNombre}</span></td>
      <td class="py-2.5 px-4 text-gray-500">${it.proveedor}</td>
      <td class="py-2.5 px-4 text-gray-500">${unidadLabel(it.unidad)}</td>
      <td class="py-2.5 px-4 text-right font-semibold text-slate-700">${formatMoney(it.precio)}</td>
      <td class="py-2.5 px-4 text-right text-gray-400 text-xs">${formatFecha(it.fecha)}</td>
    `;
    body.appendChild(tr);
  });
  const proveedoresUnicos = new Set(items.map(i => i.proveedor));
  const promedio = items.length ? items.reduce((s, i) => s + i.precio, 0) / items.length : 0;
  const ultimaFecha = items.reduce((max, i) => (!max || i.fecha > max) ? i.fecha : max, null);
  if ($("#cat-stat-items")) $("#cat-stat-items").textContent = items.length;
  if ($("#cat-stat-prov")) $("#cat-stat-prov").textContent = proveedoresUnicos.size;
  if ($("#cat-stat-avg")) $("#cat-stat-avg").textContent = formatMoney(promedio);
  if ($("#cat-stat-updated")) $("#cat-stat-updated").textContent = ultimaFecha ? formatFecha(ultimaFecha) : "-";
}
// ---------- MÓDULO EXTRACCIÓN IA / CARGA MANUAL ----------
function poblarSelectPartidas() {
  const sel = $("#f-partida");
  if (!sel) return;
  const valorPrevio = sel.value;
  sel.innerHTML = "";
  state.partidas.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.nombre;
    sel.appendChild(opt);
  });
  sel.value = valorPrevio;
  const sinPartidas = state.partidas.length === 0;
  if ($("#f-partida-warning")) $("#f-partida-warning").classList.toggle("hidden-view", !sinPartidas);
  sel.disabled = sinPartidas;
}
function setStep(n) {
  const fila = $("#steps-row");
  if (!fila) return;
  const dots = fila.querySelectorAll(".step-dot");
  const lines = fila.querySelectorAll(".step-line");
  dots.forEach((dot, idx) => {
    const i = idx + 1;
    dot.classList.remove("active", "done");
    if (i < n) dot.classList.add("done");
    if (i === n) dot.classList.add("active");
  });
  lines.forEach((line, idx) => {
    const i = idx + 1;
    line.classList.toggle("done", n > i);
  });
}
function actualizarTotalFactura() {
  const cant = parseFloat($("#f-cantidad")?.value) || 0;
  const precio = parseFloat($("#f-precio")?.value) || 0;
  if ($("#f-total")) $("#f-total").textContent = formatMoney(cant * precio);
}
let iaCola = [];
function cargarItemEnFormulario(it) {
  if ($("#f-insumo")) $("#f-insumo").value = it.insumo || "";
  if ($("#f-unidad")) $("#f-unidad").value = (it.unidad || "unidad").toLowerCase();
  if ($("#f-cantidad")) $("#f-cantidad").value = it.cantidad ?? 1;
  if ($("#f-precio")) $("#f-precio").value = it.precio_unitario ?? it.precio ?? 0;
  actualizarTotalFactura();
}
async function procesarFacturaConIA(file) {
  $("#ia-empty")?.classList.add("hidden-view");
  $("#ia-form")?.classList.add("hidden-view");
  $("#ia-success")?.classList.add("hidden-view");
  $("#ia-scanning")?.classList.remove("hidden-view");
  setStep(1);
  const mensajes = [
    "Subiendo documento...",
    "Analizando comprobante con Gemini IA...",
    "Extrayendo proveedor, insumos y montos...",
    "Preparando formulario de validación..."
  ];
  let msgIdx = 0;
  if ($("#ia-scanning-text")) {
    $("#ia-scanning-text").innerHTML = mensajes[0] + '<span class="pulse-dot">...</span>';
  }
  const timer = setInterval(() => {
    msgIdx = (msgIdx + 1) % mensajes.length;
    if ($("#ia-scanning-text")) {
      $("#ia-scanning-text").innerHTML = mensajes[msgIdx] + '<span class="pulse-dot">...</span>';
    }
  }, 900);
  const formData = new FormData();
  formData.append("factura", file);
  try {
    const res = await fetch("../api/procesar_factura.php", {
      method: "POST",
      body: formData
    });
    const rawText = await res.text();
    clearInterval(timer);
    let data;
    try {
      data = JSON.parse(rawText);
    } catch (jsonErr) {
      console.error("Respuesta no-JSON recibida desde PHP:", rawText);
      throw new Error(`El servidor devolvió un error (Código HTTP ${res.status}). Revisa la consola.`);
    }
    if (!res.ok || data.error) {
      throw new Error(data.error || "Error en el procesamiento del servidor");
    }
    const d = data.datos || data;
    const items = Array.isArray(d.items) && d.items.length ? d.items : [d];
    iaCola = items.slice(1);
    if ($("#f-proveedor")) $("#f-proveedor").value = d.proveedor || "";
    if ($("#f-fecha")) $("#f-fecha").value = d.fecha || new Date().toISOString().split("T")[0];
    cargarItemEnFormulario(items[0]);
    $("#ia-scanning")?.classList.add("hidden-view");
    $("#ia-form")?.classList.remove("hidden-view");
    setStep(2);
    poblarSelectPartidas();
    showToast(items.length > 1 ? `Lectura completada: ${items.length} ítems. Confirmalos de a uno.` : "Lectura completada por IA");
  } catch (err) {
    clearInterval(timer);
    resetIA();
    showToast(err.message || "No se pudo procesar la factura", "⚠");
    console.error("Detalle del error en procesarFacturaConIA:", err);
  }
}
function resetIA() {
  iaCola = [];
  setFacturaActual(null);
  if ($("#file-input")) $("#file-input").value = "";
  const form = $("#ia-form");
  if (form) {
    form.reset();
    form.classList.add("hidden-view");
    form.style.display = "";
  }
  ["#ia-scanning", "#ia-success"].forEach(id => {
    const el = $(id);
    if (el) {
      el.classList.add("hidden-view");
      el.style.display = "";
    }
  });
  const empty = $("#ia-empty");
  if (empty) {
    empty.classList.remove("hidden-view");
    empty.style.display = "";
  }
  actualizarTotalFactura();
  setStep(0);
}
function renderAll() {
  renderDashboard();
  renderCatalogo();
}
// ==========================================================
// ---------- CALCULADOR DE MATERIALES / PRESUPUESTO ----------
// ==========================================================
const PRECIOS_BASE = {
  placa_estandar: 18500, placa_humedad: 26900, placa_fuego: 31500,
  montante: 7800, solera: 7200, vela_rigida: 2100,
  tornillo_t1: 28, tornillo_t2: 22, fijacion: 95,
  masilla: 9800, cinta: 3200, lana_vidrio: 12500,
  LH8: 520, LH12: 780, LH18: 1150,
  BP12: 1290, BP18: 1780, BC: 1850, BD: 1980,
  LT11: 980, LT13: 1090,
  cemento: 10200, cal: 6200, arena: 42500, piedra: 48000,
  hierro8: 14200, hierro6: 9800, vigueta: 11500, malla_q188: 68000, hidrofugo: 8900,
};
const PIEZAS = {
  LH8:  { label: "Ladrillo hueco del 8 (8x18x33)",    porM2: 15.2, kgM2: 68,  pallet: 198, k: null, espesor: 0.08 },
  LH12: { label: "Ladrillo hueco del 12 (12x18x33)",  porM2: 15.2, kgM2: 92,  pallet: 144, k: 1.78, espesor: 0.12 },
  LH18: { label: "Ladrillo hueco del 18 (18x18x33)",  porM2: 15.2, kgM2: 133, pallet: 90,  k: 1.49, espesor: 0.18 },
  BP12: { label: "Bloque portante del 12 (12x19x33)", porM2: 15.2, kgM2: 88,  pallet: 114, k: 1.80, espesor: 0.12 },
  BP18: { label: "Bloque portante del 18 (18x19x33)", porM2: 15.2, kgM2: 108, pallet: 90,  k: 1.55, espesor: 0.18 },
  LT11: { label: "Ladrillo de techo del 11 (12x38x25)", porM2: 8,  kgM2: 183, pallet: 64,  k: 0.76, espesor: 0.11 },
  LT13: { label: "Ladrillo de techo del 13 (13x38x25)", porM2: 8,  kgM2: 186, pallet: 56,  k: 0.75, espesor: 0.13 },
};
const AREA_PLACA = 2.88, LARGO_PERFIL = 2.60, KG_BALDE = 32;
const M_ROLLO_CINTA = 90, M2_ROLLO_LANA = 12;
const KG_BOLSA_CEMENTO = 50, KG_BOLSA_CAL = 25, LARGO_BARRA = 12;
const SISTEMAS = {
  mamposteria: {
    grupo: "Mampostería tradicional", icono: "🧱", nombre: "Muro de ladrillo hueco",
    desc: "Tabiques y cerramientos no portantes con ladrillo cerámico.",
    unidad: "m2", vanos: true,
    opciones: {
      pieza: { label: "Tipo de ladrillo", opciones: [{ v: "LH8", t: "LH8 · del 8 (interior)" }, { v: "LH12", t: "LH12 · del 12" }, { v: "LH18", t: "LH18 · del 18 (cerramiento)" }], def: "LH18" },
      mortero: { label: "Mortero de asiento", opciones: [{ v: "1_4", t: "Cemento : cal : arena 1:1/4:4" }, { v: "1_3", t: "Reforzado 1:3 (cemento : arena)" }], def: "1_4" },
      revoque: { label: "Revoque", opciones: [{ v: "ambas", t: "Ambas caras (grueso + fino)" }, { v: "una", t: "Una cara" }, { v: "no", t: "Sin revoque" }], def: "ambas" },
    },
    calcular: (sup, o, desp, add) => {
      const p = PIEZAS[o.pieza];
      add(p.label, "unidad", sup * p.porM2 * desp, o.pieza);
      const m3Mortero = sup * 0.025 * desp;
      const dos = o.mortero === "1_3" ? { cem: 400, cal: 0, arena: 1.10 } : { cem: 270, cal: 90, arena: 1.10 };
      add("Cemento (bolsa 50 kg)", "bolsa", (m3Mortero * dos.cem) / KG_BOLSA_CEMENTO, "cemento");
      if (dos.cal) add("Cal hidratada (bolsa 25 kg)", "bolsa", (m3Mortero * dos.cal) / KG_BOLSA_CAL, "cal");
      add("Arena", "m3", m3Mortero * dos.arena, "arena", 2);
      const caras = o.revoque === "ambas" ? 2 : o.revoque === "una" ? 1 : 0;
      if (caras) {
        const m3Rev = sup * caras * 0.025 * desp;
        add("Cemento para revoque (bolsa 50 kg)", "bolsa", (m3Rev * 220) / KG_BOLSA_CEMENTO, "cemento");
        add("Cal para revoque (bolsa 25 kg)", "bolsa", (m3Rev * 130) / KG_BOLSA_CAL, "cal");
        add("Arena fina para revoque", "m3", m3Rev * 1.15, "arena", 2);
      }
      return { "Peso del muro": `${Math.round(sup * p.kgM2).toLocaleString("es-AR")} kg`, "Pallets (mín.)": Math.ceil((sup * p.porM2 * desp) / p.pallet), "Espesor": `${p.espesor * 100} cm`, "Transmitancia K": p.k ? `${p.k} W/m²K` : "—" };
    },
  },
  muro_portante: {
    grupo: "Mampostería tradicional", icono: "🏗️", nombre: "Muro portante (bloques)",
    desc: "Bloques portantes que reemplazan la estructura de hormigón armado.",
    unidad: "m2", vanos: true,
    opciones: {
      pieza: { label: "Tipo de bloque", opciones: [{ v: "BP12", t: "BP12 · del 12 (una planta)" }, { v: "BP18", t: "BP18 · del 18 (varias plantas)" }], def: "BP18" },
      columnas: { label: "Bloques columna (refuerzos)", opciones: [{ v: 1, t: "Sí, incluir" }, { v: 0, t: "No incluir" }], def: 1 },
      altura: { label: "Altura de muro para refuerzos (m)", opciones: [{ v: 2.6, t: "2,60 m" }, { v: 3, t: "3,00 m" }], def: 2.6 },
      dinteles: { label: "Metros lineales de dintel", opciones: [{ v: 0, t: "Sin dinteles" }, { v: 4, t: "4 m" }, { v: 8, t: "8 m" }, { v: 12, t: "12 m" }], def: 4 },
    },
    calcular: (sup, o, desp, add) => {
      const p = PIEZAS[o.pieza];
      add(p.label, "unidad", sup * p.porM2 * desp, o.pieza);
      if (Number(o.columnas) === 1) {
        const refuerzos = Math.max(2, Math.round(sup / 12));
        add("Bloque columna BC (18x19x33)", "unidad", refuerzos * Number(o.altura) * 5 * desp, "BC");
        add("Hierro del 8 (barra 12 m)", "barra", (refuerzos * Number(o.altura) * 4 * desp) / LARGO_BARRA, "hierro8");
      }
      if (Number(o.dinteles) > 0) {
        add("Bloque dintel BD (18x19x33)", "unidad", Number(o.dinteles) * 3 * desp, "BD");
      }
      const m3Mortero = sup * 0.022 * desp;
      add("Cemento (bolsa 50 kg)", "bolsa", (m3Mortero * 270) / KG_BOLSA_CEMENTO, "cemento");
      add("Cal hidratada (bolsa 25 kg)", "bolsa", (m3Mortero * 90) / KG_BOLSA_CAL, "cal");
      add("Arena", "m3", m3Mortero * 1.10, "arena", 2);
      if (Number(o.columnas) === 1) {
        const refuerzos = Math.max(2, Math.round(sup / 12));
        const m3Relleno = refuerzos * Number(o.altura) * 0.02;
        add("Cemento para relleno de columnas (bolsa 50 kg)", "bolsa", (m3Relleno * 350) / KG_BOLSA_CEMENTO, "cemento");
        add("Piedra partida", "m3", m3Relleno * 0.70, "piedra", 2);
      }
      return { "Peso del muro": `${Math.round(sup * p.kgM2).toLocaleString("es-AR")} kg`, "Pallets (mín.)": Math.ceil((sup * p.porM2 * desp) / p.pallet), "Espesor": `${p.espesor * 100} cm`, "Transmitancia K": `${p.k} W/m²K` };
    },
  },
  losa: {
    grupo: "Estructura y hormigón", icono: "🧱", nombre: "Losa / techo con ladrillo",
    desc: "Entrepiso o techo con viguetas premoldeadas y ladrillo cerámico.",
    unidad: "m2", vanos: false,
    opciones: {
      pieza: { label: "Ladrillo de techo", opciones: [{ v: "LT13", t: "LT13 · del 13 (techos y entrepisos)" }, { v: "LT11", t: "LT11 · del 11 (mayor altura de contrapiso)" }], def: "LT13" },
      separacion: { label: "Separación entre viguetas", opciones: [{ v: 0.50, t: "0,50 m (estándar)" }, { v: 0.42, t: "0,42 m (mayor carga)" }], def: 0.50 },
      capa: { label: "Capa de compresión", opciones: [{ v: 0.05, t: "5 cm" }, { v: 0.04, t: "4 cm" }], def: 0.05 },
      malla: { label: "Malla de repartición", opciones: [{ v: 1, t: "Sí, malla Q188" }, { v: 0, t: "No incluir" }], def: 1 },
    },
    calcular: (sup, o, desp, add) => {
      const p = PIEZAS[o.pieza];
      add(p.label, "unidad", sup * p.porM2 * desp, o.pieza);
      const mlVigueta = (sup / Number(o.separacion)) * desp;
      add("Vigueta premoldeada pretensada", "metro", mlVigueta, "vigueta", 1);
      const m3Hormigon = sup * Number(o.capa) * desp;
      add("Cemento para capa de compresión (bolsa 50 kg)", "bolsa", (m3Hormigon * 350) / KG_BOLSA_CEMENTO, "cemento");
      add("Arena", "m3", m3Hormigon * 0.65, "arena", 2);
      add("Piedra partida", "m3", m3Hormigon * 0.70, "piedra", 2);
      if (Number(o.malla) === 1) {
        add("Malla Q188 (panel 6 x 2,15 m)", "panel", (sup * 1.10) / 12.9, "malla_q188");
      }
      add("Hierro del 6 para bastones (barra 12 m)", "barra", (sup * 1.2 * desp) / LARGO_BARRA, "hierro6");
      return { "Peso propio": `${Math.round(sup * p.kgM2).toLocaleString("es-AR")} kg`, "Pallets (mín.)": Math.ceil((sup * p.porM2 * desp) / p.pallet), "Hormigón capa": `${(sup * Number(o.capa)).toFixed(2)} m³`, "Transmitancia K": `${p.k} W/m²K` };
    },
  },
  hormigon: {
    grupo: "Estructura y hormigón", icono: "🪨", nombre: "Hormigón por m³",
    desc: "Dosificación de hormigón para bases, vigas, columnas y platea.",
    unidad: "m3", vanos: false,
    opciones: {
      tipo: { label: "Tipo de hormigón", opciones: [{ v: "H21", t: "H21 · estructural (350 kg/m³)" }, { v: "H17", t: "H17 · bases y contrapisos (300 kg/m³)" }, { v: "H30", t: "H30 · alta resistencia (400 kg/m³)" }], def: "H21" },
      armadura: { label: "Armadura", opciones: [{ v: 80, t: "Media · 80 kg/m³ (vigas, columnas)" }, { v: 50, t: "Baja · 50 kg/m³ (bases)" }, { v: 120, t: "Alta · 120 kg/m³" }, { v: 0, t: "Sin armadura" }], def: 80 },
    },
    calcular: (m3, o, desp, add) => {
      const cem = { H17: 300, H21: 350, H30: 400 }[o.tipo] || 350;
      const vol = m3 * desp;
      add("Cemento (bolsa 50 kg)", "bolsa", (vol * cem) / KG_BOLSA_CEMENTO, "cemento");
      add("Arena", "m3", vol * 0.65, "arena", 2);
      add("Piedra partida", "m3", vol * 0.70, "piedra", 2);
      const kgHierro = vol * Number(o.armadura);
      if (kgHierro > 0) {
        add("Hierro del 8 (barra 12 m)", "barra", kgHierro / 4.74, "hierro8");
      }
      return { "Volumen": `${m3.toFixed(2)} m³`, "Cemento total": `${Math.round(vol * cem)} kg`, "Agua aprox.": `${Math.round(vol * 175)} litros`, "Acero": kgHierro ? `${Math.round(kgHierro)} kg` : "—" };
    },
  },
  contrapiso: {
    grupo: "Mampostería tradicional", icono: "🟫", nombre: "Contrapiso y carpeta",
    desc: "Contrapiso de hormigón pobre con carpeta de nivelación.",
    unidad: "m2", vanos: false, espesor: true,
    opciones: {
      carpeta: { label: "Carpeta de nivelación", opciones: [{ v: 1, t: "Sí, incluir (2 cm)" }, { v: 0, t: "No incluir" }], def: 1 },
      hidrofugo: { label: "Hidrófugo en carpeta", opciones: [{ v: 1, t: "Sí" }, { v: 0, t: "No" }], def: 1 },
    },
    calcular: (sup, o, desp, add, extra) => {
      const esp = extra.espesor || 0.10;
      const m3 = sup * esp * desp;
      add("Cemento para contrapiso (bolsa 50 kg)", "bolsa", (m3 * 200) / KG_BOLSA_CEMENTO, "cemento");
      add("Cal hidratada (bolsa 25 kg)", "bolsa", (m3 * 100) / KG_BOLSA_CAL, "cal");
      add("Arena", "m3", m3 * 0.55, "arena", 2);
      add("Piedra partida", "m3", m3 * 0.60, "piedra", 2);
      if (Number(o.carpeta) === 1) {
        const m3c = sup * 0.02 * desp;
        add("Cemento para carpeta (bolsa 50 kg)", "bolsa", (m3c * 400) / KG_BOLSA_CEMENTO, "cemento");
        add("Arena fina para carpeta", "m3", m3c * 1.10, "arena", 2);
        if (Number(o.hidrofugo) === 1) add("Hidrófugo (balde)", "balde", sup / 40, "hidrofugo");
      }
      return { "Espesor contrapiso": `${(esp * 100).toFixed(0)} cm`, "Volumen": `${m3.toFixed(2)} m³`, "Superficie": `${sup.toFixed(2)} m²`, "Carpeta": Number(o.carpeta) === 1 ? "2 cm" : "—" };
    },
  },
  tabique: {
    grupo: "Construcción en seco", icono: "🧊", nombre: "Pared / Tabique en seco",
    desc: "Tabique divisorio de placa de yeso con estructura de perfiles.",
    unidad: "m2", vanos: true,
    opciones: {
      caras: { label: "Caras a placar", opciones: [{ v: 2, t: "2 caras (tabique completo)" }, { v: 1, t: "1 cara" }], def: 2 },
      capas: { label: "Capas por cara", opciones: [{ v: 1, t: "1 capa" }, { v: 2, t: "2 capas" }], def: 1 },
      placa: { label: "Tipo de placa", opciones: [{ v: "placa_estandar", t: "Estándar" }, { v: "placa_humedad", t: "Resistente a la humedad" }, { v: "placa_fuego", t: "Resistente al fuego" }], def: "placa_estandar" },
      perfil: { label: "Ancho de montante", opciones: [{ v: 70, t: "70 mm" }, { v: 35, t: "35 mm" }, { v: 100, t: "100 mm" }], def: 70 },
      separacion: { label: "Separación de montantes", opciones: [{ v: 0.40, t: "0,40 m (estándar)" }, { v: 0.60, t: "0,60 m (económico)" }], def: 0.40 },
      aislacion: { label: "Lana de vidrio", opciones: [{ v: 1, t: "Sí, incluir" }, { v: 0, t: "No incluir" }], def: 1 },
    },
    calcular: (sup, o, desp, add) => calcularSeco("tabique", sup, o, desp, add),
  },
  revestimiento: {
    grupo: "Construcción en seco", icono: "🪟", nombre: "Revestimiento en seco",
    desc: "Placa aplicada sobre un muro de mampostería existente.",
    unidad: "m2", vanos: true,
    opciones: {
      capas: { label: "Capas", opciones: [{ v: 1, t: "1 capa" }, { v: 2, t: "2 capas" }], def: 1 },
      placa: { label: "Tipo de placa", opciones: [{ v: "placa_estandar", t: "Estándar" }, { v: "placa_humedad", t: "Resistente a la humedad" }, { v: "placa_fuego", t: "Resistente al fuego" }], def: "placa_estandar" },
      perfil: { label: "Ancho de montante", opciones: [{ v: 35, t: "35 mm" }, { v: 70, t: "70 mm" }], def: 35 },
      separacion: { label: "Separación de montantes", opciones: [{ v: 0.40, t: "0,40 m" }, { v: 0.60, t: "0,60 m" }], def: 0.40 },
      aislacion: { label: "Lana de vidrio", opciones: [{ v: 0, t: "No incluir" }, { v: 1, t: "Sí, incluir" }], def: 0 },
    },
    calcular: (sup, o, desp, add) => calcularSeco("revestimiento", sup, { ...o, caras: 1 }, desp, add),
  },
  cielorraso: {
    grupo: "Construcción en seco", icono: "🏠", nombre: "Cielorraso en seco",
    desc: "Cielorraso suspendido o aplicado con estructura de perfiles.",
    unidad: "m2", vanos: false,
    opciones: {
      capas: { label: "Capas", opciones: [{ v: 1, t: "1 capa" }, { v: 2, t: "2 capas" }], def: 1 },
      placa: { label: "Tipo de placa", opciones: [{ v: "placa_estandar", t: "Estándar" }, { v: "placa_humedad", t: "Resistente a la humedad" }, { v: "placa_fuego", t: "Resistente al fuego" }], def: "placa_estandar" },
      montaje: { label: "Tipo de montaje", opciones: [{ v: "suspendido", t: "Suspendido (con velas)" }, { v: "aplicado", t: "Aplicado (sin velas)" }], def: "suspendido" },
      separacion: { label: "Separación de perfiles", opciones: [{ v: 0.40, t: "0,40 m" }, { v: 0.60, t: "0,60 m" }], def: 0.40 },
      aislacion: { label: "Lana de vidrio", opciones: [{ v: 0, t: "No incluir" }, { v: 1, t: "Sí, incluir" }], def: 0 },
    },
    calcular: (sup, o, desp, add) => calcularSeco("cielorraso", sup, { ...o, caras: 1 }, desp, add),
  },
};
const PLACA_LABEL = {
  placa_estandar: "Placa de yeso estándar 12,5 mm (1,20 x 2,40)",
  placa_humedad: "Placa resistente a la humedad 12,5 mm (1,20 x 2,40)",
  placa_fuego: "Placa resistente al fuego 12,5 mm (1,20 x 2,40)",
};
const COEF_SECO = {
  tabique:      { montante: 1.10, solera: 0.70, t1: 14, t2: 4, fij: 2.0, masilla: 0.45, cinta: 1.25, lana: 1.0 },
  revestimiento:{ montante: 1.10, solera: 0.70, t1: 14, t2: 3, fij: 2.5, masilla: 0.45, cinta: 1.25, lana: 1.0 },
  cielorraso:   { montante: 2.20, solera: 0.40, t1: 17, t2: 5, fij: 1.5, masilla: 0.70, cinta: 1.70, lana: 1.0, velas: 1.2 },
};
function calcularSeco(tipo, sup, o, desp, add) {
  const c = COEF_SECO[tipo];
  const caras = Number(o.caras) || 1;
  const capas = Number(o.capas) || 1;
  const factorSep = (Number(o.separacion) || 0.40) === 0.60 ? 0.70 : 1;
  const supPlacada = sup * caras * capas;
  add(PLACA_LABEL[o.placa] || PLACA_LABEL.placa_estandar, "unidad", (supPlacada * desp) / AREA_PLACA, o.placa);
  const ancho = o.perfil ? ` ${o.perfil} mm` : "";
  add(`Montante${ancho}`, "barra", (sup * c.montante * factorSep * desp) / LARGO_PERFIL, "montante");
  add(`Solera${ancho}`, "barra", (sup * c.solera * desp) / LARGO_PERFIL, "solera");
  if (tipo === "cielorraso" && o.montaje === "suspendido") add("Vela rígida para cielorraso", "unidad", sup * c.velas * desp, "vela_rigida");
  add("Tornillo T1 punta aguja 25 mm", "unidad", sup * c.t1 * caras * capas * desp, "tornillo_t1");
  add("Tornillo T2 punta mecha 13 mm", "unidad", sup * c.t2 * desp, "tornillo_t2");
  add("Fijación con tarugo y tornillo", "unidad", sup * c.fij * desp, "fijacion");
  add("Masilla para juntas (balde x 32 kg)", "balde", (sup * c.masilla * caras * capas * desp) / KG_BALDE, "masilla");
  add("Cinta de papel para juntas (rollo x 90 m)", "rollo", (sup * c.cinta * caras * desp) / M_ROLLO_CINTA, "cinta");
  if (Number(o.aislacion) === 1) add("Lana de vidrio (rollo x 12 m²)", "rollo", (sup * c.lana * desp) / M2_ROLLO_LANA, "lana_vidrio");
  return { "Superficie": `${sup.toFixed(2)} m²`, "Placa colocada": `${supPlacada.toFixed(2)} m²`, "Caras": caras, "Capas": capas };
}
// ==========================================================
// ---------- RECOMENDADOR DE SISTEMA CONSTRUCTIVO ----------
// ==========================================================
const RECO_PREGUNTAS = {
  obra: {
    label: "¿Qué va a construir el cliente?",
    opciones: [
      { v: "casa", t: "Una casa desde cero" },
      { v: "ampliacion", t: "Una ampliación / piso nuevo" },
      { v: "interior", t: "Dividir ambientes interiores" },
      { v: "techo", t: "Un techo o entrepiso" },
    ], def: "casa",
  },
  prioridad: {
    label: "¿Qué es lo más importante para el cliente?",
    opciones: [
      { v: "costo", t: "Gastar lo menos posible" },
      { v: "velocidad", t: "Terminar rápido" },
      { v: "durabilidad", t: "Durabilidad y solidez" },
      { v: "aislacion", t: "Aislación térmica y acústica" },
    ], def: "costo",
  },
  plazo: {
    label: "¿Con qué plazo cuenta?",
    opciones: [
      { v: "corto", t: "Urgente (menos de 2 meses)" },
      { v: "medio", t: "Normal (2 a 6 meses)" },
      { v: "largo", t: "Sin apuro (más de 6 meses)" },
    ], def: "medio",
  },
  portante: {
    label: "¿El muro tiene que soportar carga?",
    opciones: [
      { v: "si", t: "Sí, es estructural" },
      { v: "no", t: "No, solo divide ambientes" },
      { v: "nose", t: "No lo sé todavía" },
    ], def: "no",
  },
};
const SISTEMAS_RECO = {
  tradicional: {
    nombre: "Construcción tradicional (ladrillo y cemento)",
    icono: "🧱", costo: "Media-alta", velocidad: "Lenta",
    resumen: "Muros de ladrillo cerámico asentados con mortero, revocados en obra húmeda.",
    pros: ["Muy durable y resistente", "Excelente masa acústica", "Mano de obra fácil de conseguir", "Admite colgar peso sin refuerzos"],
    contras: ["Obra lenta y sucia", "Mayor costo de mano de obra", "Requiere tiempos de secado", "Más peso sobre la estructura"],
    items: ["mamposteria", "contrapiso", "hormigon"],
  },
  seco: {
    nombre: "Construcción en seco (steel frame / placa de yeso)",
    icono: "🧊", costo: "Media", velocidad: "Muy rápida",
    resumen: "Estructura de perfiles con placas de yeso y aislación en el interior del tabique.",
    pros: ["Obra muy rápida y limpia", "Menos costo de mano de obra", "Excelente aislación térmica con lana", "Instalaciones fáciles de pasar y modificar"],
    contras: ["Menor masa acústica ante impactos", "Requiere refuerzos para colgar peso", "Sensible a humedad si no se usa placa verde", "Mano de obra especializada"],
    items: ["tabique", "revestimiento", "cielorraso"],
  },
  bloques: {
    nombre: "Bloques portantes",
    icono: "🏗️", costo: "Baja", velocidad: "Rápida",
    resumen: "Bloques que reemplazan la estructura independiente de hormigón armado.",
    pros: ["Reemplaza columnas y vigas: menos costo total", "No requiere mano de obra especializada", "Más rápido que el ladrillo común", "Menor espesor de muro"],
    contras: ["Requiere cálculo estructural", "Menos flexible para modificar después", "Necesita refuerzos en esquinas y dinteles", "Obra húmeda igual que el ladrillo"],
    items: ["muro_portante", "losa", "hormigon"],
  },
};
function puntuarSistemas(r) {
  const p = { tradicional: 0, seco: 0, bloques: 0 };
  const razones = { tradicional: [], seco: [], bloques: [] };
  if (r.obra === "casa") { p.bloques += 3; p.tradicional += 2; p.seco += 2; razones.bloques.push("ideal para vivienda completa sin estructura independiente"); }
  if (r.obra === "ampliacion") { p.seco += 3; p.bloques += 1; razones.seco.push("suma poco peso sobre lo existente"); }
  if (r.obra === "interior") { p.seco += 4; p.tradicional += 1; razones.seco.push("la mejor opción para dividir ambientes"); }
  if (r.obra === "techo") { p.bloques += 3; p.tradicional += 2; razones.bloques.push("losa con vigueta y ladrillo cerámico"); }
  if (r.prioridad === "costo") { p.bloques += 3; p.seco += 1; razones.bloques.push("menor costo final al evitar la estructura de hormigón"); }
  if (r.prioridad === "velocidad") { p.seco += 4; p.bloques += 2; razones.seco.push("es el sistema más rápido de ejecutar"); }
  if (r.prioridad === "durabilidad") { p.tradicional += 4; p.bloques += 3; razones.tradicional.push("máxima durabilidad y resistencia"); }
  if (r.prioridad === "aislacion") { p.seco += 3; p.bloques += 2; razones.seco.push("la lana de vidrio da muy buena aislación térmica"); }
  if (r.plazo === "corto") { p.seco += 3; razones.seco.push("no tiene tiempos de secado"); }
  if (r.plazo === "medio") { p.bloques += 2; p.seco += 1; }
  if (r.plazo === "largo") { p.tradicional += 2; razones.tradicional.push("el plazo holgado permite obra húmeda"); }
  if (r.portante === "si") { p.bloques += 4; p.tradicional += 2; p.seco -= 2; razones.bloques.push("tiene capacidad portante certificada"); }
  if (r.portante === "no") { p.seco += 3; razones.seco.push("no necesita capacidad estructural"); }
  return { p, razones };
}
const calc = { tipo: null, opciones: {}, materiales: [], medida: 0, tecnicos: {} };
const wz = { paso: -1, resp: {} }; // asistente: -1 intro · 0..n-1 preguntas · n resultado
function setCalcStep(n) {
  const fila = $("#calc-steps-row");
  if (!fila) return;
  fila.querySelectorAll(".step-dot").forEach((dot, idx) => {
    const i = idx + 1;
    dot.classList.remove("active", "done");
    if (i < n) dot.classList.add("done");
    if (i === n) dot.classList.add("active");
  });
  fila.querySelectorAll(".step-line").forEach((line, idx) => line.classList.toggle("done", n > idx + 1));
}
function renderTiposProyecto() {
  const cont = $("#calc-tipos");
  if (!cont || cont.dataset.rendered === "1") return;
  cont.innerHTML = "";
  const grupos = {};
  Object.entries(SISTEMAS).forEach(([id, s]) => {
    (grupos[s.grupo] = grupos[s.grupo] || []).push({ id, ...s });
  });
  Object.entries(grupos).forEach(([grupo, sistemas]) => {
    const bloque = document.createElement("div");
    bloque.innerHTML = `<p class="text-xs font-bold uppercase tracking-wide text-gray-400 mb-3">${grupo}</p>
      <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4" data-grid="${grupo}"></div>`;
    const grid = bloque.querySelector("[data-grid]");
    sistemas.forEach(sis => {
      const card = document.createElement("button");
      card.type = "button";
      card.className = "profile-card text-left bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-sky-400 transition";
      card.dataset.tipo = sis.id;
      card.innerHTML = `
        <div class="text-2xl mb-2">${sis.icono}</div>
        <p class="font-industrial text-base font-bold text-slate-800">${sis.nombre}</p>
        <p class="text-xs text-gray-500 mt-1">${sis.desc}</p>
        <span class="badge mt-2 inline-block" style="background:var(--pf-gray-100); color:var(--pf-gray-700)">Se mide en ${sis.unidad === "m3" ? "m³" : "m²"}</span>
      `;
      card.addEventListener("click", () => seleccionarTipo(sis.id));
      grid.appendChild(card);
    });
    cont.appendChild(bloque);
  });
  cont.dataset.rendered = "1";
}
function seleccionarTipo(tipoId) {
  calc.tipo = tipoId;
  calc.opciones = {};
  $$("#calc-tipos .profile-card").forEach(c => c.classList.toggle("selected", c.dataset.tipo === tipoId));
  renderOpciones();
  ajustarPasoMedidas();
  $("#calc-paso-2")?.classList.remove("hidden-view");
  $("#calc-paso-3")?.classList.remove("hidden-view");
  $("#calc-resultado")?.classList.add("hidden-view");
  setCalcStep(2);
  $("#calc-paso-2")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
function renderOpciones() {
  const cont = $("#calc-opciones");
  const sis = SISTEMAS[calc.tipo];
  if (!cont || !sis) return;
  cont.innerHTML = "";
  Object.entries(sis.opciones || {}).forEach(([key, cfg]) => {
    calc.opciones[key] = cfg.def;
    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <label class="text-xs text-gray-500 font-medium mb-1 block">${cfg.label}</label>
      <select data-opt="${key}" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none">
        ${cfg.opciones.map(o => `<option value="${o.v}" ${o.v === cfg.def ? "selected" : ""}>${o.t}</option>`).join("")}
      </select>`;
    const sel = wrap.querySelector("select");
    sel.addEventListener("change", () => {
      const raw = sel.value;
      calc.opciones[key] = isNaN(parseFloat(raw)) ? raw : parseFloat(raw);
      mostrarFichaPieza();
    });
    cont.appendChild(wrap);
  });
  mostrarFichaPieza();
}
function mostrarFichaPieza() {
  const ficha = $("#calc-ficha");
  if (!ficha) return;
  const p = PIEZAS[calc.opciones.pieza];
  if (!p) { ficha.classList.add("hidden-view"); return; }
  ficha.classList.remove("hidden-view");
  ficha.innerHTML = `
    <p class="font-semibold text-slate-700 mb-2">📋 Ficha técnica · ${p.label}</p>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-gray-600">
      <div><span class="text-gray-400 block">Rendimiento</span>${p.porM2} u/m²</div>
      <div><span class="text-gray-400 block">Peso</span>${p.kgM2} kg/m²</div>
      <div><span class="text-gray-400 block">Unidades por pallet</span>${p.pallet}</div>
      <div><span class="text-gray-400 block">Transmitancia K</span>${p.k ? p.k + " W/m²K" : "—"}</div>
    </div>`;
}
function ajustarPasoMedidas() {
  const sis = SISTEMAS[calc.tipo];
  if (!sis) return;
  const esM3 = sis.unidad === "m3";
  if ($("#calc-label-m2")) $("#calc-label-m2").textContent = esM3 ? "Volumen total (m³)" : "Superficie total (m²)";
  if ($("#calc-paso-3-sub")) $("#calc-paso-3-sub").textContent = esM3
    ? "Cargá el volumen de hormigón o calculalo por largo × alto × espesor"
    : "Cargá la superficie o calculala por largo × alto";
  if ($("#calc-label-alto")) $("#calc-label-alto").textContent = esM3 ? "Ancho (m)" : "Alto (m)";
  const usaEspesor = esM3 || sis.espesor;
  $("#calc-wrap-espesor")?.classList.toggle("hidden-view", !usaEspesor);
  if (usaEspesor && $("#calc-espesor")) {
    $("#calc-espesor").value = sis.espesor ? 0.10 : 0.20;
    if ($("#calc-label-espesor")) $("#calc-label-espesor").textContent = sis.espesor ? "Espesor contrapiso (m)" : "Espesor (m)";
  }
  $("#calc-descuentos")?.classList.toggle("hidden-view", !sis.vanos);
}
function precioDeCatalogo(nombreInsumo, precioDefault) {
  const items = Object.values(state.catalogo || {});
  const term = nombreInsumo.toLowerCase().split(" ")[0];
  const match = items.find(i => i.insumo && i.insumo.toLowerCase().includes(term));
  return match ? match.precio : (precioDefault || 0);
}
function calcularMateriales() {
  const sis = SISTEMAS[calc.tipo];
  if (!sis) { showToast("Elegí primero un ítem a calcular", "⚠"); return; }
  let medida = parseFloat($("#calc-m2")?.value) || 0;
  if (sis.vanos) {
    const vanos = parseFloat($("#calc-vanos")?.value) || 0;
    medida = Math.max(0, medida - vanos);
  }
  if (medida <= 0) { showToast("Ingresá una medida válida", "⚠"); return; }
  const desp = 1 + ((parseFloat($("#calc-desperdicio")?.value) || 0) / 100);
  const espesor = parseFloat($("#calc-espesor")?.value) || 0;
  calc.medida = medida;
  const mats = [];
  const add = (nombre, unidad, cantidad, precioKey, decimales = 0) => {
    if (!cantidad || cantidad <= 0) return;
    const cant = decimales ? +cantidad.toFixed(decimales) : Math.ceil(cantidad);
    mats.push({ nombre, unidad, cantidad: cant, precio: precioDeCatalogo(nombre, PRECIOS_BASE[precioKey]) });
  };
  calc.tecnicos = sis.calcular(medida, calc.opciones, desp, add, { espesor }) || {};
  calc.materiales = mats;
  renderResultado();
  setCalcStep(4);
  $("#calc-resultado")?.classList.remove("hidden-view");
  $("#calc-resultado")?.scrollIntoView({ behavior: "smooth", block: "start" });
}
function renderResultado() {
  const body = $("#calc-materiales-body");
  const sis = SISTEMAS[calc.tipo];
  if (!body || !sis) return;
  body.innerHTML = "";
  calc.materiales.forEach((m, idx) => {
    const tr = document.createElement("tr");
    tr.className = "hover:bg-gray-50";
    tr.innerHTML = `
      <td class="py-3 px-4 font-medium text-slate-700">${m.nombre}</td>
      <td class="py-3 px-4 text-gray-500">${m.unidad}</td>
      <td class="py-3 px-4 text-right font-semibold text-slate-700">${m.cantidad.toLocaleString("es-AR")}</td>
      <td class="py-3 px-4 text-right">
        <input type="number" min="0" step="0.01" value="${m.precio}" data-idx="${idx}"
          class="calc-precio-input w-28 border border-gray-300 rounded-lg px-2 py-1 text-sm text-right focus:outline-none">
      </td>
      <td class="py-3 px-4 text-right font-semibold text-slate-800" data-subtotal="${idx}">${formatMoney(m.cantidad * m.precio)}</td>`;
    body.appendChild(tr);
  });
  body.querySelectorAll(".calc-precio-input").forEach(input => {
    input.addEventListener("input", () => {
      const i = parseInt(input.dataset.idx, 10);
      calc.materiales[i].precio = parseFloat(input.value) || 0;
      const celda = body.querySelector(`[data-subtotal="${i}"]`);
      if (celda) celda.textContent = formatMoney(calc.materiales[i].cantidad * calc.materiales[i].precio);
      actualizarTotalCalc();
    });
  });
  const dt = $("#calc-datos-tecnicos");
  const entradas = Object.entries(calc.tecnicos || {});
  if (dt) {
    dt.classList.toggle("hidden-view", entradas.length === 0);
    dt.innerHTML = entradas.map(([k, v]) => `
      <div class="rounded-lg p-3 text-center" style="background:var(--pf-gray-50)">
        <p class="font-industrial text-lg font-bold text-slate-800">${v}</p>
        <p class="text-xs text-gray-500">${k}</p>
      </div>`).join("");
  }
  const unidad = sis.unidad === "m3" ? "m³" : "m²";
  if ($("#calc-resumen-texto")) {
    $("#calc-resumen-texto").textContent = `${calc.medida.toLocaleString("es-AR")} ${unidad} · ${sis.nombre}`;
  }
  if ($("#calc-nombre-partida") && !$("#calc-nombre-partida").value) {
    $("#calc-nombre-partida").value = `${sis.nombre} - ${calc.medida} ${unidad}`;
  }
  poblarDestinoCalc();
  actualizarTotalCalc();
}
const totalCalc = () => calc.materiales.reduce((s, m) => s + (m.cantidad * m.precio), 0);
function actualizarTotalCalc() {
  if ($("#calc-total")) $("#calc-total").textContent = formatMoney(totalCalc());
}
function reiniciarCalculador() {
  calc.tipo = null; calc.opciones = {}; calc.materiales = []; calc.medida = 0; calc.tecnicos = {};
  $$("#calc-tipos .profile-card").forEach(c => c.classList.remove("selected"));
  ["#calc-paso-2", "#calc-paso-3", "#calc-resultado"].forEach(id => $(id)?.classList.add("hidden-view"));
  ["#calc-largo", "#calc-alto", "#calc-m2", "#calc-nombre-partida", "#calc-vanos"].forEach(id => { if ($(id)) $(id).value = ""; });
  if ($("#calc-desperdicio")) $("#calc-desperdicio").value = 10;
  setCalcStep(1);
}
// ==========================================================
// ---------- ASISTENTE POR PASOS: SISTEMA CONSTRUCTIVO ----------
// ==========================================================
function irAlCalculador() {
  $("#wz")?.classList.add("hidden-view");
  $("#calc-wrapper")?.classList.remove("hidden-view");
  $("#calc-wrapper")?.scrollIntoView({ behavior: "smooth", block: "start" });
}
function volverAlAsistente() {
  $("#calc-wrapper")?.classList.add("hidden-view");
  $("#wz")?.classList.remove("hidden-view");
  $("#wz")?.scrollIntoView({ behavior: "smooth", block: "start" });
}
function renderAsistente() {
  const body = $("#wz-body");
  if (!body) return;
  const keys = Object.keys(RECO_PREGUNTAS);
  const n = keys.length;
  const btnSaltar = `<button type="button" data-wz="calc" class="border border-gray-300 text-gray-600 font-medium px-5 py-2.5 rounded-lg hover:bg-gray-50 text-sm">Ir directo al calculador</button>`;
  // --- Intro: ¿quiere ayuda? ---
  if (wz.paso < 0) {
    body.innerHTML = `
      <h2 class="font-industrial text-xl font-bold text-slate-800 mb-1">¿QUÉ SISTEMA LE CONVIENE AL CLIENTE?</h2>
      <p class="text-sm text-gray-500 mb-5">Antes de armar el presupuesto, ¿querés que te ayude a elegir el sistema constructivo? Son solo ${n} preguntas.</p>
      <div class="flex flex-col sm:flex-row gap-3">
        <button type="button" data-wz="start" class="btn-primary font-bold px-6 py-2.5 rounded-lg text-sm">Sí, ayudame</button>
        <button type="button" data-wz="calc" class="border border-gray-300 text-gray-600 font-medium px-6 py-2.5 rounded-lg hover:bg-gray-50 text-sm">No, ir al calculador</button>
      </div>`;
    return;
  }
  // --- Preguntas, de a una ---
  if (wz.paso < n) {
    const key = keys[wz.paso];
    const cfg = RECO_PREGUNTAS[key];
    body.innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <p class="text-xs font-semibold text-gray-500">PREGUNTA ${wz.paso + 1} DE ${n}</p>
        ${wz.paso > 0 ? `<button type="button" data-wz="back" class="text-xs font-semibold" style="color:var(--pf-brand-700)">← Atrás</button>` : ""}
      </div>
      <div class="progress-track h-2 mb-5"><div class="progress-fill h-2" style="width:${(wz.paso / n) * 100}%"></div></div>
      <h3 class="font-industrial text-lg font-bold text-slate-800 mb-4">${cfg.label}</h3>
      <div class="space-y-2 mb-5">
        ${cfg.opciones.map(o => `<button type="button" class="wz-opt ${wz.resp[key] === o.v ? "sel" : ""}" data-wz="ans" data-v="${o.v}">${o.t}</button>`).join("")}
      </div>
      <div class="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
        <span class="text-xs text-gray-400">Elegí una opción para seguir con las preguntas</span>
        <span class="sm:ml-auto">${btnSaltar}</span>
      </div>`;
    return;
  }
  // --- Resultado ---
  const { p, razones } = puntuarSistemas(wz.resp);
  const orden = Object.entries(p).sort((x, y) => y[1] - x[1]);
  const [ganadorId] = orden[0];
  const g = SISTEMAS_RECO[ganadorId];
  const maxPts = Math.max(...Object.values(p).map(v => Math.abs(v)), 1);
  const motivos = razones[ganadorId].length ? razones[ganadorId] : ["es el sistema más equilibrado para lo que necesita el cliente"];
  body.innerHTML = `
    <p class="text-xs font-semibold text-gray-500 mb-2">RECOMENDACIÓN</p>
    <div class="rounded-xl p-5 mb-4 border-2" style="border-color:var(--pf-sky-400); background:rgba(90,169,214,0.07)">
      <div class="flex items-start gap-4">
        <div class="text-4xl">${g.icono}</div>
        <div class="flex-1 min-w-0">
          <p class="font-industrial text-xl font-bold text-slate-800">${g.nombre}</p>
          <p class="text-sm text-gray-600 mt-1">${g.resumen}</p>
          <p class="text-sm text-slate-700 mt-3"><strong>Por qué:</strong> ${motivos.join("; ")}.</p>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div><p class="text-xs font-bold text-gray-500 mb-1">A FAVOR</p>
              <ul class="text-xs text-gray-600 space-y-1">${g.pros.map(x => `<li>✅ ${x}</li>`).join("")}</ul></div>
            <div><p class="text-xs font-bold text-gray-500 mb-1">A TENER EN CUENTA</p>
              <ul class="text-xs text-gray-600 space-y-1">${g.contras.map(x => `<li>⚠️ ${x}</li>`).join("")}</ul></div>
          </div>
        </div>
      </div>
    </div>
    <div class="space-y-3 mb-5">
      ${orden.map(([id, pts]) => {
        const s = SISTEMAS_RECO[id];
        const pct = Math.max(0, (pts / maxPts) * 100);
        return `<div>
          <div class="flex justify-between text-xs mb-1"><span class="font-medium text-slate-700">${s.icono} ${s.nombre}</span><span class="text-gray-500">Costo ${s.costo} · ${s.velocidad}</span></div>
          <div class="progress-track h-2"><div class="progress-fill h-2" style="width:${pct}%"></div></div>
        </div>`;
      }).join("")}
    </div>
    <p class="text-xs font-bold uppercase tracking-wide text-gray-400 mb-2">Calculá los ítems de este sistema</p>
    <div class="flex flex-wrap gap-2 mb-5">
      ${g.items.map(id => `<button type="button" data-wz="goto" data-id="${id}" class="text-sm font-semibold px-4 py-2 rounded-lg border" style="color:var(--pf-brand-700); border-color:var(--pf-brand-500)">${SISTEMAS[id].icono} ${SISTEMAS[id].nombre}</button>`).join("")}
    </div>
    <div class="flex flex-col sm:flex-row gap-3">
      <button type="button" data-wz="calc" class="btn-primary font-bold px-6 py-2.5 rounded-lg text-sm">Continuar al calculador de presupuesto</button>
      <button type="button" data-wz="reset" class="border border-gray-300 text-gray-600 font-medium px-6 py-2.5 rounded-lg hover:bg-gray-50 text-sm">Volver a empezar</button>
    </div>`;
}
function initAsistente() {
  const body = $("#wz-body");
  if (!body) return;
  renderAsistente();
  body.addEventListener("click", (e) => {
    const b = e.target.closest("[data-wz]");
    if (!b) return;
    const keys = Object.keys(RECO_PREGUNTAS);
    switch (b.dataset.wz) {
      case "start": wz.paso = 0; renderAsistente(); break;
      case "ans": wz.resp[keys[wz.paso]] = b.dataset.v; wz.paso++; renderAsistente(); break;
      case "back": wz.paso = Math.max(0, wz.paso - 1); renderAsistente(); break;
      case "reset": wz.paso = -1; wz.resp = {}; renderAsistente(); break;
      case "calc": irAlCalculador(); break;
      case "goto": irAlCalculador(); seleccionarTipo(b.dataset.id); showToast("Ítem cargado en el calculador"); break;
    }
  });
  $("#wz-volver")?.addEventListener("click", volverAlAsistente);
}
// ==========================================================
// ---------- MENÚ FLOTANTE ----------
// ==========================================================
function initFab() {
  const items = $("#fab-items"), tog = $("#fab-toggle");
  if (!items || !tog) return;
  const abrir = (v) => { items.classList.toggle("open", v); tog.textContent = v ? "✕" : "☰"; tog.setAttribute("aria-expanded", v); };
  tog.addEventListener("click", () => abrir(!items.classList.contains("open")));
  document.addEventListener("click", (e) => { if (!$("#fab").contains(e.target)) abrir(false); });
  items.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => {
    switchTab(b.dataset.go);
    window.scrollTo({ top: 0, behavior: "smooth" });
    abrir(false);
  }));
  $("#fab-chat")?.addEventListener("click", () => { $("#btn-toggle-chat")?.click(); abrir(false); });
  $("#fab-geo")?.addEventListener("click", () => { abrir(false); abrirGeo(); });
}
// ==========================================================
// ---------- GEOLOCALIZADOR (Geolocation API + OpenStreetMap / Nominatim) ----------
// ==========================================================
const NOMINATIM = "https://nominatim.openstreetmap.org";
let geoMapa = null, geoMarker = null, geoSel = null, geoToken = 0;
function geoInicializarMapa() {
  const el = $("#geo-map");
  if (!el) return;
  if (typeof L === "undefined") { $("#geo-status").textContent = "No se pudo cargar el mapa. Revisá tu conexión."; return; }
  if (geoMapa) { setTimeout(() => geoMapa.invalidateSize(), 60); return; }
  L.Icon.Default.imagePath = "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/";
  geoMapa = L.map(el).setView([-34.6, -58.45], 10);
  const calles = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "© OpenStreetMap" }).addTo(geoMapa);
  const satelite = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", { maxZoom: 19, attribution: "Imagery © Esri" });
  L.control.layers({ "Calles": calles, "Satélite": satelite }).addTo(geoMapa);
  geoMapa.on("click", (e) => geoColocar(e.latlng.lat, e.latlng.lng, { zoom: false }));
  setTimeout(() => geoMapa.invalidateSize(), 60);
}
async function geoColocar(lat, lon, { zoom = true, dir = null } = {}) {
  if (!geoMapa) return;
  const token = ++geoToken;
  geoSel = { lat: +lat, lon: +lon, dir: dir || "" };
  if (!geoMarker) {
    geoMarker = L.marker([lat, lon], { draggable: true }).addTo(geoMapa);
    geoMarker.on("dragend", () => { const p = geoMarker.getLatLng(); geoColocar(p.lat, p.lng, { zoom: false }); });
  } else geoMarker.setLatLng([lat, lon]);
  zoom ? geoMapa.setView([lat, lon], 17) : geoMapa.panTo([lat, lon]);
  const pintar = () => {
    $("#geo-addr").textContent = geoSel.dir || "Ubicación seleccionada";
    $("#geo-coords").textContent = `Lat ${geoSel.lat.toFixed(5)} · Lon ${geoSel.lon.toFixed(5)}`;
    $("#geo-result").classList.remove("hidden-view");
  };
  pintar();
  if (dir) return;
  try {
    const r = await fetch(`${NOMINATIM}/reverse?format=jsonv2&accept-language=es&lat=${lat}&lon=${lon}`);
    const jd = await r.json();
    if (token === geoToken && jd.display_name) { geoSel.dir = jd.display_name; pintar(); }
  } catch (e) { /* queda solo con coordenadas */ }
}
function geoReset() {
  geoSel = null; geoToken++;
  if (geoMarker && geoMapa) { geoMapa.removeLayer(geoMarker); geoMarker = null; }
  $("#geo-result")?.classList.add("hidden-view");
  if ($("#geo-q")) $("#geo-q").value = "";
}
function initGeo() {
  const st = $("#geo-status");
  if (!st) return;
  $("#geo-locate")?.addEventListener("click", () => {
    if (!navigator.geolocation) { st.textContent = "Tu navegador no soporta geolocalización."; return; }
    geoInicializarMapa();
    st.textContent = "Obteniendo tu ubicación…";
    navigator.geolocation.getCurrentPosition(
      (pos) => { geoColocar(pos.coords.latitude, pos.coords.longitude); st.textContent = "Ubicación encontrada ✔ Ajustá el pin si hace falta."; },
      (err) => { st.textContent = err.code === 1 ? "Permiso denegado. Habilitá la ubicación en el navegador o buscá una dirección." : "No se pudo obtener la ubicación."; },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  });
  async function buscar() {
    const q = $("#geo-q").value.trim();
    if (!q) return;
    geoInicializarMapa();
    st.textContent = "Buscando…";
    try {
      const r = await fetch(`${NOMINATIM}/search?format=jsonv2&limit=1&accept-language=es&q=${encodeURIComponent(q)}`);
      const jd = await r.json();
      if (!jd.length) { st.textContent = "No encontramos esa dirección."; return; }
      geoColocar(+jd[0].lat, +jd[0].lon, { dir: jd[0].display_name });
      st.textContent = "Dirección encontrada ✔ Ajustá el pin si hace falta.";
    } catch (e) { st.textContent = "Error al buscar. Intentá de nuevo."; }
  }
  $("#geo-search")?.addEventListener("click", buscar);
  $("#geo-q")?.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); buscar(); } });
}
function initCalculador() {
  renderTiposProyecto();
  setCalcStep(1);
  initAsistente();
  const recalcMedida = () => {
    const sis = SISTEMAS[calc.tipo];
    const largo = parseFloat($("#calc-largo")?.value) || 0;
    const alto = parseFloat($("#calc-alto")?.value) || 0;
    if (largo <= 0 || alto <= 0 || !$("#calc-m2")) return;
    let val = largo * alto;
    if (sis && sis.unidad === "m3") val *= (parseFloat($("#calc-espesor")?.value) || 0);
    $("#calc-m2").value = +val.toFixed(2);
    setCalcStep(3);
  };
  ["#calc-largo", "#calc-alto", "#calc-espesor"].forEach(id => $(id)?.addEventListener("input", recalcMedida));
  $("#calc-m2")?.addEventListener("input", () => setCalcStep(3));
  $("#btn-calcular")?.addEventListener("click", calcularMateriales);
  $("#btn-reiniciar-calc")?.addEventListener("click", reiniciarCalculador);
  initPasoFinal();
}
function poblarDestinoCalc() {
  const sel = $("#calc-partida-destino");
  if (!sel) return;
  const previo = sel.value;
  sel.innerHTML = '<option value="__nueva__">➕ Crear partida nueva</option>' +
    state.partidas.map(p => `<option value="${esc(p.id)}">${esc(p.nombre)}</option>`).join("");
  if ([...sel.options].some(o => o.value === previo)) sel.value = previo;
  actualizarHintDestino();
}
function actualizarHintDestino() {
  const sel = $("#calc-partida-destino"), hint = $("#calc-destino-hint");
  if (!sel || !hint) return;
  hint.textContent = sel.value === "__nueva__"
    ? "Se crea una partida nueva con el total del presupuesto."
    : `Se suman ${formatMoney(totalCalc())} al presupuesto asignado de la partida elegida.`;
}
const pdfTxt = (s) => String(s ?? "").replace(/[^\x20-\x7E\u00A0-\u00FF]/g, "").trim();
function nombrePresupuesto() {
  const sis = SISTEMAS[calc.tipo];
  const unidad = sis.unidad === "m3" ? "m³" : "m²";
  return ($("#calc-nombre-partida")?.value || "").trim() || `${sis.nombre} - ${calc.medida} ${unidad}`;
}
function generarPDFPresupuesto() {
  const sis = SISTEMAS[calc.tipo];
  if (!sis || !calc.materiales.length || totalCalc() <= 0) { showToast("Calculá primero los materiales", "⚠"); return null; }
  const JsPDF = window.jspdf?.jsPDF;
  if (!JsPDF) { showToast("No se pudo cargar el generador de PDF. Revisá tu conexión.", "⚠"); return null; }
  const destino = state.partidas.find(p => p.id === $("#calc-partida-destino")?.value);
  const unidad = sis.unidad === "m3" ? "m³" : "m²";
  const opciones = Object.entries(sis.opciones || {}).map(([k, cfg]) => {
    const o = cfg.opciones.find(x => String(x.v) === String(calc.opciones[k]));
    return [pdfTxt(cfg.label), pdfTxt(o ? o.t : calc.opciones[k])];
  });
  const tecnicos = Object.fromEntries(Object.entries(calc.tecnicos || {}).map(([k, v]) => [pdfTxt(k), pdfTxt(v)]));
  const titulo = pdfTxt(nombrePresupuesto()) || "Presupuesto";
  const doc = construirPDF(JsPDF, {
    titulo, fecha: new Date().toLocaleDateString("es-AR"), sistema: pdfTxt(sis.nombre),
    medida: `${calc.medida.toLocaleString("es-AR")} ${unidad}`, opciones,
    materiales: calc.materiales.map(m => ({ ...m, nombre: pdfTxt(m.nombre), unidad: pdfTxt(m.unidad) })),
    total: totalCalc(), tecnicos, partida: pdfTxt(destino?.nombre), ubicacion: pdfTxt(destino?.ubicacion?.dir)
  });
  return { doc, titulo };
}
function initPasoFinal() {
  $("#calc-partida-destino")?.addEventListener("change", actualizarHintDestino);
  $("#btn-pdf")?.addEventListener("click", () => {
    const r = generarPDFPresupuesto();
    if (!r) return;
    r.doc.save((r.titulo.replace(/[^\w-]+/g, "_") || "presupuesto") + ".pdf");
    showToast("PDF descargado");
  });
  $("#btn-enviar-mail")?.addEventListener("click", async () => {
    const email = ($("#calc-email")?.value || "").trim(), st = $("#calc-mail-status"), btn = $("#btn-enviar-mail");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { st.textContent = "Ingresá un correo válido."; return; }
    const r = generarPDFPresupuesto();
    if (!r) return;
    btn.disabled = true; st.textContent = "Enviando…";
    try {
      const pdf = r.doc.output("datauristring").split("base64,")[1];
      const res = await fetch("../api/enviar_presupuesto.php", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, titulo: r.titulo, pdf })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "No se pudo enviar el correo.");
      st.textContent = `Enviado a ${email} ✔`;
      showToast("Presupuesto enviado por correo");
    } catch (e) { st.textContent = e.message; }
    btn.disabled = false;
  });
  $("#btn-crear-partida-calc")?.addEventListener("click", () => {
    const total = totalCalc();
    if (!calc.materiales.length || total <= 0) { showToast("Calculá primero los materiales", "⚠"); return; }
    const nombre = nombrePresupuesto();
    const registro = { nombre, total, fecha: new Date().toISOString().slice(0, 10) };
    const destino = $("#calc-partida-destino")?.value;
    if (!destino || destino === "__nueva__") {
      const p = agregarPartida(nombre, total);
      p.presupuestos = [registro];
      showToast("Partida creada con el presupuesto calculado");
    } else {
      const p = state.partidas.find(x => x.id === destino);
      if (!p) { showToast("No se encontró la partida elegida", "⚠"); return; }
      p.asignado += total;
      (p.presupuestos = p.presupuestos || []).push(registro);
      showToast(`Se sumaron ${formatMoney(total)} a "${p.nombre}"`);
    }
    renderAll();
    switchTab("dashboard");
  });
}
// ---------- INICIALIZACIÓN Y EVENT LISTENERS ----------
function initEvents() {
  $$(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => switchTab(btn.dataset.tab));
  });
  if ($("#mobile-nav")) {
    $("#mobile-nav").addEventListener("change", (e) => switchTab(e.target.value));
  }
  const btnCargaManual = $("#btn-carga-manual");
  if (btnCargaManual) {
    btnCargaManual.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      ["#ia-empty", "#ia-scanning", "#ia-success"].forEach(id => {
        const el = $(id);
        if (el) {
          el.classList.add("hidden-view");
          el.style.display = "";
        }
      });
      const form = $("#ia-form");
      if (form) {
        form.reset();
        form.classList.remove("hidden-view");
        form.style.display = "";
      }
      if ($("#f-fecha")) {
        $("#f-fecha").value = new Date().toISOString().split("T")[0];
      }
      poblarSelectPartidas();
      actualizarTotalFactura();
      setStep(2);
    });
  }
  if ($("#btn-nueva-partida")) {
    $("#btn-nueva-partida").addEventListener("click", () => {
      const f = $("#form-partida");
      f?.classList.toggle("hidden-view");
      if (f && !f.classList.contains("hidden-view")) geoInicializarMapa();
    });
  }
  if ($("#btn-cancelar-partida")) {
    $("#btn-cancelar-partida").addEventListener("click", () => {
      $("#form-partida")?.classList.add("hidden-view");
      $("#form-partida")?.reset();
      geoReset();
    });
  }
  if ($("#form-partida")) {
    $("#form-partida").addEventListener("submit", (e) => {
      e.preventDefault();
      const nombre = $("#np-nombre")?.value.trim();
      const asignado = $("#np-asignado")?.value;
      if (!nombre) return;
      const nueva = agregarPartida(nombre, asignado);
      if (geoSel) nueva.ubicacion = { ...geoSel };
      $("#form-partida").reset();
      geoReset();
      $("#form-partida").classList.add("hidden-view");
      showToast("Partida de obra agregada");
      renderAll();
    });
  }
  if ($("#catalogo-search")) $("#catalogo-search").addEventListener("input", renderCatalogo);
  if ($("#catalogo-filter")) $("#catalogo-filter").addEventListener("change", renderCatalogo);
  const dropzone = $("#dropzone");
  const fileInput = $("#file-input");
  if (dropzone && fileInput) {
    dropzone.addEventListener("click", (e) => {
      if (e.target.closest("#btn-carga-manual")) return;
      fileInput.click();
    });
    fileInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (file) procesarFacturaConIA(file);
    });
    ['dragenter', 'dragover'].forEach(evt => {
      dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropzone.classList.add("drag-over");
      });
    });
    ['dragleave', 'drop'].forEach(evt => {
      dropzone.addEventListener(evt, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropzone.classList.remove("drag-over");
      });
    });
    dropzone.addEventListener("drop", (e) => {
      const files = e.dataTransfer.files;
      if (files && files.length > 0) {
        fileInput.files = files;
        procesarFacturaConIA(files[0]);
      }
    });
  }
  ["f-cantidad", "f-precio"].forEach(id => {
    const el = $("#" + id);
    if (el) el.addEventListener("input", actualizarTotalFactura);
  });
  if ($("#btn-cancelar-ia")) $("#btn-cancelar-ia").addEventListener("click", resetIA);
  if ($("#btn-nueva-factura")) $("#btn-nueva-factura").addEventListener("click", resetIA);
  if ($("#btn-ver-dashboard")) {
    $("#btn-ver-dashboard").addEventListener("click", () => {
      resetIA();
      switchTab("dashboard");
    });
  }
  if ($("#ia-form")) {
    $("#ia-form").addEventListener("submit", (e) => {
      e.preventDefault();
      if (state.partidas.length === 0) {
        showToast("Agregá una partida de obra antes de guardar", "⚠");
        return;
      }
      const item = {
        proveedor: $("#f-proveedor")?.value.trim(),
        fecha: $("#f-fecha")?.value,
        insumo: $("#f-insumo")?.value.trim(),
        unidad: $("#f-unidad")?.value,
        cantidad: parseFloat($("#f-cantidad")?.value) || 0,
        precio: parseFloat($("#f-precio")?.value) || 0,
        partida: $("#f-partida")?.value,
      };
      if (!item.proveedor || !item.insumo || !item.fecha) {
        showToast("Completá proveedor, insumo y fecha", "⚠");
        return;
      }
      guardarFacturaGlobal(item);
      if (iaCola.length) {
        cargarItemEnFormulario(iaCola.shift());
        showToast(`Ítem guardado · quedan ${iaCola.length} por confirmar`);
        renderAll();
        return;
      }
      $("#ia-form").classList.add("hidden-view");
      $("#ia-success")?.classList.remove("hidden-view");
      setStep(3);
      showToast("Factura guardada · presupuesto y catálogo actualizados");
      renderAll();
    });
  }
}
function initUsuario() {
  if ($("#sidebar-avatar")) $("#sidebar-avatar").textContent = "U";
  if ($("#topbar-avatar")) $("#topbar-avatar").textContent = "U";
  if ($("#sidebar-name") && state.usuario) $("#sidebar-name").textContent = state.usuario.nombre || "Usuario";
  if ($("#sidebar-role") && state.usuario) $("#sidebar-role").textContent = state.usuario.rol || "Administrador";
  if ($("#topbar-project") && state.usuario) $("#topbar-project").textContent = state.usuario.proyecto || "Sin obra asignada";
}
document.addEventListener("DOMContentLoaded", () => {
  setStep(0);
  initUsuario();
  initEvents();
  initCalculador();
  initFab();
  initGeo();
  renderAll();
});