<?php
// api/partidas.php · GET: lista las partidas del usuario · POST: crea o actualiza una partida.
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
session_start();

function responder($c, $a) { http_response_code($c); echo json_encode($a); exit; }
set_exception_handler(function ($e) { responder(500, ['error' => 'Error en el servidor: ' . $e->getMessage()]); });

require_once __DIR__ . '/conexion.php';
$idUsuario = (int)($_SESSION['id_usuario'] ?? $_SESSION['usuario_id'] ?? 1); // sin sesión: usuario demo (id 1)

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $st = $pdo->prepare("SELECT id_partida, nombre, asignado, gastado FROM partidas WHERE id_usuario = ? ORDER BY id_partida");
    $st->execute([$idUsuario]);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $out[] = ['id' => (int)$r['id_partida'], 'nombre' => $r['nombre'], 'asignado' => (float)$r['asignado'], 'gastado' => (float)$r['gastado']];
    }
    responder(200, ['partidas' => $out]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, ['error' => 'Método no permitido']);

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$accion = $in['accion'] ?? '';
$asignado = isset($in['asignado']) ? (float)$in['asignado'] : 0;
if ($asignado < 0) responder(400, ['error' => 'El presupuesto asignado no puede ser negativo.']);

if ($accion === 'crear') {
    $nombre = mb_substr(trim($in['nombre'] ?? ''), 0, 150);
    if ($nombre === '') responder(400, ['error' => 'El nombre de la partida es obligatorio.']);
    $pdo->prepare("INSERT INTO partidas (id_usuario, nombre, asignado, gastado) VALUES (?, ?, ?, 0)")->execute([$idUsuario, $nombre, $asignado]);
    responder(200, ['ok' => true, 'id' => (int)$pdo->lastInsertId()]);
}

if ($accion === 'actualizar') {
    $id = (int)($in['id'] ?? 0);
    $st = $pdo->prepare("UPDATE partidas SET asignado = ? WHERE id_partida = ? AND id_usuario = ?");
    $st->execute([$asignado, $id, $idUsuario]);
    responder(200, ['ok' => true]);
}

responder(400, ['error' => 'Acción no válida.']);