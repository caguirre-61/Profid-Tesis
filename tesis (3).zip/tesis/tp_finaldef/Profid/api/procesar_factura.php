<?php
// api/procesar_factura.php · Lee una factura con Gemini y la guarda en documentos, catalogo_insumos, movimientos y partidas.
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
session_start();

function responder($codigo, $arr) { if (ob_get_length()) ob_clean(); http_response_code($codigo); echo json_encode($arr); exit; }

set_exception_handler(function ($e) { responder(500, ['error' => 'Error interno en el servidor: ' . $e->getMessage()]); });

// 1. Clave de Gemini: variable de entorno o api/config_ia.php
$cfgIA = @include __DIR__ . '/config_ia.php';
if (!is_array($cfgIA)) $cfgIA = [];
$apiKey = getenv('GEMINI_API_KEY') ?: ($cfgIA['gemini_api_key'] ?? '');
if (!$apiKey) responder(500, ['error' => 'La clave API de Gemini no está configurada (api/config_ia.php).']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, ['error' => 'Método no permitido']);

// 2. Archivo subido
if (!isset($_FILES['factura']) || $_FILES['factura']['error'] !== UPLOAD_ERR_OK) responder(400, ['error' => 'No se subió ningún archivo o hubo un error en la carga']);
$file = $_FILES['factura'];
$mimeType = mime_content_type($file['tmp_name']);
if (!in_array($mimeType, ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'])) responder(400, ['error' => 'Formato no soportado. Subí un PDF o una imagen (PNG, JPG, WEBP)']);
$fileData = base64_encode(file_get_contents($file['tmp_name']));

// 4. Gemini
$prompt = "Analiza este comprobante/factura de compra de materiales de construcción y extrae los datos generales junto con la lista detallada de todos los ítems/materiales del comprobante.";
$payload = [
    "contents" => [["parts" => [["text" => $prompt], ["inline_data" => ["mime_type" => $mimeType, "data" => $fileData]]]]],
    "generationConfig" => [
        "temperature" => 0.1,
        "response_mime_type" => "application/json",
        "response_schema" => [
            "type" => "OBJECT",
            "properties" => [
                "proveedor" => ["type" => "STRING"],
                "fecha" => ["type" => "STRING", "description" => "Formato YYYY-MM-DD"],
                "items" => ["type" => "ARRAY", "items" => ["type" => "OBJECT", "properties" => [
                    "insumo" => ["type" => "STRING", "description" => "Descripción del material"],
                    "unidad" => ["type" => "STRING", "enum" => ["bolsa", "kg", "m3", "unidad", "barra", "litro"]],
                    "cantidad" => ["type" => "NUMBER"],
                    "precio_unitario" => ["type" => "NUMBER"]
                ], "required" => ["insumo", "unidad", "cantidad", "precio_unitario"]]]
            ],
            "required" => ["proveedor", "fecha", "items"]
        ]
    ]
];
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=" . $apiKey;

$apiResponse = null; $httpCode = 0; $curlError = '';
for ($intento = 1; $intento <= 3; $intento++) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_SSL_VERIFYPEER => ($cfgIA['ssl_verify'] ?? true)
    ]);
    $apiResponse = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    if (!$curlError && !in_array($httpCode, [429, 503])) break; // reintenta si Gemini está saturado
    if ($intento < 3) sleep($intento * 2);
}
if ($curlError) responder(500, ['error' => 'Error de conexión cURL: ' . $curlError]);
if ($httpCode !== 200) {
    $e = json_decode($apiResponse, true);
    responder(500, ['error' => "Gemini API Error ($httpCode): " . ($e['error']['message'] ?? 'Error desconocido en Gemini API')]);
}

// 5. Guardado en la base
try {
    $result = json_decode($apiResponse, true);
    $raw = $result['candidates'][0]['content']['parts'][0]['text'] ?? null;
    if (!$raw) throw new Exception("La API no devolvió contenido de texto.");
    $parsed = json_decode($raw, true);
    if (!$parsed || empty($parsed['items'])) throw new Exception("No se pudieron interpretar los ítems de la factura.");

    // Se conecta recién ahora (después de esperar a Gemini) para que la conexión no caduque
    require_once __DIR__ . '/conexion.php';

    // Usuario (sesión si existe; si no, el usuario demo id 1)
    $idUsuario = (int)($_SESSION['id_usuario'] ?? $_SESSION['usuario_id'] ?? 1);
    $st = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE id_usuario = ?");
    $st->execute([$idUsuario]);
    if (!$st->fetch()) throw new Exception("El usuario $idUsuario no existe en la tabla usuarios.");

    $pdo->beginTransaction();

    // Partida: la indicada si es del usuario; si no, la primera; si no hay, se crea una
    $partidaId = intval($_POST['partida_id'] ?? 0);
    $st = $pdo->prepare("SELECT id_partida FROM partidas WHERE id_partida = ? AND id_usuario = ?");
    $st->execute([$partidaId, $idUsuario]);
    if (!$st->fetch()) {
        $st = $pdo->prepare("SELECT id_partida FROM partidas WHERE id_usuario = ? ORDER BY id_partida LIMIT 1");
        $st->execute([$idUsuario]);
        $partidaId = (int)$st->fetchColumn();
        if (!$partidaId) {
            $pdo->prepare("INSERT INTO partidas (id_usuario, nombre, asignado, gastado) VALUES (?, 'Carga con IA', 0, 0)")->execute([$idUsuario]);
            $partidaId = (int)$pdo->lastInsertId();
        }
    }

    // Documento
    $tipoDoc = $mimeType === 'application/pdf' ? 'pdf' : 'imagen';
    $pdo->prepare("INSERT INTO documentos (id_usuario, nombre_archivo, tipo) VALUES (?, ?, ?)")
        ->execute([$idUsuario, mb_substr($file['name'], 0, 255), $tipoDoc]);
    $idDocumento = (int)$pdo->lastInsertId();

    $proveedor = mb_substr(trim($parsed['proveedor'] ?? '') ?: 'Proveedor Genérico', 0, 150);
    $fecha = (isset($parsed['fecha']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $parsed['fecha'])) ? $parsed['fecha'] : date('Y-m-d');

    $stCat = $pdo->prepare("
        INSERT INTO catalogo_insumos (id_usuario, proveedor, insumo, unidad, precio, id_partida, fecha_actualizacion)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE unidad = VALUES(unidad), precio = VALUES(precio), id_partida = VALUES(id_partida), fecha_actualizacion = VALUES(fecha_actualizacion)");
    $stMov = $pdo->prepare("
        INSERT INTO movimientos (id_usuario, id_partida, id_documento, proveedor, insumo, unidad, cantidad, precio, total, fecha)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $unidadesOk = ['bolsa', 'kg', 'm3', 'unidad', 'barra', 'litro'];
    $items = []; $montoTotal = 0;
    foreach ($parsed['items'] as $it) {
        $insumo = mb_substr(trim($it['insumo'] ?? '') ?: 'Material vario', 0, 150);
        $unidad = in_array($it['unidad'] ?? '', $unidadesOk) ? $it['unidad'] : 'unidad';
        $cant = floatval($it['cantidad'] ?? 1);
        $precio = floatval($it['precio_unitario'] ?? 0);
        $sub = round($cant * $precio, 2);

        $stCat->execute([$idUsuario, $proveedor, $insumo, $unidad, $precio, $partidaId, $fecha]);
        $stMov->execute([$idUsuario, $partidaId, $idDocumento, $proveedor, $insumo, $unidad, $cant, $precio, $sub, $fecha]);

        $montoTotal += $sub;
        $items[] = ['insumo' => $insumo, 'unidad' => $unidad, 'cantidad' => $cant, 'precio_unitario' => $precio, 'subtotal' => $sub];
    }
    $pdo->prepare("UPDATE partidas SET gastado = gastado + ? WHERE id_partida = ?")->execute([$montoTotal, $partidaId]);
    $pdo->commit();

    responder(200, [
        'success' => true,
        'mensaje' => 'Factura con ' . count($items) . ' ítem(s) procesada y guardada correctamente',
        'datos' => ['proveedor' => $proveedor, 'fecha' => $fecha, 'monto_total' => $montoTotal, 'items' => $items]
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    responder(500, ['error' => 'Error al guardar en la base de datos: ' . $e->getMessage()]);
}