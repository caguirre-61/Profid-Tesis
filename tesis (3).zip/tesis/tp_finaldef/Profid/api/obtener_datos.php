<?php
// obtener_datos.php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';

try {
    // 1. Obtener Partidas y su cálculo de gastos
    $stmtPartidas = $pdo->query("
        SELECT 
            p.id,
            p.nombre,
            p.monto_asignado AS asignado,
            COALESCE(SUM(m.cantidad * m.precio_unitario), 0) AS gastado
        FROM partidas p
        LEFT JOIN movimientos m ON p.id = m.partida_id
        GROUP BY p.id
    ");
    $partidas = $stmtPartidas->fetchAll();

    // 2. Obtener Lista del Catálogo
    $stmtCatalogo = $pdo->query("
        SELECT id, insumo, unidad, precio_unitario AS precio, fecha_actualizacion AS fecha 
        FROM catalogo_insumos 
        ORDER BY insumo ASC
    ");
    $catalogo = $stmtCatalogo->fetchAll();

    // 3. Obtener Últimos Movimientos
    $stmtMovimientos = $pdo->query("
        SELECT 
            m.id,
            m.concepto,
            m.unidad,
            m.cantidad,
            m.precio_unitario,
            m.subtotal,
            m.fecha,
            p.nombre AS partida_nombre,
            pr.nombre AS proveedor_nombre
        FROM movimientos m
        INNER JOIN partidas p ON m.partida_id = p.id
        LEFT JOIN proveedores pr ON m.proveedor_id = pr.id
        ORDER BY m.fecha DESC, m.id DESC
    ");
    $movimientos = $stmtMovimientos->fetchAll();

    echo json_encode([
        'partidas' => $partidas,
        'catalogo' => $catalogo,
        'movimientos' => $movimientos
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al obtener datos: ' . $e->getMessage()]);
}