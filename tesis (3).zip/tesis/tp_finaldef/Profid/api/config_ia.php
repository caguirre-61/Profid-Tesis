<?php
// api/config_ia.php · Secretos de la IA. NO subir a GitHub (agregar al .gitignore).
return [
    'gemini_api_key' => 'AQ.Ab8RN6Kbb9Q-Z6pNEMauIKHZ9YYkJB9A5tolrHnCQpGzda9aYA',
    'ssl_verify'     => false, // false SOLO en XAMPP local (sin certificados). En el hosting poné true.
];