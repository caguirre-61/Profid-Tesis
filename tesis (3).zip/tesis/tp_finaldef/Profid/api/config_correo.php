<?php
// api/config_correo.php
return [
    'host'      => 'smtp.gmail.com',
    'puerto'    => 465,
    'usuario'   => 'profidgestion@gmail.com',
    'password'  => 'znwc btek jvho gypw', // Tu contraseña de aplicación de 16 letras
    'cifrado'   => 'ssl',
    'remitente' => 'profidgestion@gmail.com',
    'nombre'    => 'Equipo ProFid',
    'debug'     => true // Cambiar a false en producción
];
