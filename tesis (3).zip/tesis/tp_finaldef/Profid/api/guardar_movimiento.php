<?php
// api/guardar_movimiento.php · Guarda un ítem de factura confirmado: movimiento + catálogo + gasto de la partida.
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
session_start();

function responder($c, $a) { http_response_code($c); echo json_encode($a); exit; }
set_exception_handler(function ($e) { responder(500, ['error' => 'Error en el servidor: ' . $e->getMessage()]); });

if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, ['error' => 'Método no permitido']);

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$partidaId = (int)($in['partida_id'] ?? 0);
$proveedor = mb_substr(trim($in['proveedor'] ?? ''), 0, 150);
$insumo = mb_substr(trim($in['insumo'] ?? ''), 0, 150);
$unidad = in_array($in['unidad'] ?? '', ['bolsa', 'kg', 'm3', 'unidad', 'barra', 'litro']) ? $in['unidad'] : 'unidad';
$cantidad = (float)($in['cantidad'] ?? 0);
$precio = (float)($in['precio'] ?? 0);
$fecha = $in['fecha'] ?? '';
if ($proveedor === '' || $insumo === '' || $cantidad <= 0 || $precio < 0) responder(400, ['error' => 'Completá proveedor, insumo, cantidad y precio.']);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) responder(400, ['error' => 'La fecha no es válida.']);
$total = round($cantidad * $precio, 2);

require_once __DIR__ . '/conexion.php';
$idUsuario = (int)($_SESSION['id_usuario'] ?? $_SESSION['usuario_id'] ?? 1);

try {
    $pdo->beginTransaction();
    $st = $pdo->prepare("SELECT id_partida FROM partidas WHERE id_partida = ? AND id_usuario = ?");
    $st->execute([$partidaId, $idUsuario]);
    if (!$st->fetch()) { $pdo->rollBack(); responder(404, ['error' => 'La partida elegida no existe en la base de datos.']); }

    $pdo->prepare("INSERT INTO movimientos (id_usuario, id_partida, proveedor, insumo, unidad, cantidad, precio, total, fecha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        ->execute([$idUsuario, $partidaId, $proveedor, $insumo, $unidad, $cantidad, $precio, $total, $fecha]);

    $pdo->prepare("INSERT INTO catalogo_insumos (id_usuario, proveedor, insumo, unidad, precio, id_partida, fecha_actualizacion) VALUES (?, ?, ?, ?, ?, ?, ?)
                   ON DUPLICATE KEY UPDATE unidad = VALUES(unidad), precio = VALUES(precio), id_partida = VALUES(id_partida), fecha_actualizacion = VALUES(fecha_actualizacion)")
        ->execute([$idUsuario, $proveedor, $insumo, $unidad, $precio, $partidaId, $fecha]);

    $pdo->prepare("UPDATE partidas SET gastado = gastado + ? WHERE id_partida = ?")->execute([$total, $partidaId]);
    $pdo->commit();
    responder(200, ['ok' => true]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    responder(500, ['error' => 'Error al guardar en la base de datos: ' . $e->getMessage()]);
}