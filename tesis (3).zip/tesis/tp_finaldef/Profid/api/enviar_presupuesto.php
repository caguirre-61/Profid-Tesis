<?php
// api/enviar_presupuesto.php · Envía por SMTP (PHPMailer) el PDF del presupuesto generado en el navegador.
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
session_start();

//  CORRECCIÓN: Reemplazamos los 'require' manuales por el Autoload de Composer
// Ajusta la ruta si tu carpeta 'vendor' está en otro nivel (ej: ../vendor/autoload.php)
require __DIR__ . '/../vendor/autoload.php'; 

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP; // Importamos SMTP por seguridad

function fallar($codigo, $msg) { http_response_code($codigo); echo json_encode(['error' => $msg]); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') fallar(405, 'Método no permitido');

$cfgArchivo = __DIR__ . '/config_correo.php';
if (!is_file($cfgArchivo)) fallar(500, 'Falta el archivo api/config_correo.php.');
$cfg = require $cfgArchivo;
if (($cfg['password'] ?? '') === '' || $cfg['password'] === 'COMPLETAR') fallar(500, 'Completá los datos SMTP en api/config_correo.php.');

// Límite anti-abuso: 1 envío cada 15 segundos y 10 por sesión
$ahora = time();
if (($ahora - ($_SESSION['ultimo_envio'] ?? 0)) < 15) fallar(429, 'Esperá unos segundos antes de enviar otro correo.');
if (($_SESSION['envios'] ?? 0) >= 10) fallar(429, 'Alcanzaste el límite de envíos de esta sesión.');

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$email = trim($in['email'] ?? '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fallar(400, 'El correo ingresado no es válido.');

$titulo = trim(preg_replace('/\s+/', ' ', mb_substr($in['titulo'] ?? 'Presupuesto', 0, 120)));
$pdf = base64_decode($in['pdf'] ?? '', true);
if ($pdf === false || strlen($pdf) > 5 * 1024 * 1024 || substr($pdf, 0, 4) !== '%PDF') fallar(400, 'El PDF recibido no es válido.');
$archivo = (preg_replace('/[^A-Za-z0-9_-]+/', '_', $titulo) ?: 'presupuesto') . '.pdf';

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = $cfg['host'];
    $mail->Port = (int)$cfg['puerto'];
    $mail->SMTPAuth = true;
    $mail->Username = $cfg['usuario'];
    $mail->Password = $cfg['password'];
    
    //  CORRECCIÓN: PHPMailer usa constantes de la clase PHPMailer para el cifrado
    $mail->SMTPSecure = (strtolower($cfg['cifrado'] ?? '') === 'tls') 
        ? PHPMailer::ENCRYPTION_STARTTLS 
        : PHPMailer::ENCRYPTION_SMTPS;
        
    $mail->CharSet = 'UTF-8';
    $mail->Timeout = 15;

    $mail->setFrom($cfg['remitente'], $cfg['nombre']);
    $mail->addAddress($email);
    $mail->Subject = "Tu presupuesto ProFid: $titulo";
    $mail->Body = "Hola,\n\nAdjuntamos tu presupuesto \"$titulo\" generado con ProFid.\nLos precios son estimativos y pueden variar según el proveedor.\n\nEquipo ProFid";
    
    //  CORRECCIÓN: Simplificado el método de adjunto usando constantes nativas
    $mail->addStringAttachment($pdf, $archivo, PHPMailer::ENCODING_BASE64, 'application/pdf');
    $mail->send();
} catch (Throwable $e) {
    error_log('enviar_presupuesto: ' . $mail->ErrorInfo . ' | ' . $e->getMessage());
    $detalle = !empty($cfg['debug']) ? ' Detalle: ' . ($mail->ErrorInfo ?: $e->getMessage()) : '';
    fallar(500, 'No se pudo enviar el correo.' . $detalle);
}

$_SESSION['ultimo_envio'] = $ahora;
$_SESSION['envios'] = ($_SESSION['envios'] ?? 0) + 1;
echo json_encode(['ok' => true]);
